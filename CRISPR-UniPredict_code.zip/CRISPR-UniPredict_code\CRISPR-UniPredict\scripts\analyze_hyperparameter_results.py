"""
Analyze hyperparameter tuning results
Provides detailed analysis and visualization of optimization results
"""

import argparse
import json
import sys
from pathlib import Path
from typing import Dict, List
import pickle

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import optuna
import yaml

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))


def load_results(results_dir: str) -> Dict:
    """
    Load all results from optimization
    
    Args:
        results_dir: Directory containing results
    
    Returns:
        Dictionary with all results
    """
    results_path = Path(results_dir)
    
    results = {}
    
    # Load trials
    trials_file = results_path / 'all_trials.json'
    if trials_file.exists():
        with open(trials_file) as f:
            results['trials'] = json.load(f)
    
    # Load summary
    summary_file = results_path / 'summary.json'
    if summary_file.exists():
        with open(summary_file) as f:
            results['summary'] = json.load(f)
    
    # Load best hyperparameters
    best_params_file = results_path / 'best_hyperparameters.yaml'
    if best_params_file.exists():
        with open(best_params_file) as f:
            results['best_params'] = yaml.safe_load(f)
    
    # Load study
    study_file = results_path / 'optuna_study.pkl'
    if study_file.exists():
        with open(study_file, 'rb') as f:
            results['study'] = pickle.load(f)
    
    return results


def print_summary(results: Dict) -> None:
    """Print optimization summary"""
    if 'summary' not in results:
        print("No summary found")
        return
    
    summary = results['summary']
    
    print("\n" + "="*80)
    print("OPTIMIZATION SUMMARY")
    print("="*80)
    
    print(f"\nTotal Trials: {summary.get('n_trials', 'N/A')}")
    print(f"Best Score: {summary.get('best_score', 'N/A'):.4f}")
    print(f"Best Trial: {summary.get('best_trial_id', 'N/A')}")
    print(f"Timestamp: {summary.get('timestamp', 'N/A')}")
    
    if 'best_hyperparameters' in summary:
        print("\nBest Hyperparameters:")
        for param, value in summary['best_hyperparameters'].items():
            if isinstance(value, float):
                print(f"  {param}: {value:.6f}")
            else:
                print(f"  {param}: {value}")


def print_top_trials(results: Dict, n: int = 10) -> None:
    """Print top N trials"""
    if 'trials' not in results:
        print("No trials found")
        return
    
    trials = results['trials']
    sorted_trials = sorted(trials, key=lambda x: x['combined_score'], reverse=True)
    
    print("\n" + "="*80)
    print(f"TOP {n} TRIALS")
    print("="*80)
    
    for i, trial in enumerate(sorted_trials[:n]):
        print(f"\n{i+1}. Trial {trial['trial_id']}")
        print(f"   Combined Score: {trial['combined_score']:.4f}")
        print(f"   SCC: {trial['scc']:.4f}")
        print(f"   AUROC: {trial['auroc']:.4f}")
        print(f"   Val Loss: {trial['val_loss']:.4f}")


def print_parameter_statistics(results: Dict) -> None:
    """Print statistics for each hyperparameter"""
    if 'trials' not in results:
        print("No trials found")
        return
    
    trials = results['trials']
    
    # Collect all parameters
    all_params = {}
    for trial in trials:
        for param, value in trial['hyperparams'].items():
            if param not in all_params:
                all_params[param] = []
            all_params[param].append(value)
    
    print("\n" + "="*80)
    print("PARAMETER STATISTICS")
    print("="*80)
    
    for param in sorted(all_params.keys()):
        values = all_params[param]
        
        # Check if numeric
        try:
            numeric_values = [float(v) for v in values]
            print(f"\n{param}:")
            print(f"  Mean: {np.mean(numeric_values):.6f}")
            print(f"  Std: {np.std(numeric_values):.6f}")
            print(f"  Min: {np.min(numeric_values):.6f}")
            print(f"  Max: {np.max(numeric_values):.6f}")
        except (ValueError, TypeError):
            # Categorical parameter
            unique_values = set(values)
            print(f"\n{param}:")
            print(f"  Unique values: {unique_values}")
            print(f"  Count: {len(unique_values)}")


def analyze_parameter_correlation(results: Dict) -> None:
    """Analyze correlation between parameters and score"""
    if 'trials' not in results:
        print("No trials found")
        return
    
    trials = results['trials']
    
    # Create dataframe
    data = []
    for trial in trials:
        row = trial['hyperparams'].copy()
        row['combined_score'] = trial['combined_score']
        row['scc'] = trial['scc']
        row['auroc'] = trial['auroc']
        data.append(row)
    
    df = pd.DataFrame(data)
    
    # Convert to numeric where possible
    for col in df.columns:
        try:
            df[col] = pd.to_numeric(df[col])
        except (ValueError, TypeError):
            pass
    
    print("\n" + "="*80)
    print("PARAMETER CORRELATION WITH SCORE")
    print("="*80)
    
    # Calculate correlations
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    correlations = df[numeric_cols].corr()['combined_score'].sort_values(ascending=False)
    
    print("\nCorrelation with Combined Score:")
    for param, corr in correlations.items():
        if param != 'combined_score':
            print(f"  {param}: {corr:.4f}")


def create_detailed_report(results: Dict, output_file: str) -> None:
    """Create detailed analysis report"""
    if 'trials' not in results:
        print("No trials found")
        return
    
    trials = results['trials']
    
    # Create figure with subplots
    fig = plt.figure(figsize=(20, 14))
    gs = fig.add_gridspec(4, 4, hspace=0.35, wspace=0.35)
    
    # 1. Score distribution
    ax = fig.add_subplot(gs[0, 0])
    scores = [t['combined_score'] for t in trials]
    ax.hist(scores, bins=20, color='steelblue', edgecolor='black', alpha=0.7)
    ax.axvline(np.mean(scores), color='r', linestyle='--', label=f'Mean: {np.mean(scores):.4f}')
    ax.set_xlabel('Combined Score')
    ax.set_ylabel('Frequency')
    ax.set_title('Score Distribution')
    ax.legend()
    ax.grid(True, alpha=0.3, axis='y')
    
    # 2. SCC distribution
    ax = fig.add_subplot(gs[0, 1])
    sccs = [t['scc'] for t in trials]
    ax.hist(sccs, bins=20, color='steelgreen', edgecolor='black', alpha=0.7)
    ax.axvline(np.mean(sccs), color='r', linestyle='--', label=f'Mean: {np.mean(sccs):.4f}')
    ax.set_xlabel('SCC')
    ax.set_ylabel('Frequency')
    ax.set_title('SCC Distribution')
    ax.legend()
    ax.grid(True, alpha=0.3, axis='y')
    
    # 3. AUROC distribution
    ax = fig.add_subplot(gs[0, 2])
    aurocs = [t['auroc'] for t in trials]
    ax.hist(aurocs, bins=20, color='steelcyan', edgecolor='black', alpha=0.7)
    ax.axvline(np.mean(aurocs), color='r', linestyle='--', label=f'Mean: {np.mean(aurocs):.4f}')
    ax.set_xlabel('AUROC')
    ax.set_ylabel('Frequency')
    ax.set_title('AUROC Distribution')
    ax.legend()
    ax.grid(True, alpha=0.3, axis='y')
    
    # 4. Loss distribution
    ax = fig.add_subplot(gs[0, 3])
    losses = [t['val_loss'] for t in trials]
    ax.hist(losses, bins=20, color='steelred', edgecolor='black', alpha=0.7)
    ax.axvline(np.mean(losses), color='r', linestyle='--', label=f'Mean: {np.mean(losses):.4f}')
    ax.set_xlabel('Validation Loss')
    ax.set_ylabel('Frequency')
    ax.set_title('Loss Distribution')
    ax.legend()
    ax.grid(True, alpha=0.3, axis='y')
    
    # 5-8. Parameter effects
    param_names = list(trials[0]['hyperparams'].keys())[:4]
    for idx, param in enumerate(param_names):
        ax = fig.add_subplot(gs[1, idx])
        param_values = [t['hyperparams'][param] for t in trials]
        
        try:
            param_values_numeric = [float(v) for v in param_values]
            ax.scatter(param_values_numeric, scores, alpha=0.6, s=100, color='steelblue')
            ax.set_xlabel(param)
            ax.set_ylabel('Score')
            ax.set_title(f'{param} Effect')
            ax.grid(True, alpha=0.3)
        except (ValueError, TypeError):
            # Categorical parameter
            unique_vals = list(set(param_values))
            val_scores = {val: [] for val in unique_vals}
            for pv, score in zip(param_values, scores):
                val_scores[pv].append(score)
            
            means = [np.mean(val_scores[v]) for v in unique_vals]
            ax.bar(range(len(unique_vals)), means, color='steelblue', edgecolor='black')
            ax.set_xticks(range(len(unique_vals)))
            ax.set_xticklabels(unique_vals, rotation=45)
            ax.set_ylabel('Mean Score')
            ax.set_title(f'{param} Effect')
            ax.grid(True, alpha=0.3, axis='y')
    
    # 9-12. More parameter effects
    for idx, param in enumerate(param_names[4:8] if len(param_names) > 4 else []):
        ax = fig.add_subplot(gs[2, idx])
        param_values = [t['hyperparams'][param] for t in trials]
        
        try:
            param_values_numeric = [float(v) for v in param_values]
            ax.scatter(param_values_numeric, scores, alpha=0.6, s=100, color='steelblue')
            ax.set_xlabel(param)
            ax.set_ylabel('Score')
            ax.set_title(f'{param} Effect')
            ax.grid(True, alpha=0.3)
        except (ValueError, TypeError):
            pass
    
    # 13. SCC vs AUROC
    ax = fig.add_subplot(gs[3, 0])
    scatter = ax.scatter(sccs, aurocs, c=scores, cmap='viridis', s=100, alpha=0.6)
    ax.set_xlabel('SCC')
    ax.set_ylabel('AUROC')
    ax.set_title('SCC vs AUROC')
    plt.colorbar(scatter, ax=ax, label='Score')
    ax.grid(True, alpha=0.3)
    
    # 14. Score over trials
    ax = fig.add_subplot(gs[3, 1])
    ax.plot(range(len(scores)), scores, 'b-o', linewidth=2, markersize=4, alpha=0.6)
    ax.axhline(np.max(scores), color='r', linestyle='--', label=f'Best: {np.max(scores):.4f}')
    ax.set_xlabel('Trial Number')
    ax.set_ylabel('Score')
    ax.set_title('Score Over Trials')
    ax.legend()
    ax.grid(True, alpha=0.3)
    
    # 15. Cumulative best score
    ax = fig.add_subplot(gs[3, 2])
    cumulative_best = [max(scores[:i+1]) for i in range(len(scores))]
    ax.plot(range(len(cumulative_best)), cumulative_best, 'g-o', linewidth=2, markersize=4)
    ax.set_xlabel('Trial Number')
    ax.set_ylabel('Best Score')
    ax.set_title('Cumulative Best Score')
    ax.grid(True, alpha=0.3)
    
    # 16. Statistics box
    ax = fig.add_subplot(gs[3, 3])
    ax.axis('off')
    
    stats_text = f"""
    STATISTICS
    
    Total Trials: {len(trials)}
    
    Combined Score:
      Mean: {np.mean(scores):.4f}
      Std: {np.std(scores):.4f}
      Min: {np.min(scores):.4f}
      Max: {np.max(scores):.4f}
    
    SCC:
      Mean: {np.mean(sccs):.4f}
      Max: {np.max(sccs):.4f}
    
    AUROC:
      Mean: {np.mean(aurocs):.4f}
      Max: {np.max(aurocs):.4f}
    
    Loss:
      Mean: {np.mean(losses):.4f}
      Min: {np.min(losses):.4f}
    """
    
    ax.text(0.1, 0.9, stats_text, transform=ax.transAxes, fontsize=10,
            verticalalignment='top', fontfamily='monospace',
            bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
    
    # Save figure
    plt.savefig(output_file, dpi=150, bbox_inches='tight')
    print(f"\nDetailed report saved to {output_file}")
    plt.close()


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(description='Analyze hyperparameter tuning results')
    parser.add_argument('--results_dir', type=str, default='results/hyperparameter_tuning',
                       help='Results directory')
    parser.add_argument('--top_n', type=int, default=10, help='Number of top trials to show')
    parser.add_argument('--detailed_report', action='store_true',
                       help='Generate detailed report')
    parser.add_argument('--output_file', type=str, default='detailed_analysis.png',
                       help='Output file for detailed report')
    
    args = parser.parse_args()
    
    # Load results
    results = load_results(args.results_dir)
    
    if not results:
        print(f"No results found in {args.results_dir}")
        return
    
    # Print summary
    print_summary(results)
    
    # Print top trials
    print_top_trials(results, args.top_n)
    
    # Print parameter statistics
    print_parameter_statistics(results)
    
    # Analyze correlations
    analyze_parameter_correlation(results)
    
    # Generate detailed report
    if args.detailed_report:
        output_path = Path(args.results_dir) / args.output_file
        create_detailed_report(results, str(output_path))


if __name__ == '__main__':
    main()
