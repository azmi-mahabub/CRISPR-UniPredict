"""
Create a GUIDE-LEVEL (sequence-level) train/val/test split for the OFF-TARGET data.

Why this exists
---------------
`scripts/create_sequence_splits.py` only sequence-splits the ON-target data; it
deliberately reuses the off-target PAIR-level split unchanged ("off-target is
already leak-free"). But pair-level uniqueness does NOT rule out guide-level
leakage: each sgRNA appears in many (sgRNA, target) pairs, and if a guide's pairs
are spread across train and test the model can memorise guide-specific patterns,
inflating the test AUROC/AUPRC.

This script groups off-target pairs by sgRNA so every pair for a given guide lands
in exactly one split. Training on this split and comparing to the pair-level
numbers (AUROC 0.9931 / AUPRC 0.8315) is the leakage check — see
`run_offtarget_seqsplit.py`.

Output (off-target only; same schema as the combined CSVs):
  data/processed/combined/train_offtarget_seqsplit.csv
  data/processed/combined/val_offtarget_seqsplit.csv
  data/processed/combined/test_offtarget_seqsplit.csv
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd

_ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = _ROOT / 'data' / 'processed' / 'combined'

TRAIN_FRAC = 0.80
VAL_FRAC = 0.10
SEED = 42


def load_offtarget() -> pd.DataFrame:
    parts = []
    for split in ['train', 'val', 'test']:
        df = pd.read_csv(DATA_DIR / f'{split}.csv')
        df.columns = [c.lower() for c in df.columns]
        parts.append(df[df['task_type'] == 'off_target'].copy())
    full = pd.concat(parts, ignore_index=True)
    full = full.dropna(subset=['sgrna_sequence', 'target_sequence', 'off_target_label'])
    full['off_target_label'] = full['off_target_label'].astype(int)
    return full.reset_index(drop=True)


def guide_level_split(df: pd.DataFrame, seed: int = SEED):
    """Assign whole guides (unique sgRNA) to train/val/test so none cross splits."""
    rng = np.random.default_rng(seed)
    guides = df['sgrna_sequence'].str.upper().unique()
    rng.shuffle(guides)
    n = len(guides)
    n_tr = int(n * TRAIN_FRAC)
    n_va = int(n * VAL_FRAC)
    tr_g = set(guides[:n_tr])
    va_g = set(guides[n_tr:n_tr + n_va])
    te_g = set(guides[n_tr + n_va:])
    up = df['sgrna_sequence'].str.upper()
    return (df[up.isin(tr_g)].copy(),
            df[up.isin(va_g)].copy(),
            df[up.isin(te_g)].copy(),
            (tr_g, va_g, te_g))


def main():
    print("=" * 64)
    print("OFF-TARGET guide-level (sequence-level) split creator")
    print("=" * 64)

    df = load_offtarget()
    n_guides = df['sgrna_sequence'].str.upper().nunique()
    print(f"\nOff-target pairs: {len(df):,}  "
          f"(pos {int(df['off_target_label'].sum()):,}, "
          f"{100 * df['off_target_label'].mean():.2f}% positive)")
    print(f"Unique sgRNA guides: {n_guides:,}")
    if n_guides < 20:
        print("  WARNING: very few unique guides — a guide-level split will be coarse "
              "and the test metrics will be high-variance.")

    tr, va, te, (tr_g, va_g, te_g) = guide_level_split(df)

    assert not (tr_g & te_g), "guide overlap train/test!"
    assert not (tr_g & va_g), "guide overlap train/val!"
    assert not (va_g & te_g), "guide overlap val/test!"
    print("\n  Guide-overlap check: PASSED (0 shared guides across splits)")

    print(f"\n{'Split':<8}{'pairs':>12}{'guides':>10}{'pos':>10}{'pos %':>9}")
    print("-" * 49)
    for name, d in [('train', tr), ('val', va), ('test', te)]:
        pos = int(d['off_target_label'].sum())
        print(f"{name:<8}{len(d):>12,}"
              f"{d['sgrna_sequence'].str.upper().nunique():>10,}"
              f"{pos:>10,}{100 * d['off_target_label'].mean():>8.2f}%")
        if pos < 30:
            print(f"  WARNING: {name} has only {pos} positives — its metrics will be noisy.")

    for name, d in [('train_offtarget_seqsplit', tr),
                    ('val_offtarget_seqsplit', va),
                    ('test_offtarget_seqsplit', te)]:
        p = DATA_DIR / f'{name}.csv'
        d.to_csv(p, index=False)
        print(f"\n  Saved {p.name}: {len(d):,} rows ({p.stat().st_size / 1e6:.1f} MB)")

    print("\nDone. Next: python run_offtarget_seqsplit.py")


if __name__ == '__main__':
    main()
