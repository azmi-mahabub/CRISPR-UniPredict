"""
Real-time Training Monitoring Dashboard for CRISPR-UniPredict
Monitors training progress, system resources, and detects anomalies
"""

import argparse
import json
import logging
import sys
import time
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Tuple
import threading

import numpy as np
import torch
import psutil
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.gridspec import GridSpec

try:
    import dash
    from dash import dcc, html, callback, Input, Output, State
    import plotly.graph_objects as go
    import plotly.express as px
    DASH_AVAILABLE = True
except ImportError:
    DASH_AVAILABLE = False

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

logger = logging.getLogger(__name__)


class TrainingMonitor:
    """Monitor training progress and system resources in real-time"""
    
    def __init__(self, log_dir: str, refresh_rate: int = 10):
        """
        Initialize training monitor
        
        Args:
            log_dir: Directory containing training logs
            refresh_rate: Update frequency in seconds
        """
        self.log_dir = Path(log_dir)
        self.refresh_rate = refresh_rate
        self.metrics_file = self.log_dir / 'training_history.json'
        self.config_file = self.log_dir / 'config.json'
        
        # Data storage
        self.metrics = {
            'epochs': [],
            'train_loss': [],
            'val_loss': [],
            'on_target_loss': [],
            'off_target_loss': [],
            'on_target_scc': [],
            'on_target_pcc': [],
            'off_target_auroc': [],
            'off_target_auprc': [],
            'learning_rate': [],
            'gpu_util': [],
            'memory_util': [],
            'gradient_norm': [],
            'timestamps': []
        }
        
        self.alerts = []
        self.best_epoch = 0
        self.best_val_loss = float('inf')
        self.last_improvement_epoch = 0
        self.stalled_epochs = 0
        
        # Configuration
        self.config = self._load_config()
        self.early_stopping_patience = self.config.get('validation', {}).get('early_stopping_patience', 10)
        
        logger.info(f"Monitor initialized for {self.log_dir}")
    
    def _load_config(self) -> Dict:
        """Load configuration from file"""
        if self.config_file.exists():
            try:
                with open(self.config_file) as f:
                    return json.load(f)
            except Exception as e:
                logger.warning(f"Could not load config: {e}")
        return {}
    
    def load_metrics(self) -> bool:
        """
        Load metrics from training history file
        
        Returns:
            True if metrics were loaded, False otherwise
        """
        if not self.metrics_file.exists():
            return False
        
        try:
            with open(self.metrics_file) as f:
                history = json.load(f)
            
            # Clear old metrics
            for key in self.metrics:
                self.metrics[key] = []
            
            # Parse training history
            train_history = history.get('train', [])
            val_history = history.get('val', [])
            
            for epoch, (train_metrics, val_metrics) in enumerate(zip(train_history, val_history)):
                self.metrics['epochs'].append(epoch + 1)
                self.metrics['train_loss'].append(train_metrics.get('total_loss', np.nan))
                self.metrics['val_loss'].append(val_metrics.get('total_loss', np.nan))
                self.metrics['on_target_loss'].append(train_metrics.get('on_target_loss', np.nan))
                self.metrics['off_target_loss'].append(train_metrics.get('off_target_loss', np.nan))
                
                # Validation metrics
                self.metrics['on_target_scc'].append(val_metrics.get('on_target_spearman', np.nan))
                self.metrics['on_target_pcc'].append(val_metrics.get('on_target_pearson', np.nan))
                self.metrics['off_target_auroc'].append(val_metrics.get('off_target_auroc', np.nan))
                self.metrics['off_target_auprc'].append(val_metrics.get('off_target_auprc', np.nan))
                
                self.metrics['timestamps'].append(datetime.now().isoformat())
            
            return len(self.metrics['epochs']) > 0
        
        except Exception as e:
            logger.error(f"Error loading metrics: {e}")
            return False
    
    def get_system_metrics(self) -> Dict[str, float]:
        """
        Get current system resource metrics
        
        Returns:
            Dictionary with GPU and memory utilization
        """
        metrics = {
            'cpu_percent': psutil.cpu_percent(interval=0.1),
            'memory_percent': psutil.virtual_memory().percent,
            'memory_gb': psutil.virtual_memory().used / 1e9
        }
        
        # GPU metrics
        if torch.cuda.is_available():
            try:
                metrics['gpu_util'] = torch.cuda.utilization() if hasattr(torch.cuda, 'utilization') else 0
                metrics['gpu_memory_gb'] = torch.cuda.memory_allocated() / 1e9
                metrics['gpu_memory_reserved_gb'] = torch.cuda.memory_reserved() / 1e9
            except:
                metrics['gpu_util'] = 0
                metrics['gpu_memory_gb'] = 0
                metrics['gpu_memory_reserved_gb'] = 0
        else:
            metrics['gpu_util'] = 0
            metrics['gpu_memory_gb'] = 0
            metrics['gpu_memory_reserved_gb'] = 0
        
        return metrics
    
    def check_for_issues(self) -> List[str]:
        """
        Check for training issues and anomalies
        
        Returns:
            List of alert messages
        """
        alerts = []
        
        if len(self.metrics['epochs']) == 0:
            return alerts
        
        latest_epoch = self.metrics['epochs'][-1]
        latest_val_loss = self.metrics['val_loss'][-1]
        
        # Check for NaN loss
        if np.isnan(latest_val_loss):
            alerts.append("⚠️ CRITICAL: Loss is NaN - gradient explosion detected!")
        
        # Check for stalled training
        if latest_val_loss < self.best_val_loss:
            self.best_val_loss = latest_val_loss
            self.best_epoch = latest_epoch
            self.last_improvement_epoch = latest_epoch
            self.stalled_epochs = 0
        else:
            self.stalled_epochs += 1
            
            if self.stalled_epochs > self.early_stopping_patience:
                alerts.append(
                    f"⚠️ WARNING: Training stalled for {self.stalled_epochs} epochs. "
                    f"Consider early stopping."
                )
            elif self.stalled_epochs > self.early_stopping_patience // 2:
                alerts.append(
                    f"ℹ️ INFO: No improvement for {self.stalled_epochs} epochs. "
                    f"Best loss: {self.best_val_loss:.6f} at epoch {self.best_epoch}"
                )
        
        # Check for validation performance degradation
        if len(self.metrics['val_loss']) > 5:
            recent_losses = self.metrics['val_loss'][-5:]
            if all(not np.isnan(l) for l in recent_losses):
                recent_trend = np.polyfit(range(5), recent_losses, 1)[0]
                if recent_trend > 0.001:  # Increasing loss
                    alerts.append(
                        f"⚠️ WARNING: Validation loss increasing. "
                        f"Trend: {recent_trend:.6f}/epoch"
                    )
        
        # Check for gradient vanishing (inferred from loss plateau)
        if len(self.metrics['train_loss']) > 10:
            recent_train = self.metrics['train_loss'][-10:]
            if all(not np.isnan(l) for l in recent_train):
                train_std = np.std(recent_train)
                if train_std < 1e-6:
                    alerts.append(
                        "⚠️ WARNING: Training loss plateau detected. "
                        "Possible gradient vanishing."
                    )
        
        # Check for memory issues
        system_metrics = self.get_system_metrics()
        if system_metrics['memory_percent'] > 90:
            alerts.append(
                f"⚠️ WARNING: High RAM usage ({system_metrics['memory_percent']:.1f}%). "
                f"OOM risk!"
            )
        
        if system_metrics['gpu_memory_gb'] > 0:
            gpu_total = torch.cuda.get_device_properties(0).total_memory / 1e9
            gpu_percent = (system_metrics['gpu_memory_gb'] / gpu_total) * 100
            if gpu_percent > 90:
                alerts.append(
                    f"⚠️ WARNING: High GPU memory usage ({gpu_percent:.1f}%). "
                    f"OOM risk!"
                )
        
        return alerts
    
    def get_summary(self) -> Dict:
        """Get summary statistics of training"""
        if len(self.metrics['epochs']) == 0:
            return {}
        
        return {
            'total_epochs': len(self.metrics['epochs']),
            'best_epoch': self.best_epoch,
            'best_val_loss': self.best_val_loss,
            'current_val_loss': self.metrics['val_loss'][-1],
            'epochs_since_improvement': self.stalled_epochs,
            'current_lr': self.metrics['learning_rate'][-1] if self.metrics['learning_rate'] else 'N/A',
            'current_gpu_util': self.metrics['gpu_util'][-1] if self.metrics['gpu_util'] else 0,
            'current_memory_util': self.metrics['memory_util'][-1] if self.metrics['memory_util'] else 0
        }
    
    def print_status(self) -> None:
        """Print current training status to console"""
        if not self.load_metrics():
            print("Waiting for training data...")
            return
        
        summary = self.get_summary()
        alerts = self.check_for_issues()
        
        print("\n" + "="*80)
        print(f"CRISPR-UniPredict Training Monitor - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print("="*80)
        
        if summary:
            print(f"\n📊 Training Progress:")
            print(f"  Epochs completed: {summary['total_epochs']}")
            print(f"  Best epoch: {summary['best_epoch']} (Loss: {summary['best_val_loss']:.6f})")
            print(f"  Current loss: {summary['current_val_loss']:.6f}")
            print(f"  Epochs since improvement: {summary['epochs_since_improvement']}")
        
        system_metrics = self.get_system_metrics()
        print(f"\n💻 System Resources:")
        print(f"  CPU: {system_metrics['cpu_percent']:.1f}%")
        print(f"  RAM: {system_metrics['memory_percent']:.1f}% ({system_metrics['memory_gb']:.1f} GB)")
        if torch.cuda.is_available():
            print(f"  GPU: {system_metrics['gpu_util']:.1f}%")
            print(f"  VRAM: {system_metrics['gpu_memory_gb']:.2f} GB / {torch.cuda.get_device_properties(0).total_memory / 1e9:.2f} GB")
        
        if alerts:
            print(f"\n🚨 Alerts ({len(alerts)}):")
            for alert in alerts:
                print(f"  {alert}")
        else:
            print(f"\n✅ No issues detected")
        
        print("="*80 + "\n")


class MatplotlibDashboard:
    """Matplotlib-based real-time monitoring dashboard"""
    
    def __init__(self, monitor: TrainingMonitor, save_dir: Optional[str] = None):
        """
        Initialize matplotlib dashboard
        
        Args:
            monitor: TrainingMonitor instance
            save_dir: Directory to save snapshots
        """
        self.monitor = monitor
        self.save_dir = Path(save_dir) if save_dir else monitor.log_dir / 'dashboard_snapshots'
        self.save_dir.mkdir(parents=True, exist_ok=True)
        
        plt.style.use('seaborn-v0_8-darkgrid')
        self.fig = None
        self.axes = None
    
    def create_dashboard(self) -> None:
        """Create dashboard layout with subplots"""
        self.fig = plt.figure(figsize=(16, 10))
        self.fig.suptitle('CRISPR-UniPredict Training Monitor', fontsize=16, fontweight='bold')
        
        gs = GridSpec(3, 3, figure=self.fig, hspace=0.3, wspace=0.3)
        
        self.axes = {
            'train_loss': self.fig.add_subplot(gs[0, 0]),
            'val_metrics': self.fig.add_subplot(gs[0, 1]),
            'learning_rate': self.fig.add_subplot(gs[0, 2]),
            'gpu_util': self.fig.add_subplot(gs[1, 0]),
            'memory': self.fig.add_subplot(gs[1, 1]),
            'gradient_norm': self.fig.add_subplot(gs[1, 2]),
            'on_target_corr': self.fig.add_subplot(gs[2, 0]),
            'off_target_metrics': self.fig.add_subplot(gs[2, 1]),
            'alerts': self.fig.add_subplot(gs[2, 2])
        }
    
    def update_plots(self) -> None:
        """Update all plots with current metrics"""
        if not self.monitor.load_metrics():
            return
        
        if self.fig is None:
            self.create_dashboard()
        
        # Clear all axes
        for ax in self.axes.values():
            ax.clear()
        
        epochs = self.monitor.metrics['epochs']
        
        # 1. Training Loss
        ax = self.axes['train_loss']
        ax.plot(epochs, self.monitor.metrics['train_loss'], 'b-o', label='Train Loss', linewidth=2)
        ax.plot(epochs, self.monitor.metrics['val_loss'], 'r-s', label='Val Loss', linewidth=2)
        ax.axvline(self.monitor.best_epoch, color='g', linestyle='--', alpha=0.5, label='Best Model')
        ax.set_xlabel('Epoch')
        ax.set_ylabel('Loss')
        ax.set_title('Training Loss')
        ax.legend()
        ax.grid(True, alpha=0.3)
        
        # 2. Validation Metrics
        ax = self.axes['val_metrics']
        ax.plot(epochs, self.monitor.metrics['on_target_scc'], 'b-o', label='SCC', linewidth=2)
        ax.plot(epochs, self.monitor.metrics['on_target_pcc'], 'g-s', label='PCC', linewidth=2)
        ax.set_xlabel('Epoch')
        ax.set_ylabel('Correlation')
        ax.set_title('On-Target Validation Metrics')
        ax.legend()
        ax.grid(True, alpha=0.3)
        ax.set_ylim([-1, 1])
        
        # 3. Learning Rate
        ax = self.axes['learning_rate']
        if self.monitor.metrics['learning_rate']:
            ax.plot(epochs, self.monitor.metrics['learning_rate'], 'purple', marker='o', linewidth=2)
        ax.set_xlabel('Epoch')
        ax.set_ylabel('Learning Rate')
        ax.set_title('Learning Rate Schedule')
        ax.grid(True, alpha=0.3)
        ax.set_yscale('log')
        
        # 4. GPU Utilization
        ax = self.axes['gpu_util']
        if self.monitor.metrics['gpu_util']:
            ax.plot(epochs, self.monitor.metrics['gpu_util'], 'orange', marker='o', linewidth=2)
            ax.set_ylim([0, 100])
        ax.set_xlabel('Epoch')
        ax.set_ylabel('GPU Utilization (%)')
        ax.set_title('GPU Utilization')
        ax.grid(True, alpha=0.3)
        
        # 5. Memory Usage
        ax = self.axes['memory']
        if self.monitor.metrics['memory_util']:
            ax.plot(epochs, self.monitor.metrics['memory_util'], 'cyan', marker='o', linewidth=2)
            ax.axhline(90, color='r', linestyle='--', alpha=0.5, label='OOM Risk')
            ax.set_ylim([0, 100])
        ax.set_xlabel('Epoch')
        ax.set_ylabel('Memory Usage (%)')
        ax.set_title('Memory Utilization')
        ax.legend()
        ax.grid(True, alpha=0.3)
        
        # 6. Gradient Norm
        ax = self.axes['gradient_norm']
        if self.monitor.metrics['gradient_norm']:
            ax.plot(epochs, self.monitor.metrics['gradient_norm'], 'brown', marker='o', linewidth=2)
        ax.set_xlabel('Epoch')
        ax.set_ylabel('Gradient Norm')
        ax.set_title('Gradient Norm')
        ax.grid(True, alpha=0.3)
        ax.set_yscale('log')
        
        # 7. On-Target Correlation
        ax = self.axes['on_target_corr']
        ax.plot(epochs, self.monitor.metrics['on_target_scc'], 'b-o', label='SCC', linewidth=2)
        ax.plot(epochs, self.monitor.metrics['on_target_pcc'], 'g-s', label='PCC', linewidth=2)
        ax.set_xlabel('Epoch')
        ax.set_ylabel('Correlation')
        ax.set_title('On-Target Correlations')
        ax.legend()
        ax.grid(True, alpha=0.3)
        ax.set_ylim([-1, 1])
        
        # 8. Off-Target Metrics
        ax = self.axes['off_target_metrics']
        ax.plot(epochs, self.monitor.metrics['off_target_auroc'], 'r-o', label='AUROC', linewidth=2)
        ax.plot(epochs, self.monitor.metrics['off_target_auprc'], 'purple', marker='s', label='AUPRC', linewidth=2)
        ax.set_xlabel('Epoch')
        ax.set_ylabel('Score')
        ax.set_title('Off-Target Metrics')
        ax.legend()
        ax.grid(True, alpha=0.3)
        ax.set_ylim([0, 1])
        
        # 9. Alerts
        ax = self.axes['alerts']
        ax.axis('off')
        alerts = self.monitor.check_for_issues()
        summary = self.monitor.get_summary()
        
        text = "📊 STATUS\n" + "="*30 + "\n"
        if summary:
            text += f"Epochs: {summary['total_epochs']}\n"
            text += f"Best: Epoch {summary['best_epoch']}\n"
            text += f"Loss: {summary['current_val_loss']:.6f}\n"
            text += f"No improve: {summary['epochs_since_improvement']}\n"
        
        if alerts:
            text += "\n🚨 ALERTS\n" + "="*30 + "\n"
            for alert in alerts[:5]:  # Show top 5 alerts
                text += alert + "\n"
        else:
            text += "\n✅ No issues\n"
        
        ax.text(0.05, 0.95, text, transform=ax.transAxes, fontsize=10,
                verticalalignment='top', fontfamily='monospace',
                bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
    
    def save_snapshot(self) -> None:
        """Save current dashboard as image"""
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filepath = self.save_dir / f'dashboard_{timestamp}.png'
        self.fig.savefig(filepath, dpi=100, bbox_inches='tight')
        logger.info(f"Dashboard snapshot saved: {filepath}")


def create_dash_app(monitor: TrainingMonitor) -> Optional[dash.Dash]:
    """
    Create Plotly Dash web application for monitoring
    
    Args:
        monitor: TrainingMonitor instance
    
    Returns:
        Dash app instance or None if Dash not available
    """
    if not DASH_AVAILABLE:
        logger.warning("Dash not available. Install with: pip install dash plotly")
        return None
    
    app = dash.Dash(__name__)
    
    app.layout = html.Div([
        html.Div([
            html.H1("CRISPR-UniPredict Training Monitor", style={'textAlign': 'center', 'marginBottom': 30}),
            dcc.Interval(id='interval-component', interval=10*1000, n_intervals=0)
        ]),
        
        html.Div([
            html.Div([
                html.Div(id='status-summary', style={'padding': '20px', 'backgroundColor': '#f0f0f0', 'borderRadius': '5px'})
            ], style={'marginBottom': '20px'}),
            
            html.Div([
                html.Div([
                    dcc.Graph(id='loss-plot')
                ], style={'width': '48%', 'display': 'inline-block', 'marginRight': '2%'}),
                
                html.Div([
                    dcc.Graph(id='metrics-plot')
                ], style={'width': '48%', 'display': 'inline-block'}),
            ], style={'marginBottom': '20px'}),
            
            html.Div([
                html.Div([
                    dcc.Graph(id='gpu-plot')
                ], style={'width': '48%', 'display': 'inline-block', 'marginRight': '2%'}),
                
                html.Div([
                    dcc.Graph(id='memory-plot')
                ], style={'width': '48%', 'display': 'inline-block'}),
            ], style={'marginBottom': '20px'}),
            
            html.Div([
                html.Div(id='alerts-div', style={'padding': '20px', 'backgroundColor': '#fff3cd', 'borderRadius': '5px'})
            ])
        ], style={'padding': '20px'})
    ])
    
    @callback(
        [Output('status-summary', 'children'),
         Output('loss-plot', 'figure'),
         Output('metrics-plot', 'figure'),
         Output('gpu-plot', 'figure'),
         Output('memory-plot', 'figure'),
         Output('alerts-div', 'children')],
        Input('interval-component', 'n_intervals')
    )
    def update_dashboard(n):
        monitor.load_metrics()
        summary = monitor.get_summary()
        alerts = monitor.check_for_issues()
        system_metrics = monitor.get_system_metrics()
        
        # Status summary
        status_text = html.Div([
            html.H3("Training Status"),
            html.P(f"Epochs: {summary.get('total_epochs', 0)} | "
                   f"Best Loss: {summary.get('best_val_loss', 'N/A')} @ Epoch {summary.get('best_epoch', 'N/A')} | "
                   f"Current Loss: {summary.get('current_val_loss', 'N/A')} | "
                   f"No Improvement: {summary.get('epochs_since_improvement', 0)} epochs")
        ])
        
        epochs = monitor.metrics['epochs']
        
        # Loss plot
        loss_fig = go.Figure()
        loss_fig.add_trace(go.Scatter(x=epochs, y=monitor.metrics['train_loss'], mode='lines+markers', name='Train Loss'))
        loss_fig.add_trace(go.Scatter(x=epochs, y=monitor.metrics['val_loss'], mode='lines+markers', name='Val Loss'))
        loss_fig.add_vline(x=summary.get('best_epoch', 0), line_dash="dash", line_color="green", annotation_text="Best")
        loss_fig.update_layout(title='Training Loss', xaxis_title='Epoch', yaxis_title='Loss')
        
        # Metrics plot
        metrics_fig = go.Figure()
        metrics_fig.add_trace(go.Scatter(x=epochs, y=monitor.metrics['on_target_scc'], mode='lines+markers', name='SCC'))
        metrics_fig.add_trace(go.Scatter(x=epochs, y=monitor.metrics['on_target_pcc'], mode='lines+markers', name='PCC'))
        metrics_fig.update_layout(title='On-Target Validation Metrics', xaxis_title='Epoch', yaxis_title='Correlation')
        
        # GPU plot
        gpu_fig = go.Figure()
        if monitor.metrics['gpu_util']:
            gpu_fig.add_trace(go.Scatter(x=epochs, y=monitor.metrics['gpu_util'], mode='lines+markers', name='GPU Util %'))
        gpu_fig.update_layout(title='GPU Utilization', xaxis_title='Epoch', yaxis_title='GPU %', yaxis_range=[0, 100])
        
        # Memory plot
        mem_fig = go.Figure()
        if monitor.metrics['memory_util']:
            mem_fig.add_trace(go.Scatter(x=epochs, y=monitor.metrics['memory_util'], mode='lines+markers', name='Memory %'))
        mem_fig.add_hline(y=90, line_dash="dash", line_color="red", annotation_text="OOM Risk")
        mem_fig.update_layout(title='Memory Utilization', xaxis_title='Epoch', yaxis_title='Memory %', yaxis_range=[0, 100])
        
        # Alerts
        alerts_text = html.Div([
            html.H3("System Alerts"),
            html.P(f"CPU: {system_metrics['cpu_percent']:.1f}% | "
                   f"RAM: {system_metrics['memory_percent']:.1f}% | "
                   f"GPU: {system_metrics['gpu_util']:.1f}%"),
            html.Ul([html.Li(alert) for alert in alerts]) if alerts else html.P("✅ No issues detected")
        ])
        
        return status_text, loss_fig, metrics_fig, gpu_fig, mem_fig, alerts_text
    
    return app


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(description='Real-time Training Monitor for CRISPR-UniPredict')
    parser.add_argument('--log_dir', type=str, required=True, help='Training log directory')
    parser.add_argument('--refresh_rate', type=int, default=10, help='Update frequency in seconds')
    parser.add_argument('--mode', type=str, default='console', choices=['console', 'matplotlib', 'dash'],
                       help='Monitoring mode')
    parser.add_argument('--save_snapshots', action='store_true', help='Save dashboard snapshots')
    parser.add_argument('--port', type=int, default=8050, help='Port for Dash app')
    
    args = parser.parse_args()
    
    # Setup logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Initialize monitor
    monitor = TrainingMonitor(args.log_dir, args.refresh_rate)
    
    if args.mode == 'console':
        # Console monitoring
        print(f"Starting console monitor for {args.log_dir}")
        print(f"Refresh rate: {args.refresh_rate} seconds")
        print("Press Ctrl+C to stop\n")
        
        try:
            while True:
                monitor.print_status()
                time.sleep(args.refresh_rate)
        except KeyboardInterrupt:
            print("\nMonitoring stopped")
    
    elif args.mode == 'matplotlib':
        # Matplotlib dashboard
        print(f"Starting matplotlib dashboard for {args.log_dir}")
        dashboard = MatplotlibDashboard(monitor, save_dir=args.log_dir / 'dashboard_snapshots' if args.save_snapshots else None)
        
        def update_loop():
            while True:
                dashboard.update_plots()
                if args.save_snapshots:
                    dashboard.save_snapshot()
                plt.pause(args.refresh_rate)
        
        try:
            update_loop()
        except KeyboardInterrupt:
            print("\nDashboard closed")
            plt.close('all')
    
    elif args.mode == 'dash':
        # Plotly Dash web app
        app = create_dash_app(monitor)
        if app:
            print(f"Starting Dash app on http://localhost:{args.port}")
            print("Press Ctrl+C to stop\n")
            app.run_server(debug=False, port=args.port)
        else:
            print("Dash not available. Falling back to console mode.")
            monitor.print_status()


if __name__ == '__main__':
    main()
