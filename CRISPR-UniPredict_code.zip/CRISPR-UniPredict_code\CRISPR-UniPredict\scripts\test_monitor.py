"""
Test script for monitor_training.py
Generates sample training data to test the monitoring dashboard
"""

import json
import sys
import time
from pathlib import Path
from datetime import datetime
import numpy as np

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))


def generate_sample_training_data(log_dir: str, num_epochs: int = 20, num_batches: int = 100):
    """
    Generate sample training data for testing the monitor
    
    Args:
        log_dir: Directory to save training data
        num_epochs: Number of epochs to simulate
        num_batches: Number of batches per epoch
    """
    log_path = Path(log_dir)
    log_path.mkdir(parents=True, exist_ok=True)
    
    print(f"Generating sample training data in {log_dir}")
    print(f"Epochs: {num_epochs}, Batches per epoch: {num_batches}")
    
    # Generate training history
    train_history = []
    val_history = []
    
    # Simulate training progression
    for epoch in range(num_epochs):
        # Training metrics (decreasing loss with some noise)
        train_loss = 0.5 * np.exp(-epoch / 5) + 0.1 * np.random.randn() * 0.01
        on_target_loss = 0.3 * np.exp(-epoch / 5) + 0.05 * np.random.randn() * 0.01
        off_target_loss = 0.2 * np.exp(-epoch / 5) + 0.05 * np.random.randn() * 0.01
        
        train_metrics = {
            'total_loss': float(max(0.01, train_loss)),
            'on_target_loss': float(max(0.01, on_target_loss)),
            'off_target_loss': float(max(0.01, off_target_loss)),
            'batch_count': num_batches
        }
        train_history.append(train_metrics)
        
        # Validation metrics (improving with some noise)
        val_loss = 0.45 * np.exp(-epoch / 5) + 0.12 * np.random.randn() * 0.01
        on_target_loss = 0.27 * np.exp(-epoch / 5) + 0.06 * np.random.randn() * 0.01
        off_target_loss = 0.18 * np.exp(-epoch / 5) + 0.06 * np.random.randn() * 0.01
        
        # Correlation metrics (improving)
        scc = 0.3 + 0.6 * (1 - np.exp(-epoch / 3)) + 0.02 * np.random.randn()
        pcc = 0.35 + 0.6 * (1 - np.exp(-epoch / 3)) + 0.02 * np.random.randn()
        
        # Classification metrics (improving)
        auroc = 0.5 + 0.4 * (1 - np.exp(-epoch / 3)) + 0.02 * np.random.randn()
        auprc = 0.45 + 0.4 * (1 - np.exp(-epoch / 3)) + 0.02 * np.random.randn()
        
        val_metrics = {
            'total_loss': float(max(0.01, val_loss)),
            'on_target_loss': float(max(0.01, on_target_loss)),
            'off_target_loss': float(max(0.01, off_target_loss)),
            'on_target_spearman': float(np.clip(scc, -1, 1)),
            'on_target_pearson': float(np.clip(pcc, -1, 1)),
            'off_target_auroc': float(np.clip(auroc, 0, 1)),
            'off_target_auprc': float(np.clip(auprc, 0, 1)),
            'batch_count': num_batches // 2
        }
        val_history.append(val_metrics)
        
        print(f"  Epoch {epoch + 1}/{num_epochs}: "
              f"Train Loss={train_metrics['total_loss']:.4f}, "
              f"Val Loss={val_metrics['total_loss']:.4f}, "
              f"SCC={val_metrics['on_target_spearman']:.4f}")
    
    # Save training history
    history = {
        'train': train_history,
        'val': val_history
    }
    
    history_file = log_path / 'training_history.json'
    with open(history_file, 'w') as f:
        json.dump(history, f, indent=2)
    
    print(f"\n✓ Saved training history to {history_file}")
    
    # Save sample config
    config = {
        'model': {
            'type': 'CRISPRUniPredict',
            'sequence_length': 23,
            'msc_channels': 64,
            'mhsa_embedding': 256,
            'bigru_hidden': 128,
            'embedding_dim': 128,
            'hidden_dim': 256,
            'dropout': 0.35
        },
        'training': {
            'epochs': num_epochs,
            'batch_size': 32,
            'learning_rate_encoder': 0.001,
            'learning_rate_heads': 0.001,
            'optimizer': 'AdamW',
            'weight_decay': 0.0001,
            'gradient_clip': 1.0
        },
        'validation': {
            'early_stopping_patience': 10
        },
        'device': {
            'use_cuda': True,
            'mixed_precision': True
        }
    }
    
    config_file = log_path / 'config.json'
    with open(config_file, 'w') as f:
        json.dump(config, f, indent=2)
    
    print(f"✓ Saved config to {config_file}")
    
    # Save training log
    log_file = log_path / 'training.log'
    with open(log_file, 'w') as f:
        f.write(f"Training started at {datetime.now()}\n")
        f.write(f"Total epochs: {num_epochs}\n")
        f.write(f"Batches per epoch: {num_batches}\n")
        f.write("\n")
        for epoch, (train_m, val_m) in enumerate(zip(train_history, val_history)):
            f.write(
                f"Epoch {epoch + 1}/{num_epochs} - "
                f"Train Loss: {train_m['total_loss']:.6f}, "
                f"Val Loss: {val_m['total_loss']:.6f}\n"
            )
    
    print(f"✓ Saved training log to {log_file}")
    
    return log_path


def simulate_live_training(log_dir: str, num_epochs: int = 10, epoch_duration: int = 5):
    """
    Simulate live training by gradually adding epochs to training history
    
    Args:
        log_dir: Directory to save training data
        num_epochs: Number of epochs to simulate
        epoch_duration: Duration of each epoch in seconds
    """
    log_path = Path(log_dir)
    log_path.mkdir(parents=True, exist_ok=True)
    
    print(f"Simulating live training in {log_dir}")
    print(f"Epochs: {num_epochs}, Duration per epoch: {epoch_duration}s")
    print("Press Ctrl+C to stop\n")
    
    history = {'train': [], 'val': []}
    history_file = log_path / 'training_history.json'
    
    try:
        for epoch in range(num_epochs):
            # Simulate training time
            print(f"Epoch {epoch + 1}/{num_epochs}: ", end='', flush=True)
            for i in range(epoch_duration):
                print(".", end='', flush=True)
                time.sleep(1)
            print(" Done")
            
            # Generate metrics
            train_loss = 0.5 * np.exp(-epoch / 3) + 0.01 * np.random.randn()
            on_target_loss = 0.3 * np.exp(-epoch / 3) + 0.005 * np.random.randn()
            off_target_loss = 0.2 * np.exp(-epoch / 3) + 0.005 * np.random.randn()
            
            train_metrics = {
                'total_loss': float(max(0.01, train_loss)),
                'on_target_loss': float(max(0.01, on_target_loss)),
                'off_target_loss': float(max(0.01, off_target_loss)),
                'batch_count': 100
            }
            history['train'].append(train_metrics)
            
            # Validation metrics
            val_loss = 0.45 * np.exp(-epoch / 3) + 0.015 * np.random.randn()
            on_target_loss = 0.27 * np.exp(-epoch / 3) + 0.008 * np.random.randn()
            off_target_loss = 0.18 * np.exp(-epoch / 3) + 0.008 * np.random.randn()
            
            scc = 0.3 + 0.6 * (1 - np.exp(-epoch / 2)) + 0.03 * np.random.randn()
            pcc = 0.35 + 0.6 * (1 - np.exp(-epoch / 2)) + 0.03 * np.random.randn()
            auroc = 0.5 + 0.4 * (1 - np.exp(-epoch / 2)) + 0.03 * np.random.randn()
            auprc = 0.45 + 0.4 * (1 - np.exp(-epoch / 2)) + 0.03 * np.random.randn()
            
            val_metrics = {
                'total_loss': float(max(0.01, val_loss)),
                'on_target_loss': float(max(0.01, on_target_loss)),
                'off_target_loss': float(max(0.01, off_target_loss)),
                'on_target_spearman': float(np.clip(scc, -1, 1)),
                'on_target_pearson': float(np.clip(pcc, -1, 1)),
                'off_target_auroc': float(np.clip(auroc, 0, 1)),
                'off_target_auprc': float(np.clip(auprc, 0, 1)),
                'batch_count': 50
            }
            history['val'].append(val_metrics)
            
            # Save history
            with open(history_file, 'w') as f:
                json.dump(history, f, indent=2)
            
            print(f"  Train Loss: {train_metrics['total_loss']:.4f}, "
                  f"Val Loss: {val_metrics['total_loss']:.4f}, "
                  f"SCC: {val_metrics['on_target_spearman']:.4f}")
    
    except KeyboardInterrupt:
        print("\n\nSimulation stopped by user")
    
    print(f"\n✓ Simulation complete. Data saved to {log_path}")


def main():
    """Main entry point"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Test monitor_training.py with sample data')
    parser.add_argument('--log_dir', type=str, default='logs/test_monitor',
                       help='Log directory for test data')
    parser.add_argument('--mode', type=str, default='generate', choices=['generate', 'simulate'],
                       help='Test mode: generate (static) or simulate (live)')
    parser.add_argument('--epochs', type=int, default=20, help='Number of epochs')
    parser.add_argument('--epoch_duration', type=int, default=5, help='Duration per epoch (seconds)')
    
    args = parser.parse_args()
    
    if args.mode == 'generate':
        log_dir = generate_sample_training_data(args.log_dir, args.epochs)
        print(f"\n✓ Test data generated successfully!")
        print(f"\nTo test the monitor, run:")
        print(f"  python scripts/monitor_training.py --log_dir {log_dir} --mode console")
        print(f"  python scripts/monitor_training.py --log_dir {log_dir} --mode matplotlib")
        print(f"  python scripts/monitor_training.py --log_dir {log_dir} --mode dash")
    
    elif args.mode == 'simulate':
        log_dir = simulate_live_training(args.log_dir, args.epochs, args.epoch_duration)
        print(f"\nTo monitor in real-time, run in another terminal:")
        print(f"  python scripts/monitor_training.py --log_dir {log_dir} --mode console")


if __name__ == '__main__':
    main()
