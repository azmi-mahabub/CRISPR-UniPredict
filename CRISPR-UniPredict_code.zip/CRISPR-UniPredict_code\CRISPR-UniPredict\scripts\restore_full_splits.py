"""
Restore Full Train/Val/Test Splits from Combined Data
Recreates the original 3.4M sample splits from combined_on_target.csv and combined_off_target.csv
"""

import sys
from pathlib import Path
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
import logging

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))


def restore_full_splits():
    """Restore full train/val/test splits from combined data"""
    
    project_root = Path(__file__).parent.parent
    combined_dir = project_root / "data" / "processed" / "combined"
    
    logger.info("\n" + "="*80)
    logger.info("RESTORING FULL TRAIN/VAL/TEST SPLITS")
    logger.info("="*80)
    
    # Load combined data
    logger.info("\nLoading combined data files...")
    
    on_target_path = combined_dir / "combined_on_target.csv"
    off_target_path = combined_dir / "combined_off_target.csv"
    
    if not on_target_path.exists():
        logger.error(f"File not found: {on_target_path}")
        return False
    
    if not off_target_path.exists():
        logger.error(f"File not found: {off_target_path}")
        return False
    
    logger.info(f"Loading on-target data...")
    on_target_df = pd.read_csv(on_target_path)
    logger.info(f"  ✓ Loaded: {len(on_target_df):,} samples")
    
    logger.info(f"Loading off-target data...")
    off_target_df = pd.read_csv(off_target_path)
    logger.info(f"  ✓ Loaded: {len(off_target_df):,} samples")
    
    # Combine data
    logger.info(f"\nCombining datasets...")
    combined_df = pd.concat([on_target_df, off_target_df], ignore_index=True)
    logger.info(f"  ✓ Combined: {len(combined_df):,} samples")
    
    # Create stratified splits (80/10/10)
    logger.info(f"\nCreating stratified train/val/test splits (80/10/10)...")
    
    # First split: train (80%) and temp (20%)
    train_df, temp_df = train_test_split(
        combined_df,
        test_size=0.20,
        random_state=42,
        stratify=combined_df['task_type']
    )
    
    # Second split: val (10%) and test (10%)
    val_df, test_df = train_test_split(
        temp_df,
        test_size=0.50,
        random_state=42,
        stratify=temp_df['task_type']
    )
    
    logger.info(f"  Train: {len(train_df):,} ({len(train_df)/len(combined_df)*100:.1f}%)")
    logger.info(f"  Val:   {len(val_df):,} ({len(val_df)/len(combined_df)*100:.1f}%)")
    logger.info(f"  Test:  {len(test_df):,} ({len(test_df)/len(combined_df)*100:.1f}%)")
    
    # Verify stratification
    logger.info(f"\nVerifying stratification...")
    
    for split_name, split_df in [("Train", train_df), ("Val", val_df), ("Test", test_df)]:
        task_dist = split_df['task_type'].value_counts()
        on_target_pct = task_dist.get('on_target', 0) / len(split_df) * 100
        off_target_pct = task_dist.get('off_target', 0) / len(split_df) * 100
        logger.info(f"  {split_name}: On-target {on_target_pct:.2f}%, Off-target {off_target_pct:.2f}%")
    
    # Save splits
    logger.info(f"\nSaving splits...")
    
    train_path = combined_dir / "train.csv"
    val_path = combined_dir / "val.csv"
    test_path = combined_dir / "test.csv"
    
    train_df.to_csv(train_path, index=False)
    logger.info(f"  ✓ Saved: {train_path} ({len(train_df):,} samples, {train_path.stat().st_size / (1024**2):.2f} MB)")
    
    val_df.to_csv(val_path, index=False)
    logger.info(f"  ✓ Saved: {val_path} ({len(val_df):,} samples, {val_path.stat().st_size / (1024**2):.2f} MB)")
    
    test_df.to_csv(test_path, index=False)
    logger.info(f"  ✓ Saved: {test_path} ({len(test_df):,} samples, {test_path.stat().st_size / (1024**2):.2f} MB)")
    
    # Print summary
    logger.info(f"\n" + "="*80)
    logger.info("RESTORATION SUMMARY")
    logger.info("="*80)
    
    logger.info(f"\nDataset Overview:")
    logger.info(f"  Total samples: {len(combined_df):,}")
    logger.info(f"  On-target: {len(on_target_df):,} ({len(on_target_df)/len(combined_df)*100:.2f}%)")
    logger.info(f"  Off-target: {len(off_target_df):,} ({len(off_target_df)/len(combined_df)*100:.2f}%)")
    
    logger.info(f"\nTrain/Val/Test Split:")
    logger.info(f"  Train: {len(train_df):,} (80.0%)")
    logger.info(f"  Val: {len(val_df):,} (10.0%)")
    logger.info(f"  Test: {len(test_df):,} (10.0%)")
    
    logger.info(f"\nTask Distribution:")
    for split_name, split_df in [("Overall", combined_df), ("Train", train_df), ("Val", val_df), ("Test", test_df)]:
        task_counts = split_df['task_type'].value_counts()
        logger.info(f"\n  {split_name}:")
        for task, count in task_counts.items():
            logger.info(f"    {task}: {count:,} ({count/len(split_df)*100:.2f}%)")
    
    logger.info(f"\n" + "="*80)
    logger.info("✓ RESTORATION COMPLETE")
    logger.info("="*80)
    
    return True


if __name__ == "__main__":
    success = restore_full_splits()
    sys.exit(0 if success else 1)
