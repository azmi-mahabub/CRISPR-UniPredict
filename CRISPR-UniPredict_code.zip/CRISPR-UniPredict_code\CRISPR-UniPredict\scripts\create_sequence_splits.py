"""
Sequence-Level Train/Val/Test Split for On-Target Data
=======================================================
Fixes data leakage: same sgRNA sequence cannot appear in both
train and val/test sets.

Off-target is already leak-free (pair-level unique) so we keep
it as-is and just rebuild the combined CSVs.

Output files (saved alongside existing splits):
  data/processed/combined/train_seqsplit.csv
  data/processed/combined/val_seqsplit.csv
  data/processed/combined/test_seqsplit.csv
"""

import sys
from pathlib import Path
import pandas as pd
import numpy as np

_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_ROOT))

DATA_DIR = _ROOT / 'data' / 'processed' / 'combined'

TRAIN_FRAC = 0.80
VAL_FRAC   = 0.10
TEST_FRAC  = 0.10
SEED       = 42


def sequence_level_split(df: pd.DataFrame, seed: int = SEED):
    """
    Split on-target data so each unique sgRNA sequence lands in
    exactly one of train / val / test.

    Strategy:
      1. Collect all unique sequences.
      2. Shuffle sequences (seeded).
      3. Assign 80/10/10 of SEQUENCES to train/val/test.
      4. All rows for a sequence go to the same split.
    """
    rng = np.random.default_rng(seed)
    unique_seqs = df['sgrna_sequence'].str.upper().unique()
    rng.shuffle(unique_seqs)

    n = len(unique_seqs)
    n_train = int(n * TRAIN_FRAC)
    n_val   = int(n * VAL_FRAC)

    train_seqs = set(unique_seqs[:n_train])
    val_seqs   = set(unique_seqs[n_train : n_train + n_val])
    test_seqs  = set(unique_seqs[n_train + n_val :])

    upper = df['sgrna_sequence'].str.upper()
    train_df = df[upper.isin(train_seqs)].copy()
    val_df   = df[upper.isin(val_seqs)].copy()
    test_df  = df[upper.isin(test_seqs)].copy()

    return train_df, val_df, test_df


def verify_no_leakage(train_df, val_df, test_df):
    tr = set(train_df['sgrna_sequence'].str.upper())
    va = set(val_df['sgrna_sequence'].str.upper())
    te = set(test_df['sgrna_sequence'].str.upper())
    tv = tr & va
    tt = tr & te
    vt = va & te
    assert len(tv) == 0, f"Train-Val overlap: {len(tv)}"
    assert len(tt) == 0, f"Train-Test overlap: {len(tt)}"
    assert len(vt) == 0, f"Val-Test overlap: {len(vt)}"
    print("  Leakage check: PASSED (0 overlapping sequences)")


def main():
    print("=" * 60)
    print("Sequence-Level Split Creator")
    print("=" * 60)

    # ── Load existing splits and reconstruct full dataset ──────────
    print("\nLoading existing splits...")
    parts = []
    for split in ['train', 'val', 'test']:
        p = DATA_DIR / f'{split}.csv'
        df = pd.read_csv(p)
        df.columns = [c.lower() for c in df.columns]
        parts.append(df)
        print(f"  {split}.csv: {len(df):,} rows")

    full = pd.concat(parts, ignore_index=True)
    print(f"  Total: {len(full):,} rows")

    on_target  = full[full['task_type'] == 'on_target'].copy()
    off_target = full[full['task_type'] == 'off_target'].copy()

    print(f"\nOn-target:  {len(on_target):,} rows | "
          f"{on_target['sgrna_sequence'].str.upper().nunique():,} unique sequences")
    print(f"Off-target: {len(off_target):,} rows")

    # ── Sequence-level split for on-target ─────────────────────────
    print("\nCreating sequence-level split for on-target...")
    tr_on, va_on, te_on = sequence_level_split(on_target)
    verify_no_leakage(tr_on, va_on, te_on)

    print(f"  Train: {len(tr_on):,} rows  "
          f"({tr_on['sgrna_sequence'].nunique():,} unique seqs)")
    print(f"  Val:   {len(va_on):,} rows  "
          f"({va_on['sgrna_sequence'].nunique():,} unique seqs)")
    print(f"  Test:  {len(te_on):,} rows  "
          f"({te_on['sgrna_sequence'].nunique():,} unique seqs)")

    # ── Off-target: keep original row-level split (0% leakage confirmed) ──
    print("\nOff-target: reusing existing splits (pair-level leakage = 0%)...")
    existing = {}
    for split in ['train', 'val', 'test']:
        df = pd.read_csv(DATA_DIR / f'{split}.csv')
        df.columns = [c.lower() for c in df.columns]
        existing[split] = df[df['task_type'] == 'off_target'].copy()

    tr_off = existing['train']
    va_off = existing['val']
    te_off = existing['test']
    print(f"  Train: {len(tr_off):,} rows")
    print(f"  Val:   {len(va_off):,} rows")
    print(f"  Test:  {len(te_off):,} rows")

    # ── Combine and save ───────────────────────────────────────────
    print("\nCombining and saving...")
    train_final = pd.concat([tr_on, tr_off], ignore_index=True).sample(
        frac=1, random_state=SEED).reset_index(drop=True)
    val_final   = pd.concat([va_on, va_off], ignore_index=True).reset_index(drop=True)
    test_final  = pd.concat([te_on, te_off], ignore_index=True).reset_index(drop=True)

    for name, df in [('train_seqsplit', train_final),
                     ('val_seqsplit',   val_final),
                     ('test_seqsplit',  test_final)]:
        path = DATA_DIR / f'{name}.csv'
        df.to_csv(path, index=False)
        size_mb = path.stat().st_size / 1024 / 1024
        print(f"  Saved {name}.csv: {len(df):,} rows ({size_mb:.1f} MB)")

    # ── Final summary ──────────────────────────────────────────────
    print("\n" + "=" * 60)
    print("SUMMARY")
    print("=" * 60)
    print(f"{'Split':<12} {'Total':>10} {'On-target':>12} {'Off-target':>12}")
    print("-" * 50)
    for name, df in [('train', train_final), ('val', val_final), ('test', test_final)]:
        on  = (df['task_type'] == 'on_target').sum()
        off = (df['task_type'] == 'off_target').sum()
        print(f"{name:<12} {len(df):>10,} {on:>12,} {off:>12,}")

    print("\nDone. Use *_seqsplit.csv files for training.")
    print("=" * 60)


if __name__ == '__main__':
    main()
