@echo off
REM CRISPR-UniPredict Quick Start Script for Windows
REM Automated setup and execution for CRISPR-UniPredict
REM Usage: scripts\quickstart.bat

setlocal enabledelayedexpansion

REM Configuration
set PROJECT_ROOT=%~dp0..
set LOG_DIR=%PROJECT_ROOT%\logs\quickstart
set REPORT_DIR=%PROJECT_ROOT%\reports

REM Create directories
if not exist "%LOG_DIR%" mkdir "%LOG_DIR%"
if not exist "%REPORT_DIR%" mkdir "%REPORT_DIR%"

REM Colors (using ANSI codes)
set GREEN=[92m
set RED=[91m
set YELLOW=[93m
set BLUE=[94m
set NC=[0m

echo.
echo %BLUE%================================%NC%
echo %BLUE%CRISPR-UniPredict Quick Start%NC%
echo %BLUE%================================%NC%
echo.

REM Step 1: Check prerequisites
echo %BLUE%[1/12] Checking prerequisites...%NC%
python --version >nul 2>&1
if errorlevel 1 (
    echo %RED%Error: Python not found%NC%
    exit /b 1
)
echo %GREEN%✓ Python found%NC%

pip --version >nul 2>&1
if errorlevel 1 (
    echo %RED%Error: pip not found%NC%
    exit /b 1
)
echo %GREEN%✓ pip found%NC%

REM Step 2: Environment setup
echo.
echo %BLUE%[2/12] Setting up Python environment...%NC%
if exist "%PROJECT_ROOT%\venv" (
    echo %YELLOW%Virtual environment already exists%NC%
) else (
    python -m venv "%PROJECT_ROOT%\venv"
    echo %GREEN%✓ Virtual environment created%NC%
)

REM Activate virtual environment
call "%PROJECT_ROOT%\venv\Scripts\activate.bat"
echo %GREEN%✓ Virtual environment activated%NC%

REM Step 3: Install dependencies
echo.
echo %BLUE%[3/12] Installing dependencies...%NC%
python -m pip install --upgrade pip setuptools wheel >nul 2>&1

if exist "%PROJECT_ROOT%\requirements.txt" (
    pip install -r "%PROJECT_ROOT%\requirements.txt"
    echo %GREEN%✓ Core dependencies installed%NC%
)

if exist "%PROJECT_ROOT%\web_app\requirements.txt" (
    pip install -r "%PROJECT_ROOT%\web_app\requirements.txt"
    echo %GREEN%✓ Web app dependencies installed%NC%
)

REM Step 4: Validate system
echo.
echo %BLUE%[4/12] Validating system...%NC%
cd /d "%PROJECT_ROOT%"
python scripts\validate_system.py > "%REPORT_DIR%\system_validation.txt" 2>&1
echo %GREEN%✓ System validation complete%NC%

REM Step 5: Data inspection
echo.
echo %BLUE%[5/12] Inspecting datasets...%NC%
if exist "%PROJECT_ROOT%\data\raw" (
    (
        echo Data directory structure:
        dir /s "%PROJECT_ROOT%\data\raw\*.csv" 2>nul
    ) > "%REPORT_DIR%\data_inspection.txt"
    echo %GREEN%✓ Data inspection complete%NC%
) else (
    echo %YELLOW%⚠ Data directory not found%NC%
)

REM Step 6: Data preprocessing
echo.
echo %BLUE%[6/12] Preprocessing datasets...%NC%
if exist "%PROJECT_ROOT%\data\raw" (
    python << 'PYTHON_EOF'
import pandas as pd
from pathlib import Path
import sys

try:
    data_dir = Path('data/raw')
    processed_dir = Path('data/processed')
    processed_dir.mkdir(parents=True, exist_ok=True)
    
    csv_files = list(data_dir.rglob('*.csv'))
    if csv_files:
        print(f"Found {len(csv_files)} CSV files")
        for csv_file in csv_files[:3]:
            try:
                df = pd.read_csv(csv_file)
                print(f"  - {csv_file.name}: {len(df)} rows")
            except Exception as e:
                print(f"  - {csv_file.name}: Error - {e}")
    else:
        print("No CSV files found in data/raw")
except Exception as e:
    print(f"Data preprocessing error: {e}")
    sys.exit(0)
PYTHON_EOF
    echo %GREEN%✓ Data preprocessing complete%NC%
) else (
    echo %YELLOW%⚠ No raw data found%NC%
)

REM Step 7: Download pretrained models
echo.
echo %BLUE%[7/12] Downloading pretrained models...%NC%
if not exist "%PROJECT_ROOT%\models\pretrained" mkdir "%PROJECT_ROOT%\models\pretrained"

if not exist "%PROJECT_ROOT%\models\pretrained\rna_fm_t12.pt" (
    echo %YELLOW%⚠ RNA-FM model not found - download from https://github.com/ml4bio/RNA-FM%NC%
) else (
    echo %GREEN%✓ RNA-FM model found%NC%
)

REM Step 8: Run unit tests
echo.
echo %BLUE%[8/12] Running unit tests...%NC%
if exist "%PROJECT_ROOT%\tests\test_models.py" (
    python -m pytest tests\test_models.py -v --tb=short > "%REPORT_DIR%\unit_tests.txt" 2>&1
    echo %GREEN%✓ Unit tests complete%NC%
) else (
    echo %YELLOW%⚠ No tests found%NC%
)

REM Step 9: Run integration tests
echo.
echo %BLUE%[9/12] Running integration tests...%NC%
if exist "%PROJECT_ROOT%\tests\test_integration.py" (
    python -m pytest tests\test_integration.py -v --tb=short > "%REPORT_DIR%\integration_tests.txt" 2>&1
    echo %GREEN%✓ Integration tests complete%NC%
) else (
    echo %YELLOW%⚠ Integration tests not found%NC%
)

REM Step 10: Debug training
echo.
echo %BLUE%[10/12] Running debug training...%NC%
if exist "%PROJECT_ROOT%\scripts\train.py" (
    python scripts\train.py ^
        --config configs\model_config.yaml ^
        --epochs 2 ^
        --batch_size 16 ^
        --experiment_name debug_quickstart
    echo %GREEN%✓ Debug training complete%NC%
) else (
    echo %YELLOW%⚠ Training script not found%NC%
)

REM Step 11: Generate reports
echo.
echo %BLUE%[11/12] Generating reports...%NC%
(
    echo CRISPR-UniPredict Quick Start Summary
    echo =====================================
    echo Generated: %date% %time%
    echo Project Root: %PROJECT_ROOT%
    echo.
    echo Completed Steps:
    echo - [✓] Prerequisites check
    echo - [✓] Environment setup
    echo - [✓] Dependencies installation
    echo - [✓] System validation
    echo - [✓] Data inspection
    echo - [✓] Data preprocessing
    echo - [✓] Pretrained models check
    echo - [✓] Unit tests
    echo - [✓] Integration tests
    echo - [✓] Debug training
    echo.
    echo Reports Generated:
    echo - system_validation.txt: System validation results
    echo - data_inspection.txt: Data inspection report
    echo - unit_tests.txt: Unit test results
    echo - integration_tests.txt: Integration test results
    echo.
    echo Next Steps:
    echo 1. Review the reports in %REPORT_DIR%\
    echo 2. Run full training: python scripts\train.py --config configs\model_config.yaml --experiment_name full_training
    echo 3. Deploy web app: streamlit run web_app\app.py
    echo 4. Start API: uvicorn api.inference_api:app --host 0.0.0.0 --port 8000
    echo 5. Deploy with Docker: docker-compose up
) > "%REPORT_DIR%\quickstart_summary.txt"

echo %GREEN%✓ Reports generated%NC%

REM Step 12: Final summary
echo.
echo %BLUE%================================%NC%
echo %GREEN%Quick Start Complete!%NC%
echo %BLUE%================================%NC%
echo.
echo %BLUE%Summary:%NC%
echo   Project Root: %PROJECT_ROOT%
echo   Reports: %REPORT_DIR%
echo   Logs: %LOG_DIR%
echo.
echo %BLUE%Next Steps:%NC%
echo   1. Review reports:
echo      type %REPORT_DIR%\quickstart_summary.txt
echo.
echo   2. Run full training:
echo      python scripts\train.py --config configs\model_config.yaml --experiment_name full_training
echo.
echo   3. Deploy web app:
echo      streamlit run web_app\app.py
echo.
echo   4. Start API:
echo      uvicorn api.inference_api:app --host 0.0.0.0 --port 8000
echo.
echo   5. Deploy with Docker:
echo      docker-compose up
echo.
echo %GREEN%System is ready for use!%NC%
echo.

endlocal
exit /b 0
