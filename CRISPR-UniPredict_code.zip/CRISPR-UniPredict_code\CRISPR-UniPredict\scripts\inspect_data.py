"""
Data Inspection Script for CRISPR-UniPredict
Scans and analyzes all datasets in data/raw/ directories
"""

import os
import sys
from pathlib import Path
import pandas as pd
import numpy as np
from datetime import datetime
from collections import defaultdict

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))


class DataInspector:
    """Inspect and analyze datasets"""
    
    def __init__(self, base_dir=None):
        """Initialize inspector"""
        if base_dir is None:
            base_dir = Path(__file__).parent.parent / "data" / "raw"
        
        self.base_dir = Path(base_dir)
        self.results = []
        self.summary = {
            'total_files': 0,
            'total_samples': 0,
            'datasets': {},
            'column_patterns': defaultdict(int),
            'sequence_columns': set(),
            'target_columns': set(),
            'errors': []
        }
    
    def detect_separator(self, file_path, sample_lines=5):
        """Detect CSV/TSV separator"""
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                sample = ''.join([f.readline() for _ in range(sample_lines)])
            
            # Check for common separators
            separators = {',': 0, '\t': 0, ';': 0, '|': 0}
            for sep in separators:
                separators[sep] = sample.count(sep)
            
            # Return separator with highest count
            return max(separators, key=separators.get)
        except Exception as e:
            return ','  # Default to comma
    
    def identify_column_type(self, col_name):
        """Identify column type based on name"""
        col_lower = col_name.lower()
        
        sequence_keywords = ['seq', 'rna', 'guide', 'grna', 'sgrna', 'target', 'dna']
        target_keywords = ['indel', 'efficiency', 'activity', 'label', 'off_target', 'offtarget', 'score', 'pred']
        
        col_type = []
        
        if any(keyword in col_lower for keyword in sequence_keywords):
            col_type.append('sequence')
        
        if any(keyword in col_lower for keyword in target_keywords):
            col_type.append('target')
        
        return col_type if col_type else ['other']
    
    def load_file(self, file_path):
        """Load CSV/TSV file with automatic separator detection"""
        try:
            separator = self.detect_separator(file_path)
            df = pd.read_csv(file_path, sep=separator, nrows=None)
            return df, separator
        except Exception as e:
            raise Exception(f"Error loading file: {str(e)}")
    
    def inspect_file(self, file_path):
        """Inspect a single file"""
        try:
            file_name = file_path.name
            file_size_mb = file_path.stat().st_size / (1024 * 1024)
            
            # Load file
            df, separator = self.load_file(file_path)
            
            # Get basic info
            rows, cols = df.shape
            column_names = list(df.columns)
            
            # Identify column types
            seq_cols = []
            target_cols = []
            
            for col in column_names:
                col_types = self.identify_column_type(col)
                if 'sequence' in col_types:
                    seq_cols.append(col)
                    self.summary['sequence_columns'].add(col)
                if 'target' in col_types:
                    target_cols.append(col)
                    self.summary['target_columns'].add(col)
            
            # Get first 3 rows
            first_rows = df.head(3)
            
            # Data types
            dtypes = df.dtypes.to_dict()
            
            # Statistics
            stats = {
                'numeric_cols': df.select_dtypes(include=[np.number]).columns.tolist(),
                'object_cols': df.select_dtypes(include=['object']).columns.tolist(),
                'missing_values': df.isnull().sum().to_dict()
            }
            
            result = {
                'file_name': file_name,
                'file_path': str(file_path),
                'file_size_mb': file_size_mb,
                'separator': separator,
                'rows': rows,
                'cols': cols,
                'column_names': column_names,
                'sequence_columns': seq_cols,
                'target_columns': target_cols,
                'first_rows': first_rows,
                'dtypes': dtypes,
                'stats': stats,
                'error': None
            }
            
            # Update summary
            self.summary['total_files'] += 1
            self.summary['total_samples'] += rows
            self.summary['datasets'][file_name] = {
                'rows': rows,
                'cols': cols,
                'size_mb': file_size_mb,
                'sequence_cols': seq_cols,
                'target_cols': target_cols
            }
            
            for col in column_names:
                self.summary['column_patterns'][col] += 1
            
            return result
            
        except Exception as e:
            error_msg = f"Error inspecting {file_path.name}: {str(e)}"
            self.summary['errors'].append(error_msg)
            return {
                'file_name': file_path.name,
                'file_path': str(file_path),
                'error': error_msg
            }
    
    def scan_directory(self):
        """Scan all data directories"""
        print("=" * 80)
        print("SCANNING DATA DIRECTORIES")
        print("=" * 80)
        
        # Define directories to scan
        directories = [
            self.base_dir / "crispr_hnn",
            self.base_dir / "cclmoff"
        ]
        
        for directory in directories:
            if not directory.exists():
                print(f"\n⚠ Directory not found: {directory}")
                continue
            
            print(f"\nScanning: {directory}")
            print("-" * 80)
            
            # Find all CSV/TSV files
            files = list(directory.glob("*.csv")) + list(directory.glob("*.tsv")) + list(directory.glob("*.txt"))
            
            if not files:
                print(f"  No data files found in {directory.name}/")
                continue
            
            print(f"  Found {len(files)} file(s)")
            
            for file_path in sorted(files):
                print(f"\n  Processing: {file_path.name}")
                result = self.inspect_file(file_path)
                
                if result.get('error'):
                    print(f"    ✗ {result['error']}")
                else:
                    print(f"    ✓ Shape: {result['rows']} × {result['cols']}")
                    print(f"    ✓ Size: {result['file_size_mb']:.2f} MB")
                    print(f"    ✓ Separator: {repr(result['separator'])}")
                    print(f"    ✓ Sequence columns: {result['sequence_columns']}")
                    print(f"    ✓ Target columns: {result['target_columns']}")
                
                self.results.append(result)
    
    def generate_report(self, output_file="data_inspection_report.txt"):
        """Generate inspection report"""
        report_lines = []
        
        # Header
        report_lines.append("=" * 80)
        report_lines.append("CRISPR-UniPredict DATA INSPECTION REPORT")
        report_lines.append("=" * 80)
        report_lines.append(f"\nGenerated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        report_lines.append(f"Base Directory: {self.base_dir}\n")
        
        # Summary
        report_lines.append("=" * 80)
        report_lines.append("SUMMARY")
        report_lines.append("=" * 80)
        report_lines.append(f"\nTotal Files Found: {self.summary['total_files']}")
        report_lines.append(f"Total Samples: {self.summary['total_samples']:,}")
        report_lines.append(f"Unique Sequence Columns: {len(self.summary['sequence_columns'])}")
        report_lines.append(f"Unique Target Columns: {len(self.summary['target_columns'])}")
        
        if self.summary['errors']:
            report_lines.append(f"Errors: {len(self.summary['errors'])}")
        
        # Sequence and Target Columns
        report_lines.append("\n" + "-" * 80)
        report_lines.append("IDENTIFIED COLUMNS")
        report_lines.append("-" * 80)
        
        report_lines.append("\nSequence Columns Found:")
        for col in sorted(self.summary['sequence_columns']):
            report_lines.append(f"  • {col}")
        
        report_lines.append("\nTarget Columns Found:")
        for col in sorted(self.summary['target_columns']):
            report_lines.append(f"  • {col}")
        
        # Detailed Results
        report_lines.append("\n" + "=" * 80)
        report_lines.append("DETAILED FILE INSPECTION")
        report_lines.append("=" * 80)
        
        for result in self.results:
            report_lines.append(f"\n{'─' * 80}")
            report_lines.append(f"File: {result['file_name']}")
            report_lines.append(f"{'─' * 80}")
            
            if result.get('error'):
                report_lines.append(f"ERROR: {result['error']}")
                continue
            
            report_lines.append(f"Path: {result['file_path']}")
            report_lines.append(f"Size: {result['file_size_mb']:.2f} MB")
            report_lines.append(f"Separator: {repr(result['separator'])}")
            report_lines.append(f"Shape: {result['rows']:,} rows × {result['cols']} columns")
            
            report_lines.append(f"\nColumns ({result['cols']}):")
            for i, col in enumerate(result['column_names'], 1):
                dtype = result['dtypes'].get(col, 'unknown')
                col_type = self.identify_column_type(col)
                col_type_str = f" [{', '.join(col_type)}]" if col_type != ['other'] else ""
                report_lines.append(f"  {i:2d}. {col:30s} ({dtype}){col_type_str}")
            
            report_lines.append(f"\nSequence Columns: {result['sequence_columns']}")
            report_lines.append(f"Target Columns: {result['target_columns']}")
            
            report_lines.append(f"\nFirst 3 Rows:")
            report_lines.append(result['first_rows'].to_string())
            
            # Data types summary
            if result['stats']['numeric_cols']:
                report_lines.append(f"\nNumeric Columns: {result['stats']['numeric_cols']}")
            
            if result['stats']['object_cols']:
                report_lines.append(f"Object Columns: {result['stats']['object_cols']}")
            
            # Missing values
            missing = {k: v for k, v in result['stats']['missing_values'].items() if v > 0}
            if missing:
                report_lines.append(f"\nMissing Values:")
                for col, count in missing.items():
                    pct = (count / result['rows']) * 100
                    report_lines.append(f"  {col}: {count} ({pct:.2f}%)")
        
        # Dataset Summary Table
        report_lines.append("\n" + "=" * 80)
        report_lines.append("DATASET SUMMARY TABLE")
        report_lines.append("=" * 80)
        report_lines.append("\n{:<40s} {:>10s} {:>8s} {:>10s}".format(
            "Dataset", "Rows", "Cols", "Size (MB)"
        ))
        report_lines.append("-" * 80)
        
        for dataset_name, info in sorted(self.summary['datasets'].items()):
            report_lines.append("{:<40s} {:>10,d} {:>8d} {:>10.2f}".format(
                dataset_name,
                info['rows'],
                info['cols'],
                info['size_mb']
            ))
        
        report_lines.append("-" * 80)
        report_lines.append("{:<40s} {:>10,d}".format(
            "TOTAL SAMPLES",
            self.summary['total_samples']
        ))
        
        # Column Pattern Analysis
        report_lines.append("\n" + "=" * 80)
        report_lines.append("COLUMN PATTERN ANALYSIS")
        report_lines.append("=" * 80)
        report_lines.append("\nMost Common Columns:")
        
        sorted_patterns = sorted(
            self.summary['column_patterns'].items(),
            key=lambda x: x[1],
            reverse=True
        )[:10]
        
        for col, count in sorted_patterns:
            report_lines.append(f"  {col:<30s} : {count} file(s)")
        
        # Errors
        if self.summary['errors']:
            report_lines.append("\n" + "=" * 80)
            report_lines.append("ERRORS")
            report_lines.append("=" * 80)
            for error in self.summary['errors']:
                report_lines.append(f"\n⚠ {error}")
        
        # Footer
        report_lines.append("\n" + "=" * 80)
        report_lines.append("END OF REPORT")
        report_lines.append("=" * 80)
        
        # Write report
        report_text = "\n".join(report_lines)
        
        # Save to file
        output_path = self.base_dir.parent / output_file
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(report_text)
        
        print(f"\n✓ Report saved to: {output_path}")
        
        return report_text
    
    def print_summary(self):
        """Print summary to console"""
        print("\n" + "=" * 80)
        print("INSPECTION SUMMARY")
        print("=" * 80)
        print(f"\nTotal Files: {self.summary['total_files']}")
        print(f"Total Samples: {self.summary['total_samples']:,}")
        print(f"Sequence Columns: {len(self.summary['sequence_columns'])}")
        print(f"Target Columns: {len(self.summary['target_columns'])}")
        
        if self.summary['errors']:
            print(f"\nErrors: {len(self.summary['errors'])}")
            for error in self.summary['errors']:
                print(f"  ⚠ {error}")
        
        print("\n" + "=" * 80)


def main():
    """Main function"""
    print("\n" + "=" * 80)
    print("CRISPR-UniPredict DATA INSPECTION TOOL")
    print("=" * 80)
    
    # Create inspector
    inspector = DataInspector()
    
    # Scan directories
    inspector.scan_directory()
    
    # Print summary
    inspector.print_summary()
    
    # Generate report
    report = inspector.generate_report("data_inspection_report.txt")
    
    # Print first part of report
    print("\n" + "=" * 80)
    print("REPORT PREVIEW")
    print("=" * 80)
    lines = report.split('\n')
    for line in lines[:50]:
        print(line)
    
    if len(lines) > 50:
        print(f"\n... ({len(lines) - 50} more lines)")
        print("\nFull report saved to: data_inspection_report.txt")


if __name__ == "__main__":
    main()
