"""
Transfer Learning for CRISPR-UniPredict
Fine-tune model for new organisms or cell types with limited data
"""

import argparse
import sys
import logging
import json
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Tuple
import numpy as np
import torch
import torch.nn as nn
from copy import deepcopy

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from models.crispr_unipredict import CRISPRUniPredict
from utils.preprocessing.dataloader_factory import DataLoaderFactory
from training.trainer import Trainer
from training.optimization import setup_optimizer, setup_scheduler
from utils.evaluation.metrics import MetricsCalculator
from configs.config_loader import ConfigLoader

logger = logging.getLogger(__name__)


class TransferLearner:
    """Transfer learning for model adaptation"""
    
    def __init__(self,
                 pretrained_model_path: str,
                 device: str = 'cuda'):
        """
        Initialize transfer learner
        
        Args:
            pretrained_model_path: Path to pretrained model
            device: Device to use (cuda/cpu)
        """
        self.pretrained_model_path = pretrained_model_path
        self.device = device
        
        # Load pretrained model
        self.model = self._load_pretrained_model()
        
        # Track frozen layers
        self.frozen_layers = set()
        
        logger.info(f"TransferLearner initialized with pretrained model from {pretrained_model_path}")
    
    def _load_pretrained_model(self) -> CRISPRUniPredict:
        """Load pretrained model"""
        model = CRISPRUniPredict(device=self.device)
        
        checkpoint = torch.load(self.pretrained_model_path, map_location=self.device)
        if isinstance(checkpoint, dict) and 'model_state_dict' in checkpoint:
            model.load_state_dict(checkpoint['model_state_dict'])
        else:
            model.load_state_dict(checkpoint)
        
        logger.info(f"Loaded pretrained model from {self.pretrained_model_path}")
        
        return model
    
    def freeze_layers(self, layers_to_freeze: List[str]) -> None:
        """
        Freeze specified layers
        
        Args:
            layers_to_freeze: List of layer names to freeze
        """
        for name, param in self.model.named_parameters():
            for layer in layers_to_freeze:
                if layer in name:
                    param.requires_grad = False
                    self.frozen_layers.add(name)
                    break
        
        logger.info(f"Frozen {len(self.frozen_layers)} parameters")
    
    def unfreeze_layers(self, layers_to_unfreeze: List[str]) -> None:
        """
        Unfreeze specified layers
        
        Args:
            layers_to_unfreeze: List of layer names to unfreeze
        """
        unfrozen_count = 0
        
        for name, param in self.model.named_parameters():
            for layer in layers_to_unfreeze:
                if layer in name:
                    param.requires_grad = True
                    if name in self.frozen_layers:
                        self.frozen_layers.remove(name)
                    unfrozen_count += 1
                    break
        
        logger.info(f"Unfrozen {unfrozen_count} parameters")
    
    def feature_extraction_mode(self) -> None:
        """
        Freeze all encoder layers, train only task heads
        
        Suitable for: ~100-1000 samples
        Learning rate: 1e-3
        """
        logger.info("Setting feature extraction mode")
        
        # Freeze encoder layers
        layers_to_freeze = [
            'rna_fm',
            'msc',
            'bigru',
            'mhsa',
            'fusion'
        ]
        
        self.freeze_layers(layers_to_freeze)
        
        # Count trainable parameters
        trainable_params = sum(p.numel() for p in self.model.parameters() if p.requires_grad)
        total_params = sum(p.numel() for p in self.model.parameters())
        
        logger.info(f"Feature extraction mode: {trainable_params}/{total_params} trainable parameters")
    
    def fine_tuning_mode(self, n_layers_to_unfreeze: int = 2) -> None:
        """
        Unfreeze last N layers for fine-tuning
        
        Suitable for: ~1000-5000 samples
        Learning rate: 1e-4
        
        Args:
            n_layers_to_unfreeze: Number of layers to unfreeze from the end
        """
        logger.info(f"Setting fine-tuning mode (unfreezing {n_layers_to_unfreeze} layers)")
        
        # First freeze all
        all_layers = [
            'rna_fm',
            'msc',
            'bigru',
            'mhsa',
            'fusion'
        ]
        self.freeze_layers(all_layers)
        
        # Then unfreeze last layers
        layers_to_unfreeze = [
            'on_target_head',
            'off_target_head'
        ]
        
        if n_layers_to_unfreeze >= 2:
            layers_to_unfreeze.append('fusion')
        
        if n_layers_to_unfreeze >= 3:
            layers_to_unfreeze.append('mhsa')
        
        self.unfreeze_layers(layers_to_unfreeze)
        
        # Count trainable parameters
        trainable_params = sum(p.numel() for p in self.model.parameters() if p.requires_grad)
        total_params = sum(p.numel() for p in self.model.parameters())
        
        logger.info(f"Fine-tuning mode: {trainable_params}/{total_params} trainable parameters")
    
    def full_retraining_mode(self) -> None:
        """
        Unfreeze all layers for full retraining
        
        Suitable for: >5000 samples
        Learning rate: 5e-4
        """
        logger.info("Setting full retraining mode")
        
        # Unfreeze all layers
        for param in self.model.parameters():
            param.requires_grad = True
        
        self.frozen_layers.clear()
        
        # Count trainable parameters
        trainable_params = sum(p.numel() for p in self.model.parameters() if p.requires_grad)
        
        logger.info(f"Full retraining mode: {trainable_params} trainable parameters")
    
    def get_transfer_config(self, strategy: str, n_samples: int) -> Dict:
        """
        Get recommended configuration for transfer strategy
        
        Args:
            strategy: Transfer strategy ('feature_extraction', 'fine_tuning', 'full_retraining')
            n_samples: Number of training samples
        
        Returns:
            Configuration dictionary
        """
        configs = {
            'feature_extraction': {
                'learning_rate': 1e-3,
                'weight_decay': 1e-5,
                'epochs': 50,
                'early_stopping_patience': 10,
                'batch_size': 32,
                'min_samples': 100,
                'max_samples': 1000
            },
            'fine_tuning': {
                'learning_rate': 1e-4,
                'weight_decay': 1e-4,
                'epochs': 100,
                'early_stopping_patience': 15,
                'batch_size': 16,
                'min_samples': 1000,
                'max_samples': 5000
            },
            'full_retraining': {
                'learning_rate': 5e-4,
                'weight_decay': 1e-4,
                'epochs': 200,
                'early_stopping_patience': 20,
                'batch_size': 32,
                'min_samples': 5000,
                'max_samples': None
            }
        }
        
        config = configs.get(strategy, configs['feature_extraction'])
        
        # Warn if sample count is outside recommended range
        if n_samples < config['min_samples']:
            logger.warning(f"Sample count {n_samples} < recommended minimum {config['min_samples']} for {strategy}")
        
        if config['max_samples'] and n_samples > config['max_samples']:
            logger.warning(f"Sample count {n_samples} > recommended maximum {config['max_samples']} for {strategy}")
        
        return config
    
    def transfer_to_new_species(self,
                               new_data_path: str,
                               strategy: str = 'feature_extraction',
                               output_dir: str = 'models/transfer',
                               base_config_path: str = 'configs/model_config.yaml',
                               species_name: str = 'new_species',
                               epochs: Optional[int] = None) -> Tuple[str, Dict]:
        """
        Transfer model to new species/condition
        
        Args:
            new_data_path: Path to new species data CSV
            strategy: Transfer strategy
            output_dir: Output directory
            base_config_path: Base configuration
            species_name: Name of new species
            epochs: Number of epochs (overrides default)
        
        Returns:
            Tuple of (checkpoint_path, metrics)
        """
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        
        logger.info(f"\n{'='*80}")
        logger.info(f"Transfer Learning: {strategy} for {species_name}")
        logger.info(f"{'='*80}")
        
        # Load new data
        from utils.preprocessing.dataset import CRISPRDataset
        new_dataset = CRISPRDataset(new_data_path)
        n_samples = len(new_dataset)
        
        logger.info(f"Loaded {n_samples} samples for {species_name}")
        
        # Set transfer mode
        if strategy == 'feature_extraction':
            self.feature_extraction_mode()
        elif strategy == 'fine_tuning':
            self.fine_tuning_mode()
        else:
            self.full_retraining_mode()
        
        # Get configuration
        transfer_config = self.get_transfer_config(strategy, n_samples)
        
        if epochs:
            transfer_config['epochs'] = epochs
        
        logger.info(f"Transfer config: {transfer_config}")
        
        # Load base config and create dataloaders
        config_loader = ConfigLoader(base_config_path)
        config = config_loader.config
        
        # Update config with transfer settings
        if hasattr(config, 'training'):
            config.training.learning_rate = transfer_config['learning_rate']
            config.training.epochs = transfer_config['epochs']
            config.training.early_stopping_patience = transfer_config['early_stopping_patience']
            config.training.batch_size = transfer_config['batch_size']
        
        # Create dataloaders
        dataloader_factory = DataLoaderFactory(config)
        dataloaders = dataloader_factory.create_dataloaders()
        
        # Setup optimizer with only trainable parameters
        optimizer = setup_optimizer(
            self.model,
            learning_rate=transfer_config['learning_rate'],
            weight_decay=transfer_config['weight_decay']
        )
        
        # Setup scheduler
        scheduler = setup_scheduler(
            optimizer,
            scheduler_type='ReduceLROnPlateau',
            patience=5
        )
        
        # Create trainer
        trainer = Trainer(
            model=self.model,
            dataloaders=dataloaders,
            config=config,
            optimizer=optimizer,
            scheduler=scheduler
        )
        
        # Train
        logger.info(f"Starting transfer learning for {species_name}")
        history = trainer.train()
        
        # Get best metrics
        if history['val']:
            best_metrics = history['val'][-1]
        else:
            best_metrics = {}
        
        # Save checkpoint
        checkpoint_path = output_dir / f'{species_name}_best.pt'
        torch.save({
            'model_state_dict': self.model.state_dict(),
            'strategy': strategy,
            'species': species_name,
            'metrics': best_metrics,
            'config': transfer_config,
            'n_samples': n_samples
        }, checkpoint_path)
        
        logger.info(f"Saved checkpoint to {checkpoint_path}")
        
        # Extract metrics
        metrics = {
            'strategy': strategy,
            'species': species_name,
            'n_samples': n_samples,
            'val_loss': best_metrics.get('total_loss', float('inf')),
            'on_target_scc': best_metrics.get('on_target_spearman', 0.0),
            'on_target_pcc': best_metrics.get('on_target_pearson', 0.0),
            'off_target_auroc': best_metrics.get('off_target_auroc', 0.0),
            'off_target_auprc': best_metrics.get('off_target_auprc', 0.0),
            'epochs_trained': len(history['train']),
            'transfer_config': transfer_config
        }
        
        logger.info(f"Transfer learning complete for {species_name}")
        logger.info(f"  SCC: {metrics['on_target_scc']:.4f}")
        logger.info(f"  AUROC: {metrics['off_target_auroc']:.4f}")
        
        return str(checkpoint_path), metrics
    
    def compare_strategies(self,
                          new_data_path: str,
                          output_dir: str = 'results/transfer_comparison',
                          base_config_path: str = 'configs/model_config.yaml',
                          species_name: str = 'new_species') -> Dict:
        """
        Compare transfer learning strategies
        
        Args:
            new_data_path: Path to new species data
            output_dir: Output directory
            base_config_path: Base configuration
            species_name: Name of new species
        
        Returns:
            Dictionary with results for each strategy
        """
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        
        logger.info(f"\n{'='*80}")
        logger.info(f"Comparing Transfer Learning Strategies for {species_name}")
        logger.info(f"{'='*80}")
        
        strategies = ['feature_extraction', 'fine_tuning', 'full_retraining']
        results = {}
        
        for strategy in strategies:
            logger.info(f"\nTesting strategy: {strategy}")
            
            # Reload model for each strategy
            self.model = self._load_pretrained_model()
            self.frozen_layers.clear()
            
            # Transfer
            checkpoint_path, metrics = self.transfer_to_new_species(
                new_data_path=new_data_path,
                strategy=strategy,
                output_dir=output_dir,
                base_config_path=base_config_path,
                species_name=f"{species_name}_{strategy}"
            )
            
            results[strategy] = {
                'checkpoint': checkpoint_path,
                'metrics': metrics
            }
        
        # Save comparison
        comparison_file = output_dir / 'strategy_comparison.json'
        with open(comparison_file, 'w') as f:
            json.dump(results, f, indent=2, default=str)
        
        logger.info(f"Saved comparison to {comparison_file}")
        
        return results
    
    def analyze_transfer_performance(self,
                                    results: Dict,
                                    save_path: Optional[str] = None) -> None:
        """
        Analyze and visualize transfer learning performance
        
        Args:
            results: Results dictionary from compare_strategies
            save_path: Optional path to save analysis
        """
        import matplotlib.pyplot as plt
        
        strategies = list(results.keys())
        
        # Extract metrics
        scc_scores = [results[s]['metrics']['on_target_scc'] for s in strategies]
        auroc_scores = [results[s]['metrics']['off_target_auroc'] for s in strategies]
        n_samples = [results[s]['metrics']['n_samples'] for s in strategies]
        
        # Create figure
        fig, axes = plt.subplots(1, 2, figsize=(14, 5))
        fig.suptitle('Transfer Learning Strategy Comparison', fontsize=16, fontweight='bold')
        
        # SCC comparison
        ax = axes[0]
        bars1 = ax.bar(strategies, scc_scores, color='steelblue', edgecolor='black', alpha=0.7)
        ax.set_ylabel('Spearman Correlation (On-Target)')
        ax.set_title('On-Target Performance')
        ax.set_ylim([0, 1])
        ax.grid(True, alpha=0.3, axis='y')
        
        # Add value labels
        for bar, score in zip(bars1, scc_scores):
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2., height,
                   f'{score:.4f}', ha='center', va='bottom')
        
        # AUROC comparison
        ax = axes[1]
        bars2 = ax.bar(strategies, auroc_scores, color='coral', edgecolor='black', alpha=0.7)
        ax.set_ylabel('AUROC (Off-Target)')
        ax.set_title('Off-Target Performance')
        ax.set_ylim([0, 1])
        ax.grid(True, alpha=0.3, axis='y')
        
        # Add value labels
        for bar, score in zip(bars2, auroc_scores):
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2., height,
                   f'{score:.4f}', ha='center', va='bottom')
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
            logger.info(f"Saved analysis to {save_path}")
        
        plt.close()
    
    def print_summary(self, metrics: Dict) -> None:
        """Print transfer learning summary"""
        print("\n" + "="*80)
        print("TRANSFER LEARNING SUMMARY")
        print("="*80)
        
        print(f"\nStrategy: {metrics['strategy']}")
        print(f"Species: {metrics['species']}")
        print(f"Samples: {metrics['n_samples']}")
        print(f"Epochs: {metrics['epochs_trained']}")
        
        print(f"\nPerformance:")
        print(f"  On-target SCC: {metrics['on_target_scc']:.4f}")
        print(f"  On-target PCC: {metrics['on_target_pcc']:.4f}")
        print(f"  Off-target AUROC: {metrics['off_target_auroc']:.4f}")
        print(f"  Off-target AUPRC: {metrics['off_target_auprc']:.4f}")
        
        print(f"\nTransfer Config:")
        config = metrics['transfer_config']
        print(f"  Learning Rate: {config['learning_rate']}")
        print(f"  Batch Size: {config['batch_size']}")
        print(f"  Early Stopping Patience: {config['early_stopping_patience']}")
        
        print("\n" + "="*80)


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(description='Transfer learning for CRISPR-UniPredict')
    parser.add_argument('--pretrained_model', type=str, required=True,
                       help='Path to pretrained model')
    parser.add_argument('--new_data', type=str, required=True,
                       help='Path to new species/condition data CSV')
    parser.add_argument('--species_name', type=str, default='new_species',
                       help='Name of new species/condition')
    parser.add_argument('--strategy', type=str, default='feature_extraction',
                       choices=['feature_extraction', 'fine_tuning', 'full_retraining'],
                       help='Transfer learning strategy')
    parser.add_argument('--compare_strategies', action='store_true',
                       help='Compare all strategies')
    parser.add_argument('--output_dir', type=str, default='models/transfer',
                       help='Output directory')
    parser.add_argument('--base_config', type=str, default='configs/model_config.yaml',
                       help='Base configuration file')
    parser.add_argument('--epochs', type=int, default=None,
                       help='Number of epochs (overrides default)')
    
    args = parser.parse_args()
    
    # Setup logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Create transfer learner
    learner = TransferLearner(
        pretrained_model_path=args.pretrained_model,
        device='cuda' if torch.cuda.is_available() else 'cpu'
    )
    
    if args.compare_strategies:
        # Compare all strategies
        results = learner.compare_strategies(
            new_data_path=args.new_data,
            output_dir=args.output_dir,
            base_config_path=args.base_config,
            species_name=args.species_name
        )
        
        # Analyze
        learner.analyze_transfer_performance(
            results,
            save_path=f"{args.output_dir}/strategy_comparison.png"
        )
    else:
        # Single strategy
        checkpoint_path, metrics = learner.transfer_to_new_species(
            new_data_path=args.new_data,
            strategy=args.strategy,
            output_dir=args.output_dir,
            base_config_path=args.base_config,
            species_name=args.species_name,
            epochs=args.epochs
        )
        
        learner.print_summary(metrics)
    
    print(f"\nResults saved to: {args.output_dir}")


if __name__ == '__main__':
    main()
