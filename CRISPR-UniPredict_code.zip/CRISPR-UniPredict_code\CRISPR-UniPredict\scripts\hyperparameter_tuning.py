"""
Hyperparameter Tuning for CRISPR-UniPredict using Optuna
Automatically finds optimal hyperparameters using Bayesian optimization
"""

import argparse
import json
import logging
import sys
import time
from pathlib import Path
from datetime import datetime
from typing import Dict, Optional, Tuple
import pickle

import numpy as np
import torch
import optuna
from optuna.pruners import MedianPruner
from optuna.samplers import TPESampler
from optuna.trial import Trial
import matplotlib.pyplot as plt
import seaborn as sns
import yaml

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from configs.config_loader import ConfigLoader
from models.crispr_unipredict import CRISPRUniPredict
from utils.preprocessing.dataloader_factory import DataLoaderFactory
from training.trainer import Trainer
from training.optimization import create_optimizer_and_scheduler

logger = logging.getLogger(__name__)


class HyperparameterTuner:
    """Hyperparameter tuning using Optuna"""
    
    def __init__(self,
                 config_path: str,
                 n_trials: int = 50,
                 study_name: str = 'crispr_optimization',
                 storage: Optional[str] = None,
                 output_dir: str = 'results/hyperparameter_tuning'):
        """
        Initialize hyperparameter tuner
        
        Args:
            config_path: Path to base configuration file
            n_trials: Number of trials to run
            study_name: Name of the Optuna study
            storage: Storage URL for study persistence (e.g., 'sqlite:///optuna_study.db')
            output_dir: Directory to save results
        """
        self.config_path = Path(config_path)
        self.n_trials = n_trials
        self.study_name = study_name
        self.storage = storage
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        # Load base configuration
        self.config_loader = ConfigLoader(str(self.config_path))
        self.base_config = self.config_loader.config
        
        # Setup logging
        self._setup_logging()
        
        # Trial tracking
        self.trial_results = []
        self.best_trial = None
        self.best_score = float('-inf')
        
        logger.info(f"Tuner initialized: {n_trials} trials, study: {study_name}")
    
    def _setup_logging(self) -> None:
        """Setup logging"""
        log_file = self.output_dir / 'tuning.log'
        handler = logging.FileHandler(log_file)
        handler.setLevel(logging.INFO)
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        handler.setFormatter(formatter)
        logger.addHandler(handler)
    
    def _suggest_hyperparameters(self, trial: Trial) -> Dict:
        """
        Suggest hyperparameters for a trial
        
        Args:
            trial: Optuna trial object
        
        Returns:
            Dictionary with suggested hyperparameters
        """
        config = self.base_config.copy() if hasattr(self.base_config, 'copy') else self.base_config
        
        # Learning rates
        rna_fm_lr = trial.suggest_float('rna_fm_lr', 1e-5, 1e-3, log=True)
        feature_extraction_lr = trial.suggest_float('feature_extraction_lr', 5e-4, 5e-3, log=True)
        task_heads_lr = trial.suggest_float('task_heads_lr', 5e-4, 5e-3, log=True)
        
        # Architecture parameters
        msc_out_channels = trial.suggest_categorical('msc_out_channels', [32, 64, 128])
        bigru_hidden_dim = trial.suggest_categorical('bigru_hidden_dim', [64, 128, 256])
        mhsa_num_heads = trial.suggest_categorical('mhsa_num_heads', [2, 4, 8])
        dropout_rate = trial.suggest_float('dropout_rate', 0.2, 0.5, step=0.05)
        
        # Training parameters
        batch_size = trial.suggest_categorical('batch_size', [64, 128, 256])
        warmup_epochs = trial.suggest_categorical('warmup_epochs', [3, 5, 10])
        loss_weight_on_target = trial.suggest_float('loss_weight_on_target', 0.3, 0.7, step=0.1)
        loss_weight_off_target = trial.suggest_float('loss_weight_off_target', 0.3, 0.7, step=0.1)
        
        # Optimizer parameters
        weight_decay = trial.suggest_float('weight_decay', 1e-5, 1e-3, log=True)
        gradient_clip = trial.suggest_float('gradient_clip', 0.5, 2.0)
        
        # Learning rate scheduler
        scheduler_patience = trial.suggest_categorical('scheduler_patience', [3, 5, 7])
        scheduler_factor = trial.suggest_float('scheduler_factor', 0.1, 0.5, step=0.1)
        
        return {
            'rna_fm_lr': rna_fm_lr,
            'feature_extraction_lr': feature_extraction_lr,
            'task_heads_lr': task_heads_lr,
            'msc_out_channels': msc_out_channels,
            'bigru_hidden_dim': bigru_hidden_dim,
            'mhsa_num_heads': mhsa_num_heads,
            'dropout_rate': dropout_rate,
            'batch_size': batch_size,
            'warmup_epochs': warmup_epochs,
            'loss_weight_on_target': loss_weight_on_target,
            'loss_weight_off_target': loss_weight_off_target,
            'weight_decay': weight_decay,
            'gradient_clip': gradient_clip,
            'scheduler_patience': scheduler_patience,
            'scheduler_factor': scheduler_factor
        }
    
    def _create_trial_config(self, base_config, hyperparams: Dict):
        """
        Create configuration for a trial
        
        Args:
            base_config: Base configuration
            hyperparams: Suggested hyperparameters
        
        Returns:
            Modified configuration
        """
        # Create a copy of the config
        from dataclasses import replace, asdict, is_dataclass
        
        if is_dataclass(base_config):
            config_dict = asdict(base_config)
        else:
            config_dict = base_config
        
        # Update learning rates
        if 'training' in config_dict:
            config_dict['training']['learning_rate_encoder'] = hyperparams['feature_extraction_lr']
            config_dict['training']['learning_rate_heads'] = hyperparams['task_heads_lr']
            config_dict['training']['weight_decay'] = hyperparams['weight_decay']
            config_dict['training']['gradient_clip'] = hyperparams['gradient_clip']
            config_dict['training']['batch_size'] = hyperparams['batch_size']
            config_dict['training']['loss']['loss_weights'] = {
                'on_target': hyperparams['loss_weight_on_target'],
                'off_target': hyperparams['loss_weight_off_target']
            }
        
        # Update model architecture
        if 'model' in config_dict:
            config_dict['model']['msc_channels'] = hyperparams['msc_out_channels']
            config_dict['model']['bigru_hidden'] = hyperparams['bigru_hidden_dim']
            config_dict['model']['mhsa_heads'] = hyperparams['mhsa_num_heads']
            config_dict['model']['dropout'] = hyperparams['dropout_rate']
        
        # Update validation parameters
        if 'validation' in config_dict:
            config_dict['validation']['early_stopping_patience'] = hyperparams['scheduler_patience']
        
        return config_dict
    
    def objective(self, trial: Trial) -> float:
        """
        Objective function for Optuna optimization
        
        Args:
            trial: Optuna trial object
        
        Returns:
            Combined validation metric (higher is better)
        """
        trial_id = trial.number
        logger.info(f"\n{'='*80}")
        logger.info(f"Trial {trial_id + 1}/{self.n_trials}")
        logger.info(f"{'='*80}")
        
        try:
            # Suggest hyperparameters
            hyperparams = self._suggest_hyperparameters(trial)
            logger.info(f"Suggested hyperparameters: {hyperparams}")
            
            # Create trial configuration
            trial_config = self._create_trial_config(self.base_config, hyperparams)
            
            # Setup device
            device = 'cuda' if torch.cuda.is_available() else 'cpu'
            logger.info(f"Using device: {device}")
            
            # Create model
            model = CRISPRUniPredict(device=device)
            
            # Create dataloaders
            dataloader_factory = DataLoaderFactory(trial_config)
            dataloaders = dataloader_factory.create_dataloaders()
            
            # Create trainer
            trainer = Trainer(model, dataloaders, trial_config)
            
            # Train for limited epochs (early stopping)
            max_epochs = min(20, trial_config.get('training', {}).get('epochs', 50))
            original_epochs = trial_config.get('training', {}).get('epochs', 50)
            trial_config['training']['epochs'] = max_epochs
            
            logger.info(f"Training for {max_epochs} epochs (original: {original_epochs})")
            
            # Train
            history = trainer.train()
            
            # Get validation metrics
            val_metrics = history['val'][-1] if history['val'] else {}
            
            # Calculate combined score
            scc = val_metrics.get('on_target_spearman', 0.0)
            auroc = val_metrics.get('off_target_auroc', 0.0)
            combined_score = (scc + auroc) / 2
            
            logger.info(f"Trial {trial_id + 1} Results:")
            logger.info(f"  SCC: {scc:.4f}")
            logger.info(f"  AUROC: {auroc:.4f}")
            logger.info(f"  Combined Score: {combined_score:.4f}")
            
            # Store trial result
            trial_result = {
                'trial_id': trial_id,
                'hyperparams': hyperparams,
                'scc': scc,
                'auroc': auroc,
                'combined_score': combined_score,
                'val_loss': val_metrics.get('total_loss', float('inf')),
                'timestamp': datetime.now().isoformat()
            }
            self.trial_results.append(trial_result)
            
            # Update best trial
            if combined_score > self.best_score:
                self.best_score = combined_score
                self.best_trial = trial_result
                logger.info(f"New best score: {combined_score:.4f}")
            
            # Report intermediate value for pruning
            trial.report(combined_score, step=max_epochs)
            
            # Check if trial should be pruned
            if trial.should_prune():
                logger.info(f"Trial {trial_id + 1} pruned")
                raise optuna.TrialPruned()
            
            return combined_score
        
        except Exception as e:
            logger.error(f"Trial {trial_id + 1} failed: {e}")
            logger.error(f"Exception: {type(e).__name__}: {str(e)}")
            return float('-inf')
    
    def run_optimization(self) -> optuna.Study:
        """
        Run hyperparameter optimization
        
        Returns:
            Optuna study object
        """
        logger.info(f"Starting optimization: {self.n_trials} trials")
        logger.info(f"Study name: {self.study_name}")
        
        # Create study
        sampler = TPESampler(seed=42)
        pruner = MedianPruner(n_startup_trials=5, n_warmup_steps=5)
        
        study = optuna.create_study(
            direction='maximize',
            sampler=sampler,
            pruner=pruner,
            study_name=self.study_name,
            storage=self.storage,
            load_if_exists=True
        )
        
        # Optimize
        start_time = time.time()
        study.optimize(self.objective, n_trials=self.n_trials, show_progress_bar=True)
        elapsed_time = time.time() - start_time
        
        logger.info(f"\nOptimization completed in {elapsed_time:.2f} seconds")
        logger.info(f"Best score: {study.best_value:.4f}")
        logger.info(f"Best trial: {study.best_trial.number}")
        
        return study
    
    def save_results(self, study: optuna.Study) -> None:
        """
        Save optimization results
        
        Args:
            study: Optuna study object
        """
        logger.info("\nSaving results...")
        
        # Save best hyperparameters
        best_params = study.best_params
        best_params_file = self.output_dir / 'best_hyperparameters.yaml'
        with open(best_params_file, 'w') as f:
            yaml.dump(best_params, f, default_flow_style=False)
        logger.info(f"Best hyperparameters saved to {best_params_file}")
        
        # Save all trial results
        trials_file = self.output_dir / 'all_trials.json'
        with open(trials_file, 'w') as f:
            json.dump(self.trial_results, f, indent=2)
        logger.info(f"All trials saved to {trials_file}")
        
        # Save study object
        study_file = self.output_dir / 'optuna_study.pkl'
        with open(study_file, 'wb') as f:
            pickle.dump(study, f)
        logger.info(f"Study object saved to {study_file}")
        
        # Save summary
        summary = {
            'n_trials': len(self.trial_results),
            'best_score': self.best_score,
            'best_trial_id': self.best_trial['trial_id'] if self.best_trial else None,
            'best_hyperparameters': best_params,
            'timestamp': datetime.now().isoformat()
        }
        summary_file = self.output_dir / 'summary.json'
        with open(summary_file, 'w') as f:
            json.dump(summary, f, indent=2)
        logger.info(f"Summary saved to {summary_file}")
    
    def generate_report(self, study: optuna.Study) -> None:
        """
        Generate visualization and report
        
        Args:
            study: Optuna study object
        """
        logger.info("\nGenerating report...")
        
        # Create figure with subplots
        fig = plt.figure(figsize=(16, 12))
        gs = fig.add_gridspec(3, 3, hspace=0.3, wspace=0.3)
        
        # 1. Optimization history
        ax = fig.add_subplot(gs[0, :2])
        trials_df = study.trials_dataframe()
        ax.plot(trials_df['number'], trials_df['value'], 'b-o', linewidth=2, markersize=4)
        ax.axhline(study.best_value, color='r', linestyle='--', label=f'Best: {study.best_value:.4f}')
        ax.set_xlabel('Trial Number')
        ax.set_ylabel('Combined Score')
        ax.set_title('Optimization History')
        ax.legend()
        ax.grid(True, alpha=0.3)
        
        # 2. Parameter importance
        ax = fig.add_subplot(gs[0, 2])
        try:
            importance = optuna.importance.get_param_importances(study)
            params = list(importance.keys())[:5]  # Top 5
            values = [importance[p] for p in params]
            ax.barh(params, values, color='steelblue')
            ax.set_xlabel('Importance')
            ax.set_title('Top 5 Parameter Importance')
            ax.grid(True, alpha=0.3, axis='x')
        except Exception as e:
            logger.warning(f"Could not compute parameter importance: {e}")
        
        # 3. Score distribution
        ax = fig.add_subplot(gs[1, 0])
        scores = [t['combined_score'] for t in self.trial_results]
        ax.hist(scores, bins=20, color='steelblue', edgecolor='black', alpha=0.7)
        ax.axvline(np.mean(scores), color='r', linestyle='--', label=f'Mean: {np.mean(scores):.4f}')
        ax.set_xlabel('Combined Score')
        ax.set_ylabel('Frequency')
        ax.set_title('Score Distribution')
        ax.legend()
        ax.grid(True, alpha=0.3, axis='y')
        
        # 4. SCC vs AUROC scatter
        ax = fig.add_subplot(gs[1, 1])
        sccs = [t['scc'] for t in self.trial_results]
        aurocs = [t['auroc'] for t in self.trial_results]
        scatter = ax.scatter(sccs, aurocs, c=scores, cmap='viridis', s=100, alpha=0.6)
        ax.set_xlabel('SCC')
        ax.set_ylabel('AUROC')
        ax.set_title('SCC vs AUROC')
        plt.colorbar(scatter, ax=ax, label='Combined Score')
        ax.grid(True, alpha=0.3)
        
        # 5. Batch size effect
        ax = fig.add_subplot(gs[1, 2])
        batch_sizes = [t['hyperparams']['batch_size'] for t in self.trial_results]
        batch_scores = {}
        for bs, trial in zip(batch_sizes, self.trial_results):
            if bs not in batch_scores:
                batch_scores[bs] = []
            batch_scores[bs].append(trial['combined_score'])
        
        batch_means = {bs: np.mean(scores) for bs, scores in batch_scores.items()}
        ax.bar(batch_means.keys(), batch_means.values(), color='steelblue', edgecolor='black')
        ax.set_xlabel('Batch Size')
        ax.set_ylabel('Mean Score')
        ax.set_title('Batch Size Effect')
        ax.grid(True, alpha=0.3, axis='y')
        
        # 6. Learning rate effects
        ax = fig.add_subplot(gs[2, 0])
        lrs = [t['hyperparams']['feature_extraction_lr'] for t in self.trial_results]
        ax.scatter(lrs, scores, alpha=0.6, s=100, color='steelblue')
        ax.set_xlabel('Feature Extraction LR')
        ax.set_ylabel('Combined Score')
        ax.set_title('Learning Rate Effect')
        ax.set_xscale('log')
        ax.grid(True, alpha=0.3)
        
        # 7. Dropout effect
        ax = fig.add_subplot(gs[2, 1])
        dropouts = [t['hyperparams']['dropout_rate'] for t in self.trial_results]
        ax.scatter(dropouts, scores, alpha=0.6, s=100, color='steelblue')
        ax.set_xlabel('Dropout Rate')
        ax.set_ylabel('Combined Score')
        ax.set_title('Dropout Effect')
        ax.grid(True, alpha=0.3)
        
        # 8. Trials over time
        ax = fig.add_subplot(gs[2, 2])
        trial_times = [datetime.fromisoformat(t['timestamp']) for t in self.trial_results]
        time_diffs = [(t - trial_times[0]).total_seconds() / 3600 for t in trial_times]
        ax.plot(time_diffs, scores, 'b-o', linewidth=2, markersize=4)
        ax.set_xlabel('Time (hours)')
        ax.set_ylabel('Combined Score')
        ax.set_title('Score Over Time')
        ax.grid(True, alpha=0.3)
        
        # Save figure
        report_file = self.output_dir / 'optimization_report.png'
        plt.savefig(report_file, dpi=150, bbox_inches='tight')
        logger.info(f"Report saved to {report_file}")
        plt.close()
    
    def print_summary(self, study: optuna.Study) -> None:
        """
        Print optimization summary
        
        Args:
            study: Optuna study object
        """
        print("\n" + "="*80)
        print("HYPERPARAMETER OPTIMIZATION SUMMARY")
        print("="*80)
        
        print(f"\nTotal Trials: {len(self.trial_results)}")
        print(f"Best Score: {study.best_value:.4f}")
        print(f"Best Trial: {study.best_trial.number}")
        
        print("\nBest Hyperparameters:")
        for param, value in study.best_params.items():
            if isinstance(value, float):
                print(f"  {param}: {value:.6f}")
            else:
                print(f"  {param}: {value}")
        
        print("\nScore Statistics:")
        scores = [t['combined_score'] for t in self.trial_results]
        print(f"  Mean: {np.mean(scores):.4f}")
        print(f"  Std: {np.std(scores):.4f}")
        print(f"  Min: {np.min(scores):.4f}")
        print(f"  Max: {np.max(scores):.4f}")
        
        print("\nTop 5 Trials:")
        sorted_trials = sorted(self.trial_results, key=lambda x: x['combined_score'], reverse=True)
        for i, trial in enumerate(sorted_trials[:5]):
            print(f"  {i+1}. Trial {trial['trial_id']}: {trial['combined_score']:.4f}")
        
        print("\n" + "="*80)


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(description='Hyperparameter tuning for CRISPR-UniPredict')
    parser.add_argument('--config', type=str, default='configs/model_config.yaml',
                       help='Base configuration file')
    parser.add_argument('--n_trials', type=int, default=50, help='Number of trials')
    parser.add_argument('--study_name', type=str, default='crispr_optimization',
                       help='Optuna study name')
    parser.add_argument('--storage', type=str, default=None,
                       help='Storage URL (e.g., sqlite:///optuna_study.db)')
    parser.add_argument('--output_dir', type=str, default='results/hyperparameter_tuning',
                       help='Output directory')
    parser.add_argument('--resume', action='store_true', help='Resume previous study')
    
    args = parser.parse_args()
    
    # Setup logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Create tuner
    tuner = HyperparameterTuner(
        config_path=args.config,
        n_trials=args.n_trials,
        study_name=args.study_name,
        storage=args.storage,
        output_dir=args.output_dir
    )
    
    # Run optimization
    study = tuner.run_optimization()
    
    # Save results
    tuner.save_results(study)
    
    # Generate report
    tuner.generate_report(study)
    
    # Print summary
    tuner.print_summary(study)
    
    print(f"\nResults saved to: {tuner.output_dir}")


if __name__ == '__main__':
    main()
