"""
Active Learning for CRISPR-UniPredict
Identifies informative samples for additional labeling/validation
"""

import argparse
import sys
import logging
import json
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Tuple, Optional
import numpy as np
import pandas as pd
import torch
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
import seaborn as sns

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from models.crispr_unipredict import CRISPRUniPredict
from models.ensemble_model import EnsembleModel
from utils.preprocessing.dataset import CRISPRDataset
from utils.evaluation.metrics import MetricsCalculator

logger = logging.getLogger(__name__)


class ActiveLearner:
    """Active learning for model improvement"""
    
    def __init__(self,
                 model_checkpoint: str,
                 unlabeled_data_path: str,
                 ensemble_checkpoint: Optional[str] = None,
                 output_dir: str = 'results/active_learning',
                 device: str = 'cuda'):
        """
        Initialize active learner
        
        Args:
            model_checkpoint: Path to trained model checkpoint
            unlabeled_data_path: Path to unlabeled sequences CSV
            ensemble_checkpoint: Path to ensemble config (optional)
            output_dir: Output directory
            device: Device to use (cuda/cpu)
        """
        self.model_checkpoint = model_checkpoint
        self.unlabeled_data_path = Path(unlabeled_data_path)
        self.ensemble_checkpoint = ensemble_checkpoint
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.device = device
        
        # Load model
        self.model = self._load_model(model_checkpoint)
        
        # Load ensemble if provided
        self.ensemble = None
        if ensemble_checkpoint:
            self.ensemble = EnsembleModel.load_config(ensemble_checkpoint)
        
        # Load unlabeled data
        self.unlabeled_data = self._load_unlabeled_data()
        
        # Metrics calculator
        self.metrics_calculator = MetricsCalculator()
        
        # Results tracking
        self.query_history = []
        self.selected_indices = set()
        
        logger.info(f"ActiveLearner initialized with {len(self.unlabeled_data)} unlabeled samples")
    
    def _setup_logging(self) -> None:
        """Setup logging"""
        log_file = self.output_dir / 'active_learning.log'
        handler = logging.FileHandler(log_file)
        handler.setLevel(logging.INFO)
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        handler.setFormatter(formatter)
        logger.addHandler(handler)
    
    def _load_model(self, checkpoint_path: str) -> CRISPRUniPredict:
        """Load model from checkpoint"""
        model = CRISPRUniPredict(device=self.device)
        
        checkpoint = torch.load(checkpoint_path, map_location=self.device)
        if isinstance(checkpoint, dict) and 'model_state_dict' in checkpoint:
            model.load_state_dict(checkpoint['model_state_dict'])
        else:
            model.load_state_dict(checkpoint)
        
        model.eval()
        logger.info(f"Loaded model from {checkpoint_path}")
        
        return model
    
    def _load_unlabeled_data(self) -> pd.DataFrame:
        """Load unlabeled sequences"""
        df = pd.read_csv(self.unlabeled_data_path)
        logger.info(f"Loaded {len(df)} unlabeled sequences from {self.unlabeled_data_path}")
        return df
    
    def uncertainty_sampling(self, n_samples: int = 100) -> np.ndarray:
        """
        Select most uncertain predictions
        
        Args:
            n_samples: Number of samples to select
        
        Returns:
            Array of indices
        """
        logger.info(f"Uncertainty sampling: selecting {n_samples} samples")
        
        # Get predictions with uncertainty
        uncertainties = []
        
        with torch.no_grad():
            for idx, row in self.unlabeled_data.iterrows():
                try:
                    # Get sequence
                    sgrna = row['sgrna']
                    
                    # Create one-hot encoding
                    from utils.preprocessing.dataset import SequenceEncoder
                    encoder = SequenceEncoder()
                    sgrna_onehot = encoder.encode_onehot(sgrna)
                    sgrna_label = encoder.encode_label(sgrna)
                    
                    sgrna_onehot = torch.tensor(sgrna_onehot, dtype=torch.float32, device=self.device).unsqueeze(0)
                    sgrna_label = torch.tensor(sgrna_label, dtype=torch.long, device=self.device).unsqueeze(0)
                    
                    # Get predictions
                    if self.ensemble:
                        on_target_var, off_target_var = self.ensemble.get_prediction_variance(
                            sgrna_onehot, sgrna_label
                        )
                        # Combined uncertainty
                        uncertainty = (on_target_var.item() + off_target_var.item()) / 2
                    else:
                        on_target, off_target = self.model(sgrna_onehot, sgrna_label, task_type='both')
                        
                        # Uncertainty: distance from decision boundary
                        on_target_uncertainty = torch.abs(on_target - 0.5).item()
                        off_target_uncertainty = torch.abs(off_target - 0.5).item()
                        uncertainty = min(on_target_uncertainty, off_target_uncertainty)
                    
                    uncertainties.append(uncertainty)
                
                except Exception as e:
                    logger.warning(f"Error processing sample {idx}: {e}")
                    uncertainties.append(0.0)
        
        uncertainties = np.array(uncertainties)
        
        # Select samples with highest uncertainty (lowest confidence)
        uncertain_indices = np.argsort(uncertainties)[:n_samples]
        
        logger.info(f"Selected {len(uncertain_indices)} uncertain samples")
        logger.info(f"Uncertainty range: {uncertainties[uncertain_indices].min():.4f} - {uncertainties[uncertain_indices].max():.4f}")
        
        return uncertain_indices
    
    def diversity_sampling(self, n_samples: int = 100, n_clusters: Optional[int] = None) -> np.ndarray:
        """
        Select diverse samples using clustering
        
        Args:
            n_samples: Number of samples to select
            n_clusters: Number of clusters (default: n_samples)
        
        Returns:
            Array of indices
        """
        logger.info(f"Diversity sampling: selecting {n_samples} diverse samples")
        
        if n_clusters is None:
            n_clusters = min(n_samples, len(self.unlabeled_data) // 10)
        
        # Get embeddings from RNA-FM
        embeddings = self._get_embeddings()
        
        if embeddings is None:
            logger.warning("Could not get embeddings, using random sampling")
            return np.random.choice(len(self.unlabeled_data), n_samples, replace=False)
        
        # Normalize embeddings
        scaler = StandardScaler()
        embeddings_scaled = scaler.fit_transform(embeddings)
        
        # Cluster
        logger.info(f"Clustering into {n_clusters} clusters")
        kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
        clusters = kmeans.fit_predict(embeddings_scaled)
        
        # Select representatives from each cluster
        diverse_indices = []
        for cluster_id in range(n_clusters):
            cluster_mask = clusters == cluster_id
            cluster_indices = np.where(cluster_mask)[0]
            
            if len(cluster_indices) > 0:
                # Select closest to cluster center
                cluster_embeddings = embeddings_scaled[cluster_mask]
                distances = np.linalg.norm(cluster_embeddings - kmeans.cluster_centers_[cluster_id], axis=1)
                closest_idx = cluster_indices[np.argmin(distances)]
                diverse_indices.append(closest_idx)
        
        # If we need more samples, add random ones
        if len(diverse_indices) < n_samples:
            remaining = n_samples - len(diverse_indices)
            additional = np.random.choice(
                len(self.unlabeled_data),
                remaining,
                replace=False
            )
            diverse_indices.extend(additional)
        
        diverse_indices = np.array(diverse_indices[:n_samples])
        
        logger.info(f"Selected {len(diverse_indices)} diverse samples from {n_clusters} clusters")
        
        return diverse_indices
    
    def disagreement_sampling(self, n_samples: int = 100) -> np.ndarray:
        """
        Select samples with highest disagreement between ensemble members
        
        Args:
            n_samples: Number of samples to select
        
        Returns:
            Array of indices
        """
        if self.ensemble is None:
            logger.warning("Ensemble not available, skipping disagreement sampling")
            return np.array([])
        
        logger.info(f"Disagreement sampling: selecting {n_samples} samples")
        
        disagreements = []
        
        with torch.no_grad():
            for idx, row in self.unlabeled_data.iterrows():
                try:
                    # Get sequence
                    sgrna = row['sgrna']
                    
                    # Create encodings
                    from utils.preprocessing.dataset import SequenceEncoder
                    encoder = SequenceEncoder()
                    sgrna_onehot = encoder.encode_onehot(sgrna)
                    sgrna_label = encoder.encode_label(sgrna)
                    
                    sgrna_onehot = torch.tensor(sgrna_onehot, dtype=torch.float32, device=self.device).unsqueeze(0)
                    sgrna_label = torch.tensor(sgrna_label, dtype=torch.long, device=self.device).unsqueeze(0)
                    
                    # Get predictions from each model
                    predictions = self.ensemble.get_model_predictions(sgrna_onehot, sgrna_label)
                    
                    # Calculate disagreement (variance of predictions)
                    on_target_preds = [p[0].item() for p in predictions.values()]
                    off_target_preds = [p[1].item() for p in predictions.values()]
                    
                    on_target_disagreement = np.var(on_target_preds)
                    off_target_disagreement = np.var(off_target_preds)
                    
                    disagreement = (on_target_disagreement + off_target_disagreement) / 2
                    disagreements.append(disagreement)
                
                except Exception as e:
                    logger.warning(f"Error processing sample {idx}: {e}")
                    disagreements.append(0.0)
        
        disagreements = np.array(disagreements)
        
        # Select samples with highest disagreement
        disagreement_indices = np.argsort(disagreements)[-n_samples:]
        
        logger.info(f"Selected {len(disagreement_indices)} disagreement samples")
        logger.info(f"Disagreement range: {disagreements[disagreement_indices].min():.4f} - {disagreements[disagreement_indices].max():.4f}")
        
        return disagreement_indices
    
    def query_next_batch(self,
                        n_samples: int = 100,
                        uncertainty_weight: float = 0.4,
                        diversity_weight: float = 0.4,
                        disagreement_weight: float = 0.2) -> Tuple[np.ndarray, pd.DataFrame]:
        """
        Query next batch using combined strategy
        
        Args:
            n_samples: Number of samples to select
            uncertainty_weight: Weight for uncertainty sampling
            diversity_weight: Weight for diversity sampling
            disagreement_weight: Weight for disagreement sampling
        
        Returns:
            Tuple of (indices, selected_data)
        """
        logger.info(f"\nQuerying next batch of {n_samples} samples")
        
        # Normalize weights
        total_weight = uncertainty_weight + diversity_weight + disagreement_weight
        uncertainty_weight /= total_weight
        diversity_weight /= total_weight
        disagreement_weight /= total_weight
        
        # Get samples from each strategy
        n_uncertain = int(n_samples * uncertainty_weight)
        n_diverse = int(n_samples * diversity_weight)
        n_disagreement = n_samples - n_uncertain - n_diverse
        
        logger.info(f"Strategy weights: uncertainty={uncertainty_weight:.2f}, diversity={diversity_weight:.2f}, disagreement={disagreement_weight:.2f}")
        logger.info(f"Samples per strategy: uncertain={n_uncertain}, diverse={n_diverse}, disagreement={n_disagreement}")
        
        # Get indices from each strategy
        uncertain_indices = self.uncertainty_sampling(n_uncertain)
        diverse_indices = self.diversity_sampling(n_diverse)
        disagreement_indices = self.disagreement_sampling(n_disagreement)
        
        # Combine and remove duplicates
        all_indices = np.concatenate([uncertain_indices, diverse_indices, disagreement_indices])
        all_indices = np.unique(all_indices)
        
        # Remove already selected
        all_indices = np.array([idx for idx in all_indices if idx not in self.selected_indices])
        
        # Trim to requested size
        if len(all_indices) > n_samples:
            all_indices = all_indices[:n_samples]
        
        # Update selected set
        self.selected_indices.update(all_indices)
        
        # Get selected data
        selected_data = self.unlabeled_data.iloc[all_indices].copy()
        selected_data['selected_index'] = all_indices
        
        # Track query
        query_info = {
            'iteration': len(self.query_history) + 1,
            'timestamp': datetime.now().isoformat(),
            'n_samples': len(all_indices),
            'indices': all_indices.tolist()
        }
        self.query_history.append(query_info)
        
        logger.info(f"Selected {len(all_indices)} samples for labeling")
        
        return all_indices, selected_data
    
    def _get_embeddings(self) -> Optional[np.ndarray]:
        """
        Get embeddings for all unlabeled sequences
        
        Returns:
            Array of embeddings or None if not available
        """
        try:
            from models.rna_fm_encoder import RNAFMEncoder
            
            encoder = RNAFMEncoder(device=self.device)
            embeddings = []
            
            for idx, row in self.unlabeled_data.iterrows():
                sgrna = row['sgrna']
                embedding = encoder.encode_single(sgrna, return_full_embeddings=False)
                embeddings.append(embedding)
            
            return np.array(embeddings)
        
        except Exception as e:
            logger.warning(f"Could not get RNA-FM embeddings: {e}")
            return None
    
    def save_query_results(self, selected_indices: np.ndarray, selected_data: pd.DataFrame) -> None:
        """
        Save query results
        
        Args:
            selected_indices: Selected indices
            selected_data: Selected data
        """
        # Save selected data
        selected_file = self.output_dir / f'selected_samples_iter_{len(self.query_history)}.csv'
        selected_data.to_csv(selected_file, index=False)
        logger.info(f"Saved selected samples to {selected_file}")
        
        # Save query history
        history_file = self.output_dir / 'query_history.json'
        with open(history_file, 'w') as f:
            json.dump(self.query_history, f, indent=2)
        logger.info(f"Saved query history to {history_file}")
    
    def generate_report(self) -> None:
        """Generate visualization report"""
        if not self.query_history:
            logger.warning("No queries to report")
            return
        
        logger.info("Generating active learning report")
        
        # Create figure
        fig, axes = plt.subplots(2, 2, figsize=(14, 10))
        fig.suptitle('Active Learning Report', fontsize=16, fontweight='bold')
        
        # 1. Samples selected over iterations
        ax = axes[0, 0]
        iterations = [q['iteration'] for q in self.query_history]
        n_samples = [q['n_samples'] for q in self.query_history]
        ax.bar(iterations, n_samples, color='steelblue', edgecolor='black')
        ax.set_xlabel('Iteration')
        ax.set_ylabel('Samples Selected')
        ax.set_title('Samples Selected per Iteration')
        ax.grid(True, alpha=0.3, axis='y')
        
        # 2. Cumulative samples
        ax = axes[0, 1]
        cumulative = np.cumsum(n_samples)
        ax.plot(iterations, cumulative, 'b-o', linewidth=2, markersize=8)
        ax.fill_between(iterations, cumulative, alpha=0.3)
        ax.set_xlabel('Iteration')
        ax.set_ylabel('Cumulative Samples')
        ax.set_title('Cumulative Samples Selected')
        ax.grid(True, alpha=0.3)
        
        # 3. Query timeline
        ax = axes[1, 0]
        timestamps = [datetime.fromisoformat(q['timestamp']) for q in self.query_history]
        time_diffs = [(t - timestamps[0]).total_seconds() / 3600 for t in timestamps]
        ax.scatter(time_diffs, n_samples, s=100, alpha=0.6, color='steelblue')
        ax.set_xlabel('Time (hours)')
        ax.set_ylabel('Samples Selected')
        ax.set_title('Query Timeline')
        ax.grid(True, alpha=0.3)
        
        # 4. Statistics
        ax = axes[1, 1]
        ax.axis('off')
        
        stats_text = f"""
        ACTIVE LEARNING STATISTICS
        
        Total Iterations: {len(self.query_history)}
        Total Samples Selected: {sum(n_samples)}
        Average per Iteration: {np.mean(n_samples):.1f}
        
        Unlabeled Data Size: {len(self.unlabeled_data)}
        Coverage: {sum(n_samples) / len(self.unlabeled_data) * 100:.1f}%
        
        Start Time: {timestamps[0].strftime('%Y-%m-%d %H:%M:%S')}
        End Time: {timestamps[-1].strftime('%Y-%m-%d %H:%M:%S')}
        Duration: {time_diffs[-1]:.1f} hours
        """
        
        ax.text(0.1, 0.9, stats_text, transform=ax.transAxes, fontsize=10,
                verticalalignment='top', fontfamily='monospace',
                bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
        
        # Save figure
        report_file = self.output_dir / 'active_learning_report.png'
        plt.savefig(report_file, dpi=150, bbox_inches='tight')
        logger.info(f"Saved report to {report_file}")
        plt.close()
    
    def print_summary(self) -> None:
        """Print active learning summary"""
        print("\n" + "="*80)
        print("ACTIVE LEARNING SUMMARY")
        print("="*80)
        
        if self.query_history:
            print(f"\nTotal Iterations: {len(self.query_history)}")
            print(f"Total Samples Selected: {sum(q['n_samples'] for q in self.query_history)}")
            print(f"Average per Iteration: {np.mean([q['n_samples'] for q in self.query_history]):.1f}")
            print(f"Coverage: {len(self.selected_indices) / len(self.unlabeled_data) * 100:.1f}%")
        else:
            print("No queries performed yet")
        
        print("\n" + "="*80)


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(description='Active learning for model improvement')
    parser.add_argument('--initial_model', type=str, required=True,
                       help='Initial model checkpoint')
    parser.add_argument('--unlabeled_data', type=str, required=True,
                       help='Unlabeled sequences CSV')
    parser.add_argument('--ensemble_config', type=str, default=None,
                       help='Ensemble configuration (optional)')
    parser.add_argument('--n_iterations', type=int, default=5,
                       help='Number of iterations')
    parser.add_argument('--samples_per_iteration', type=int, default=1000,
                       help='Samples to select per iteration')
    parser.add_argument('--output_dir', type=str, default='results/active_learning',
                       help='Output directory')
    parser.add_argument('--uncertainty_weight', type=float, default=0.4,
                       help='Weight for uncertainty sampling')
    parser.add_argument('--diversity_weight', type=float, default=0.4,
                       help='Weight for diversity sampling')
    parser.add_argument('--disagreement_weight', type=float, default=0.2,
                       help='Weight for disagreement sampling')
    
    args = parser.parse_args()
    
    # Setup logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Create active learner
    learner = ActiveLearner(
        model_checkpoint=args.initial_model,
        unlabeled_data_path=args.unlabeled_data,
        ensemble_checkpoint=args.ensemble_config,
        output_dir=args.output_dir
    )
    
    # Run iterations
    for iteration in range(args.n_iterations):
        logger.info(f"\n{'='*80}")
        logger.info(f"Iteration {iteration + 1}/{args.n_iterations}")
        logger.info(f"{'='*80}")
        
        # Query next batch
        selected_indices, selected_data = learner.query_next_batch(
            n_samples=args.samples_per_iteration,
            uncertainty_weight=args.uncertainty_weight,
            diversity_weight=args.diversity_weight,
            disagreement_weight=args.disagreement_weight
        )
        
        # Save results
        learner.save_query_results(selected_indices, selected_data)
        
        logger.info(f"Iteration {iteration + 1} complete. Selected {len(selected_indices)} samples")
    
    # Generate report
    learner.generate_report()
    
    # Print summary
    learner.print_summary()
    
    print(f"\nResults saved to: {learner.output_dir}")


if __name__ == '__main__':
    main()
