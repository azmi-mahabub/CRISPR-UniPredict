"""
Evaluation Script for CRISPR-UniPredict
Loads trained model and evaluates on test set with comprehensive metrics and visualizations
"""

import argparse
import sys
import logging
import json
from pathlib import Path
from datetime import datetime
from typing import Tuple, Dict
import numpy as np
import pandas as pd
import torch
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import roc_curve, auc, precision_recall_curve

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

# Ensure RNA-FM is in path (so checkpoints with real RNA-FM can be loaded)
from utils.rna_fm_path import ensure_rna_fm_import_path
ensure_rna_fm_import_path(Path(__file__).parent.parent)

from models.crispr_unipredict import CRISPRUniPredict
from models.encoding import SequenceEncoder
from utils.preprocessing.dataset import CRISPRDataset
from utils.evaluation.metrics import MetricsCalculator
from torch.utils.data import DataLoader


def setup_logging(output_dir: Path) -> logging.Logger:
    """
    Setup logging
    
    Args:
        output_dir: Output directory
    
    Returns:
        Configured logger
    """
    output_dir.mkdir(parents=True, exist_ok=True)
    
    logger = logging.getLogger('CRISPR-Evaluate')
    logger.setLevel(logging.DEBUG)
    
    # File handler
    log_file = output_dir / 'evaluation.log'
    file_handler = logging.FileHandler(log_file)
    file_handler.setLevel(logging.DEBUG)
    
    # Console handler
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    
    # Formatter
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    file_handler.setFormatter(formatter)
    console_handler.setFormatter(formatter)
    
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)
    
    return logger


def load_checkpoint(checkpoint_path: str, device: str) -> Tuple[CRISPRUniPredict, Dict]:
    """
    Load trained model from checkpoint
    
    Args:
        checkpoint_path: Path to checkpoint
        device: Device to load on
    
    Returns:
        Tuple of (model, checkpoint_dict)
    """
    checkpoint_path = Path(checkpoint_path)
    
    if not checkpoint_path.exists():
        raise FileNotFoundError(f"Checkpoint not found: {checkpoint_path}")
    
    # Load checkpoint
    checkpoint = torch.load(checkpoint_path, map_location=device)
    
    # Initialize model
    model = CRISPRUniPredict(device=device)
    model.load_state_dict(checkpoint['model_state_dict'])
    model.eval()
    
    logger.info(f"Model loaded from {checkpoint_path}")
    
    return model, checkpoint


def load_test_dataset(test_data_path: str, device: str) -> CRISPRDataset:
    """
    Load test dataset
    
    Args:
        test_data_path: Path to test CSV
        device: Device for encoder
    
    Returns:
        CRISPRDataset instance
    """
    test_data_path = Path(test_data_path)
    
    if not test_data_path.exists():
        raise FileNotFoundError(f"Test data not found: {test_data_path}")
    
    # Create encoder
    encoder = SequenceEncoder(device=device)
    
    # Load dataset
    dataset = CRISPRDataset(
        csv_path=str(test_data_path),
        encoder=encoder,
        cache_dir=Path('.cache/test'),
        use_cache=True,
        augmentation=False,
        verbose=True
    )
    
    logger.info(f"Test dataset loaded: {len(dataset)} samples")
    
    return dataset


def run_predictions(model: CRISPRUniPredict,
                   dataset: CRISPRDataset,
                   device: str,
                   batch_size: int = 64) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    Run predictions on entire test set
    
    Args:
        model: Trained model
        dataset: Test dataset
        device: Device
        batch_size: Batch size for inference
    
    Returns:
        Tuple of (on_target_pred, on_target_target, off_target_pred, off_target_target, on_target_mask, off_target_mask)
    """
    # Create dataloader
    dataloader = DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=4,
        pin_memory=True
    )
    
    # Collect predictions
    all_on_target_pred = []
    all_on_target_target = []
    all_off_target_pred = []
    all_off_target_target = []
    all_on_target_mask = []
    all_off_target_mask = []
    
    logger.info("Running predictions on test set...")
    
    with torch.no_grad():
        for batch in dataloader:
            sgrna_onehot = batch['sgrna_onehot'].to(device)
            sgrna_label = batch['sgrna_label'].to(device)
            on_target_score = batch['on_target_score'].to(device)
            off_target_label = batch['off_target_label'].to(device)
            on_target_mask = batch['on_target_mask'].to(device)
            off_target_mask = batch['off_target_mask'].to(device)
            
            # Forward pass
            on_target_pred, off_target_pred = model(
                sgrna_onehot, sgrna_label, task_type='both'
            )
            
            # Collect
            all_on_target_pred.append(on_target_pred.cpu())
            all_on_target_target.append(on_target_score.cpu())
            all_off_target_pred.append(off_target_pred.cpu())
            all_off_target_target.append(off_target_label.cpu())
            all_on_target_mask.append(on_target_mask.cpu())
            all_off_target_mask.append(off_target_mask.cpu())
    
    # Concatenate
    on_target_pred = torch.cat(all_on_target_pred).numpy().squeeze()
    on_target_target = torch.cat(all_on_target_target).numpy().squeeze()
    off_target_pred = torch.cat(all_off_target_pred).numpy().squeeze()
    off_target_target = torch.cat(all_off_target_target).numpy().squeeze()
    on_target_mask = torch.cat(all_on_target_mask).numpy()
    off_target_mask = torch.cat(all_off_target_mask).numpy()
    
    logger.info(f"Predictions completed: {len(on_target_pred)} samples")
    
    return on_target_pred, on_target_target, off_target_pred, off_target_target, on_target_mask, off_target_mask


def compute_metrics(on_target_pred: np.ndarray,
                   on_target_target: np.ndarray,
                   off_target_pred: np.ndarray,
                   off_target_target: np.ndarray,
                   on_target_mask: np.ndarray,
                   off_target_mask: np.ndarray) -> Dict:
    """
    Compute all metrics
    
    Args:
        on_target_pred: On-target predictions
        on_target_target: On-target targets
        off_target_pred: Off-target predictions
        off_target_target: Off-target targets
        on_target_mask: On-target mask
        off_target_mask: Off-target mask
    
    Returns:
        Dictionary with all metrics
    """
    calculator = MetricsCalculator()
    
    # On-target metrics
    on_target_metrics = calculator.compute_on_target_metrics(
        on_target_pred[on_target_mask],
        on_target_target[on_target_mask]
    )
    
    # Off-target metrics
    off_target_metrics = calculator.compute_off_target_metrics(
        off_target_pred[off_target_mask],
        off_target_target[off_target_mask]
    )
    
    # Combined metrics
    all_metrics = calculator.compute_all_metrics(
        on_target_pred=on_target_pred,
        off_target_pred=off_target_pred,
        on_target_target=on_target_target,
        off_target_target=off_target_target,
        on_target_mask=on_target_mask,
        off_target_mask=off_target_mask
    )
    
    metrics = {
        'on_target': on_target_metrics,
        'off_target': off_target_metrics,
        'combined': all_metrics
    }
    
    logger.info("Metrics computed")
    
    return metrics


def plot_roc_curve(off_target_pred: np.ndarray,
                  off_target_target: np.ndarray,
                  off_target_mask: np.ndarray,
                  output_dir: Path) -> None:
    """
    Plot ROC curve for off-target prediction
    
    Args:
        off_target_pred: Predictions
        off_target_target: Targets
        off_target_mask: Mask
        output_dir: Output directory
    """
    try:
        # Filter valid samples
        pred = off_target_pred[off_target_mask]
        target = off_target_target[off_target_mask]
        
        # Compute ROC curve
        fpr, tpr, _ = roc_curve(target, pred)
        roc_auc = auc(fpr, tpr)
        
        # Plot
        plt.figure(figsize=(8, 6))
        plt.plot(fpr, tpr, color='darkorange', lw=2, label=f'ROC curve (AUC = {roc_auc:.3f})')
        plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--', label='Random')
        plt.xlim([0.0, 1.0])
        plt.ylim([0.0, 1.05])
        plt.xlabel('False Positive Rate')
        plt.ylabel('True Positive Rate')
        plt.title('ROC Curve - Off-Target Prediction')
        plt.legend(loc="lower right")
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(output_dir / 'roc_curve.png', dpi=150)
        plt.close()
        
        logger.info(f"ROC curve saved to {output_dir / 'roc_curve.png'}")
    
    except Exception as e:
        logger.warning(f"Failed to plot ROC curve: {e}")


def plot_precision_recall_curve(off_target_pred: np.ndarray,
                               off_target_target: np.ndarray,
                               off_target_mask: np.ndarray,
                               output_dir: Path) -> None:
    """
    Plot Precision-Recall curve for off-target prediction
    
    Args:
        off_target_pred: Predictions
        off_target_target: Targets
        off_target_mask: Mask
        output_dir: Output directory
    """
    try:
        # Filter valid samples
        pred = off_target_pred[off_target_mask]
        target = off_target_target[off_target_mask]
        
        # Compute PR curve
        precision, recall, _ = precision_recall_curve(target, pred)
        pr_auc = auc(recall, precision)
        
        # Plot
        plt.figure(figsize=(8, 6))
        plt.plot(recall, precision, color='darkorange', lw=2, label=f'PR curve (AUC = {pr_auc:.3f})')
        plt.xlim([0.0, 1.0])
        plt.ylim([0.0, 1.05])
        plt.xlabel('Recall')
        plt.ylabel('Precision')
        plt.title('Precision-Recall Curve - Off-Target Prediction')
        plt.legend(loc="lower left")
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(output_dir / 'precision_recall_curve.png', dpi=150)
        plt.close()
        
        logger.info(f"Precision-Recall curve saved to {output_dir / 'precision_recall_curve.png'}")
    
    except Exception as e:
        logger.warning(f"Failed to plot Precision-Recall curve: {e}")


def plot_scatter(on_target_pred: np.ndarray,
                on_target_target: np.ndarray,
                on_target_mask: np.ndarray,
                output_dir: Path) -> None:
    """
    Plot scatter: predicted vs actual for on-target
    
    Args:
        on_target_pred: Predictions
        on_target_target: Targets
        on_target_mask: Mask
        output_dir: Output directory
    """
    try:
        # Filter valid samples
        pred = on_target_pred[on_target_mask]
        target = on_target_target[on_target_mask]
        
        # Plot
        plt.figure(figsize=(8, 8))
        plt.scatter(target, pred, alpha=0.5, s=20)
        
        # Add diagonal line
        min_val = min(target.min(), pred.min())
        max_val = max(target.max(), pred.max())
        plt.plot([min_val, max_val], [min_val, max_val], 'r--', lw=2, label='Perfect prediction')
        
        plt.xlabel('Actual On-Target Score')
        plt.ylabel('Predicted On-Target Score')
        plt.title('On-Target Prediction: Predicted vs Actual')
        plt.legend()
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(output_dir / 'scatter_on_target.png', dpi=150)
        plt.close()
        
        logger.info(f"Scatter plot saved to {output_dir / 'scatter_on_target.png'}")
    
    except Exception as e:
        logger.warning(f"Failed to plot scatter: {e}")


def plot_correlation_heatmap(on_target_pred: np.ndarray,
                            on_target_target: np.ndarray,
                            off_target_pred: np.ndarray,
                            off_target_target: np.ndarray,
                            on_target_mask: np.ndarray,
                            off_target_mask: np.ndarray,
                            output_dir: Path) -> None:
    """
    Plot correlation heatmap
    
    Args:
        on_target_pred: On-target predictions
        on_target_target: On-target targets
        off_target_pred: Off-target predictions
        off_target_target: Off-target targets
        on_target_mask: On-target mask
        off_target_mask: Off-target mask
        output_dir: Output directory
    """
    try:
        # Create correlation matrix
        data = {
            'On-Target Pred': on_target_pred[on_target_mask],
            'On-Target Target': on_target_target[on_target_mask],
            'Off-Target Pred': off_target_pred[off_target_mask],
            'Off-Target Target': off_target_target[off_target_mask]
        }
        
        df = pd.DataFrame(data)
        corr = df.corr()
        
        # Plot
        plt.figure(figsize=(8, 6))
        sns.heatmap(corr, annot=True, cmap='coolwarm', center=0, vmin=-1, vmax=1)
        plt.title('Correlation Heatmap')
        plt.tight_layout()
        plt.savefig(output_dir / 'correlation_heatmap.png', dpi=150)
        plt.close()
        
        logger.info(f"Correlation heatmap saved to {output_dir / 'correlation_heatmap.png'}")
    
    except Exception as e:
        logger.warning(f"Failed to plot correlation heatmap: {e}")


def save_predictions(on_target_pred: np.ndarray,
                    on_target_target: np.ndarray,
                    off_target_pred: np.ndarray,
                    off_target_target: np.ndarray,
                    on_target_mask: np.ndarray,
                    off_target_mask: np.ndarray,
                    output_dir: Path) -> None:
    """
    Save predictions to CSV
    
    Args:
        on_target_pred: On-target predictions
        on_target_target: On-target targets
        off_target_pred: Off-target predictions
        off_target_target: Off-target targets
        on_target_mask: On-target mask
        off_target_mask: Off-target mask
        output_dir: Output directory
    """
    try:
        # Create dataframe
        df = pd.DataFrame({
            'on_target_pred': on_target_pred,
            'on_target_target': on_target_target,
            'on_target_mask': on_target_mask,
            'off_target_pred': off_target_pred,
            'off_target_target': off_target_target,
            'off_target_mask': off_target_mask
        })
        
        # Save
        output_dir.mkdir(parents=True, exist_ok=True)
        csv_path = output_dir / 'predictions.csv'
        df.to_csv(csv_path, index=False)
        
        logger.info(f"Predictions saved to {csv_path}")
    
    except Exception as e:
        logger.warning(f"Failed to save predictions: {e}")


def save_metrics(metrics: Dict, output_dir: Path) -> None:
    """
    Save metrics to JSON
    
    Args:
        metrics: Metrics dictionary
        output_dir: Output directory
    """
    try:
        output_dir.mkdir(parents=True, exist_ok=True)
        
        # Convert to JSON-serializable format
        metrics_json = {}
        for task, task_metrics in metrics.items():
            metrics_json[task] = {}
            for key, value in task_metrics.items():
                if isinstance(value, (dict, list)):
                    # Skip complex nested structures
                    continue
                elif isinstance(value, np.ndarray):
                    metrics_json[task][key] = value.tolist()
                elif isinstance(value, (np.integer, np.floating)):
                    metrics_json[task][key] = float(value)
                else:
                    metrics_json[task][key] = value
        
        # Save
        json_path = output_dir / 'metrics.json'
        with open(json_path, 'w') as f:
            json.dump(metrics_json, f, indent=2)
        
        logger.info(f"Metrics saved to {json_path}")
    
    except Exception as e:
        logger.warning(f"Failed to save metrics: {e}")


def print_metrics_summary(metrics: Dict) -> None:
    """
    Print metrics summary to console
    
    Args:
        metrics: Metrics dictionary
    """
    logger.info("\n" + "=" * 80)
    logger.info("EVALUATION RESULTS")
    logger.info("=" * 80)
    
    # On-target metrics
    logger.info("\nON-TARGET METRICS (Regression):")
    for key, value in metrics['on_target'].items():
        if not isinstance(value, dict):
            logger.info(f"  {key}: {value:.6f}")
    
    # Off-target metrics
    logger.info("\nOFF-TARGET METRICS (Classification):")
    for key, value in metrics['off_target'].items():
        if not isinstance(value, dict):
            logger.info(f"  {key}: {value:.6f}")
    
    logger.info("=" * 80 + "\n")


def parse_arguments():
    """Parse command-line arguments"""
    parser = argparse.ArgumentParser(
        description='Evaluate CRISPR-UniPredict model',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python scripts/evaluate.py \\
    --checkpoint models/checkpoints/best.pt \\
    --test_data data/processed/combined/test.csv \\
    --output_dir results/exp_001
        """
    )
    
    parser.add_argument(
        '--checkpoint',
        type=str,
        required=True,
        help='Path to trained model checkpoint'
    )
    
    parser.add_argument(
        '--test_data',
        type=str,
        required=True,
        help='Path to test data CSV'
    )
    
    parser.add_argument(
        '--output_dir',
        type=str,
        default='results/evaluation',
        help='Output directory for results'
    )
    
    parser.add_argument(
        '--batch_size',
        type=int,
        default=64,
        help='Batch size for inference'
    )
    
    parser.add_argument(
        '--device',
        type=str,
        default='cuda' if torch.cuda.is_available() else 'cpu',
        help='Device to use (cuda or cpu)'
    )
    
    return parser.parse_args()


def main():
    """Main evaluation function"""
    
    # Parse arguments
    args = parse_arguments()
    
    # Setup output directory
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Setup logging
    global logger
    logger = setup_logging(output_dir)
    
    logger.info("=" * 80)
    logger.info("CRISPR-UniPredict Evaluation")
    logger.info("=" * 80)
    logger.info(f"Checkpoint: {args.checkpoint}")
    logger.info(f"Test data: {args.test_data}")
    logger.info(f"Output directory: {output_dir}")
    logger.info(f"Device: {args.device}")
    
    try:
        # Load checkpoint
        logger.info("Loading checkpoint...")
        model, checkpoint = load_checkpoint(args.checkpoint, args.device)
        
        # Load test dataset
        logger.info("Loading test dataset...")
        dataset = load_test_dataset(args.test_data, args.device)
        
        # Run predictions
        logger.info("Running predictions...")
        on_target_pred, on_target_target, off_target_pred, off_target_target, on_target_mask, off_target_mask = \
            run_predictions(model, dataset, args.device, args.batch_size)
        
        # Compute metrics
        logger.info("Computing metrics...")
        metrics = compute_metrics(
            on_target_pred, on_target_target,
            off_target_pred, off_target_target,
            on_target_mask, off_target_mask
        )
        
        # Create plots directory
        plots_dir = output_dir / 'plots'
        plots_dir.mkdir(parents=True, exist_ok=True)
        
        # Generate visualizations
        logger.info("Generating visualizations...")
        plot_roc_curve(off_target_pred, off_target_target, off_target_mask, plots_dir)
        plot_precision_recall_curve(off_target_pred, off_target_target, off_target_mask, plots_dir)
        plot_scatter(on_target_pred, on_target_target, on_target_mask, plots_dir)
        plot_correlation_heatmap(
            on_target_pred, on_target_target,
            off_target_pred, off_target_target,
            on_target_mask, off_target_mask,
            plots_dir
        )
        
        # Save results
        logger.info("Saving results...")
        save_metrics(metrics, output_dir / 'metrics')
        save_predictions(
            on_target_pred, on_target_target,
            off_target_pred, off_target_target,
            on_target_mask, off_target_mask,
            output_dir / 'predictions'
        )
        
        # Print summary
        print_metrics_summary(metrics)
        
        logger.info("Evaluation completed successfully!")
        logger.info(f"Results saved to {output_dir}")
        
        return 0
    
    except Exception as e:
        logger.error(f"Evaluation failed with error: {e}", exc_info=True)
        return 1


if __name__ == '__main__':
    sys.exit(main())
