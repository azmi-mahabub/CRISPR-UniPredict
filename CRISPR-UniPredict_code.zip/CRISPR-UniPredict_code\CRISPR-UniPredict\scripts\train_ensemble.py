"""
Training script for ensemble models
Trains multiple model variants and combines them into an ensemble
"""

import argparse
import sys
import logging
import json
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Tuple
import numpy as np
import torch
from copy import deepcopy

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from configs.config_loader import ConfigLoader
from models.crispr_unipredict import CRISPRUniPredict
from models.ensemble_model import EnsembleModel, EnsembleConfig, MetaModel
from utils.preprocessing.dataloader_factory import DataLoaderFactory
from training.trainer import Trainer
from utils.evaluation.metrics import MetricsCalculator

logger = logging.getLogger(__name__)


class EnsembleTrainer:
    """Train ensemble of models"""
    
    def __init__(self,
                 base_config_path: str,
                 n_models: int = 5,
                 output_dir: str = 'models/ensemble',
                 ensemble_method: str = 'weighted_average'):
        """
        Initialize ensemble trainer
        
        Args:
            base_config_path: Path to base configuration
            n_models: Number of models to train
            output_dir: Output directory for ensemble
            ensemble_method: Ensemble method to use
        """
        self.base_config_path = Path(base_config_path)
        self.n_models = n_models
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.ensemble_method = ensemble_method
        
        # Load base configuration
        self.config_loader = ConfigLoader(str(self.base_config_path))
        self.base_config = self.config_loader.config
        
        # Setup logging
        self._setup_logging()
        
        # Results tracking
        self.model_checkpoints = []
        self.model_metrics = []
        
        logger.info(f"EnsembleTrainer initialized: {n_models} models, method: {ensemble_method}")
    
    def _setup_logging(self) -> None:
        """Setup logging"""
        log_file = self.output_dir / 'ensemble_training.log'
        handler = logging.FileHandler(log_file)
        handler.setLevel(logging.INFO)
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        handler.setFormatter(formatter)
        logger.addHandler(handler)
    
    def _create_variant_config(self, variant_id: int) -> Dict:
        """
        Create configuration for a model variant
        
        Args:
            variant_id: Variant ID (0-4)
        
        Returns:
            Modified configuration
        """
        from dataclasses import asdict, is_dataclass
        
        if is_dataclass(self.base_config):
            config_dict = asdict(self.base_config)
        else:
            config_dict = deepcopy(self.base_config)
        
        # Variant 0: Full model (default)
        if variant_id == 0:
            pass  # Use base config
        
        # Variant 1: Different random seed
        elif variant_id == 1:
            if 'training' in config_dict:
                config_dict['training']['seed'] = 123
        
        # Variant 2: Different train/val split
        elif variant_id == 2:
            if 'data' in config_dict:
                config_dict['data']['val_split'] = 0.15  # Different split
        
        # Variant 3: Focus on on-target (higher weight)
        elif variant_id == 3:
            if 'training' in config_dict and 'loss' in config_dict['training']:
                config_dict['training']['loss']['loss_weights'] = {
                    'on_target': 0.7,
                    'off_target': 0.3
                }
        
        # Variant 4: Focus on off-target (higher weight)
        elif variant_id == 4:
            if 'training' in config_dict and 'loss' in config_dict['training']:
                config_dict['training']['loss']['loss_weights'] = {
                    'on_target': 0.3,
                    'off_target': 0.7
                }
        
        return config_dict
    
    def train_single_model(self, variant_id: int) -> Tuple[str, Dict]:
        """
        Train a single model variant
        
        Args:
            variant_id: Variant ID
        
        Returns:
            Tuple of (checkpoint_path, metrics)
        """
        logger.info(f"\n{'='*80}")
        logger.info(f"Training Model {variant_id + 1}/{self.n_models}")
        logger.info(f"{'='*80}")
        
        # Create variant configuration
        variant_config = self._create_variant_config(variant_id)
        
        # Setup device
        device = 'cuda' if torch.cuda.is_available() else 'cpu'
        logger.info(f"Using device: {device}")
        
        # Create model
        model = CRISPRUniPredict(device=device)
        
        # Create dataloaders
        dataloader_factory = DataLoaderFactory(variant_config)
        dataloaders = dataloader_factory.create_dataloaders()
        
        # Create trainer
        trainer = Trainer(model, dataloaders, variant_config)
        
        # Train
        logger.info(f"Starting training for variant {variant_id}")
        history = trainer.train()
        
        # Get best metrics
        if history['val']:
            best_metrics = history['val'][-1]
        else:
            best_metrics = {}
        
        # Save checkpoint
        checkpoint_path = self.output_dir / f'model_{variant_id}_best.pt'
        torch.save({
            'model_state_dict': model.state_dict(),
            'config': variant_config,
            'metrics': best_metrics,
            'variant_id': variant_id
        }, checkpoint_path)
        
        logger.info(f"Saved checkpoint to {checkpoint_path}")
        
        # Extract metrics
        metrics = {
            'variant_id': variant_id,
            'checkpoint': str(checkpoint_path),
            'val_loss': best_metrics.get('total_loss', float('inf')),
            'on_target_scc': best_metrics.get('on_target_spearman', 0.0),
            'on_target_pcc': best_metrics.get('on_target_pearson', 0.0),
            'off_target_auroc': best_metrics.get('off_target_auroc', 0.0),
            'off_target_auprc': best_metrics.get('off_target_auprc', 0.0)
        }
        
        logger.info(f"Model {variant_id} Results:")
        logger.info(f"  SCC: {metrics['on_target_scc']:.4f}")
        logger.info(f"  AUROC: {metrics['off_target_auroc']:.4f}")
        
        return str(checkpoint_path), metrics
    
    def train_all_models(self) -> List[str]:
        """
        Train all model variants
        
        Returns:
            List of checkpoint paths
        """
        logger.info(f"Starting ensemble training: {self.n_models} models")
        
        for variant_id in range(self.n_models):
            checkpoint_path, metrics = self.train_single_model(variant_id)
            self.model_checkpoints.append(checkpoint_path)
            self.model_metrics.append(metrics)
        
        logger.info(f"\nCompleted training all {self.n_models} models")
        
        return self.model_checkpoints
    
    def create_ensemble(self) -> EnsembleModel:
        """
        Create ensemble from trained models
        
        Returns:
            EnsembleModel instance
        """
        logger.info(f"\nCreating ensemble from {len(self.model_checkpoints)} models")
        
        # Create ensemble
        ensemble = EnsembleModel(
            model_checkpoints=self.model_checkpoints,
            config=EnsembleConfig(
                n_models=len(self.model_checkpoints),
                ensemble_method=self.ensemble_method,
                device='cuda' if torch.cuda.is_available() else 'cpu'
            )
        )
        
        # Compute weights based on validation performance
        scc_scores = [m['on_target_scc'] for m in self.model_metrics]
        auroc_scores = [m['off_target_auroc'] for m in self.model_metrics]
        
        ensemble.compute_weights(scc_scores, auroc_scores)
        
        logger.info(f"Ensemble created with weights: {ensemble.weights}")
        
        return ensemble
    
    def train_meta_model(self,
                        ensemble: EnsembleModel,
                        dataloaders: Dict) -> str:
        """
        Train meta-model for stacking
        
        Args:
            ensemble: Ensemble model
            dataloaders: Data loaders
        
        Returns:
            Path to meta-model checkpoint
        """
        if not ensemble.meta_model:
            logger.warning("Meta-model not initialized, skipping meta-model training")
            return None
        
        logger.info("\nTraining meta-model for stacking")
        
        device = ensemble.device
        meta_model = ensemble.meta_model
        
        # Setup optimizer
        optimizer = torch.optim.Adam(meta_model.parameters(), lr=1e-3)
        criterion = torch.nn.MSELoss()
        
        # Training loop
        num_epochs = 10
        best_loss = float('inf')
        patience_counter = 0
        
        for epoch in range(num_epochs):
            # Training
            meta_model.train()
            train_loss = 0.0
            batch_count = 0
            
            for batch in dataloaders['train']:
                sgrna_onehot = batch['sgrna_onehot'].to(device)
                sgrna_label = batch['sgrna_label'].to(device)
                on_target_target = batch['on_target_score'].to(device)
                off_target_target = batch['off_target_label'].to(device)
                
                # Get predictions from all models
                all_predictions = []
                with torch.no_grad():
                    for model in ensemble.models:
                        on_target, off_target = model(sgrna_onehot, sgrna_label, task_type='both')
                        predictions = torch.cat([on_target, off_target], dim=1)
                        all_predictions.append(predictions)
                
                # Meta-model input
                meta_input = torch.cat(all_predictions, dim=1)
                
                # Meta-model prediction
                meta_output = meta_model(meta_input)
                
                # Loss
                target = torch.cat([on_target_target, off_target_target], dim=1)
                loss = criterion(meta_output, target)
                
                # Backward
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()
                
                train_loss += loss.item()
                batch_count += 1
            
            train_loss /= max(batch_count, 1)
            
            # Validation
            meta_model.eval()
            val_loss = 0.0
            batch_count = 0
            
            with torch.no_grad():
                for batch in dataloaders['val']:
                    sgrna_onehot = batch['sgrna_onehot'].to(device)
                    sgrna_label = batch['sgrna_label'].to(device)
                    on_target_target = batch['on_target_score'].to(device)
                    off_target_target = batch['off_target_label'].to(device)
                    
                    # Get predictions from all models
                    all_predictions = []
                    for model in ensemble.models:
                        on_target, off_target = model(sgrna_onehot, sgrna_label, task_type='both')
                        predictions = torch.cat([on_target, off_target], dim=1)
                        all_predictions.append(predictions)
                    
                    # Meta-model input
                    meta_input = torch.cat(all_predictions, dim=1)
                    
                    # Meta-model prediction
                    meta_output = meta_model(meta_input)
                    
                    # Loss
                    target = torch.cat([on_target_target, off_target_target], dim=1)
                    loss = criterion(meta_output, target)
                    
                    val_loss += loss.item()
                    batch_count += 1
            
            val_loss /= max(batch_count, 1)
            
            logger.info(f"Meta-model Epoch {epoch + 1}/{num_epochs}: Train Loss={train_loss:.6f}, Val Loss={val_loss:.6f}")
            
            # Early stopping
            if val_loss < best_loss:
                best_loss = val_loss
                patience_counter = 0
                
                # Save best checkpoint
                meta_checkpoint_path = self.output_dir / 'meta_model_best.pt'
                torch.save({
                    'model_state_dict': meta_model.state_dict(),
                    'epoch': epoch,
                    'loss': val_loss
                }, meta_checkpoint_path)
            else:
                patience_counter += 1
                if patience_counter >= 3:
                    logger.info(f"Early stopping at epoch {epoch + 1}")
                    break
        
        logger.info(f"Meta-model training completed. Best loss: {best_loss:.6f}")
        
        return str(meta_checkpoint_path)
    
    def evaluate_ensemble(self,
                         ensemble: EnsembleModel,
                         dataloaders: Dict) -> Dict:
        """
        Evaluate ensemble on validation set
        
        Args:
            ensemble: Ensemble model
            dataloaders: Data loaders
        
        Returns:
            Dictionary with metrics
        """
        logger.info("\nEvaluating ensemble")
        
        device = ensemble.device
        metrics_calculator = MetricsCalculator()
        
        all_on_target_pred = []
        all_on_target_target = []
        all_off_target_pred = []
        all_off_target_target = []
        
        with torch.no_grad():
            for batch in dataloaders['val']:
                sgrna_onehot = batch['sgrna_onehot'].to(device)
                sgrna_label = batch['sgrna_label'].to(device)
                on_target_score = batch['on_target_score'].to(device)
                off_target_label = batch['off_target_label'].to(device)
                on_target_mask = batch['on_target_mask'].to(device)
                off_target_mask = batch['off_target_mask'].to(device)
                
                # Get ensemble predictions
                on_target_pred, off_target_pred = ensemble.predict(
                    sgrna_onehot, sgrna_label,
                    method=self.ensemble_method
                )
                
                # Collect predictions
                all_on_target_pred.append(on_target_pred[on_target_mask].cpu())
                all_on_target_target.append(on_target_score[on_target_mask].cpu())
                all_off_target_pred.append(off_target_pred[off_target_mask].cpu())
                all_off_target_target.append(off_target_label[off_target_mask].cpu())
        
        # Compute metrics
        if all_on_target_pred:
            on_target_pred_all = torch.cat(all_on_target_pred)
            on_target_target_all = torch.cat(all_on_target_target)
            on_target_metrics = metrics_calculator.compute_on_target_metrics(
                on_target_pred_all, on_target_target_all
            )
        else:
            on_target_metrics = {}
        
        if all_off_target_pred:
            off_target_pred_all = torch.cat(all_off_target_pred)
            off_target_target_all = torch.cat(all_off_target_target)
            off_target_metrics = metrics_calculator.compute_off_target_metrics(
                off_target_pred_all, off_target_target_all
            )
        else:
            off_target_metrics = {}
        
        # Combine metrics
        ensemble_metrics = {
            'ensemble_method': self.ensemble_method,
            'on_target': on_target_metrics,
            'off_target': off_target_metrics
        }
        
        logger.info(f"Ensemble Metrics:")
        logger.info(f"  On-target SCC: {on_target_metrics.get('spearman', 0.0):.4f}")
        logger.info(f"  Off-target AUROC: {off_target_metrics.get('auroc', 0.0):.4f}")
        
        return ensemble_metrics
    
    def save_ensemble(self, ensemble: EnsembleModel, meta_model_path: str = None) -> None:
        """
        Save ensemble configuration and metadata
        
        Args:
            ensemble: Ensemble model
            meta_model_path: Path to meta-model checkpoint
        """
        # Save ensemble config
        ensemble_config = {
            'n_models': len(ensemble.models),
            'ensemble_method': self.ensemble_method,
            'model_checkpoints': self.model_checkpoints,
            'weights': ensemble.weights.tolist(),
            'model_metrics': self.model_metrics,
            'meta_model_path': meta_model_path,
            'timestamp': datetime.now().isoformat()
        }
        
        config_path = self.output_dir / 'ensemble_config.json'
        with open(config_path, 'w') as f:
            json.dump(ensemble_config, f, indent=2)
        
        logger.info(f"Saved ensemble config to {config_path}")
        
        # Save summary
        summary = {
            'n_models': len(ensemble.models),
            'ensemble_method': self.ensemble_method,
            'individual_model_metrics': self.model_metrics,
            'ensemble_weights': ensemble.weights.tolist()
        }
        
        summary_path = self.output_dir / 'ensemble_summary.json'
        with open(summary_path, 'w') as f:
            json.dump(summary, f, indent=2)
        
        logger.info(f"Saved ensemble summary to {summary_path}")
    
    def print_summary(self, ensemble_metrics: Dict = None) -> None:
        """Print training summary"""
        print("\n" + "="*80)
        print("ENSEMBLE TRAINING SUMMARY")
        print("="*80)
        
        print(f"\nIndividual Model Metrics:")
        for metrics in self.model_metrics:
            print(f"\n  Model {metrics['variant_id']}:")
            print(f"    SCC: {metrics['on_target_scc']:.4f}")
            print(f"    AUROC: {metrics['off_target_auroc']:.4f}")
        
        if ensemble_metrics:
            print(f"\nEnsemble Metrics ({self.ensemble_method}):")
            on_target = ensemble_metrics.get('on_target', {})
            off_target = ensemble_metrics.get('off_target', {})
            print(f"  On-target SCC: {on_target.get('spearman', 0.0):.4f}")
            print(f"  Off-target AUROC: {off_target.get('auroc', 0.0):.4f}")
        
        print("\n" + "="*80)


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(description='Train ensemble of models')
    parser.add_argument('--base_config', type=str, default='configs/model_config.yaml',
                       help='Base configuration file')
    parser.add_argument('--n_models', type=int, default=5, help='Number of models to train')
    parser.add_argument('--output_dir', type=str, default='models/ensemble',
                       help='Output directory')
    parser.add_argument('--ensemble_method', type=str, default='weighted_average',
                       choices=['simple_average', 'weighted_average', 'stacking', 'voting'],
                       help='Ensemble method')
    parser.add_argument('--train_meta_model', action='store_true',
                       help='Train meta-model for stacking')
    
    args = parser.parse_args()
    
    # Setup logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Create trainer
    trainer = EnsembleTrainer(
        base_config_path=args.base_config,
        n_models=args.n_models,
        output_dir=args.output_dir,
        ensemble_method=args.ensemble_method
    )
    
    # Train all models
    trainer.train_all_models()
    
    # Create ensemble
    ensemble = trainer.create_ensemble()
    
    # Train meta-model if requested
    meta_model_path = None
    if args.train_meta_model and args.ensemble_method == 'stacking':
        # Load dataloaders for meta-model training
        config_loader = ConfigLoader(args.base_config)
        dataloader_factory = DataLoaderFactory(config_loader.config)
        dataloaders = dataloader_factory.create_dataloaders()
        
        meta_model_path = trainer.train_meta_model(ensemble, dataloaders)
    
    # Evaluate ensemble
    config_loader = ConfigLoader(args.base_config)
    dataloader_factory = DataLoaderFactory(config_loader.config)
    dataloaders = dataloader_factory.create_dataloaders()
    
    ensemble_metrics = trainer.evaluate_ensemble(ensemble, dataloaders)
    
    # Save ensemble
    trainer.save_ensemble(ensemble, meta_model_path)
    
    # Print summary
    trainer.print_summary(ensemble_metrics)
    
    print(f"\nEnsemble saved to: {trainer.output_dir}")


if __name__ == '__main__':
    main()
