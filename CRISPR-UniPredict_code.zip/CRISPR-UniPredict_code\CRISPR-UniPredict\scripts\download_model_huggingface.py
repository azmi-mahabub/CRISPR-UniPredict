"""
Download RNA-FM model from HuggingFace
"""

import urllib.request
import urllib.error
from pathlib import Path
import sys

def download_with_progress(url, destination):
    """Download file with progress tracking"""
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    
    print(f"Downloading from HuggingFace...")
    print(f"URL: {url}")
    print(f"Destination: {destination}\n")
    
    def progress_hook(block_num, block_size, total_size):
        downloaded = block_num * block_size
        if total_size > 0:
            percent = min(100, (downloaded / total_size) * 100)
            mb_downloaded = downloaded / (1024 * 1024)
            mb_total = total_size / (1024 * 1024)
            print(f"\rProgress: {percent:.1f}% ({mb_downloaded:.1f}/{mb_total:.1f} MB)", 
                  end='', flush=True)
    
    try:
        urllib.request.urlretrieve(url, destination, reporthook=progress_hook)
        print("\n✓ Download completed!")
        
        # Verify
        size_mb = destination.stat().st_size / (1024 * 1024)
        print(f"✓ File size: {size_mb:.1f} MB")
        
        # Try to load
        try:
            import torch
            checkpoint = torch.load(destination, map_location='cpu')
            print(f"✓ Checkpoint verified!")
            print(f"✓ Model ready for use!")
            return True
        except Exception as e:
            print(f"⚠ Could not verify checkpoint: {e}")
            return False
            
    except urllib.error.URLError as e:
        print(f"\n✗ Download failed: {e}")
        return False
    except Exception as e:
        print(f"\n✗ Error: {e}")
        return False

if __name__ == "__main__":
    url = "https://huggingface.co/facebook/rna-fm/resolve/main/rna_fm_t12.pt"
    destination = Path(__file__).parent.parent / "models" / "pretrained" / "rna_fm_t12.pt"
    
    success = download_with_progress(url, destination)
    sys.exit(0 if success else 1)
