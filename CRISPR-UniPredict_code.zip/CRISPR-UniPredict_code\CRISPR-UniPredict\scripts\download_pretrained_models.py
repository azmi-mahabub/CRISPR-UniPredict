"""
Download Pretrained Models for CRISPR-UniPredict
Downloads RNA-FM and other pretrained models for model training
"""

import os
import sys
from pathlib import Path
import subprocess
import urllib.request
import urllib.error
from typing import Dict, Optional, Tuple
import json
from datetime import datetime
import hashlib

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))


class PretrainedModelDownloader:
    """Download and verify pretrained models"""
    
    # Model configurations
    MODELS = {
        'rna_fm_t12': {
            'name': 'RNA-FM (t12)',
            'size_mb': 700,
            'url_direct': 'https://dl.fbaipublicfiles.com/fair-esm/models/rna_fm_t12.pt',
            'url_huggingface': 'https://huggingface.co/facebook/rna-fm/resolve/main/rna_fm_t12.pt',
            'description': 'RNA Foundation Model (12 layers)'
        },
        'esmfold_esmif1': {
            'name': 'ESMFold ESM-IF1',
            'size_mb': 500,
            'url_direct': 'https://dl.fbaipublicfiles.com/fair-esm/models/esmif1_model_weights_pt.pth',
            'description': 'ESMFold structure prediction model'
        }
    }
    
    def __init__(self, base_dir=None):
        """
        Initialize downloader
        
        Args:
            base_dir: Base directory for models
        """
        if base_dir is None:
            base_dir = Path(__file__).parent.parent / "models"
        
        self.base_dir = Path(base_dir)
        self.pretrained_dir = self.base_dir / "pretrained"
        self.pretrained_dir.mkdir(parents=True, exist_ok=True)
        
        self.download_log = {
            'timestamp': datetime.now().isoformat(),
            'downloads': {},
            'errors': []
        }
    
    def check_fair_esm_installed(self) -> bool:
        """Check if fair-esm is installed"""
        print(f"\n{'─' * 80}")
        print(f"CHECKING FAIR-ESM INSTALLATION")
        print(f"{'─' * 80}\n")
        
        try:
            import fair_esm
            print(f"✓ fair-esm is installed")
            print(f"  Version: {fair_esm.__version__ if hasattr(fair_esm, '__version__') else 'Unknown'}")
            return True
        except ImportError:
            print(f"✗ fair-esm is not installed")
            return False
    
    def install_fair_esm(self) -> bool:
        """Install fair-esm package"""
        print(f"\n{'─' * 80}")
        print(f"INSTALLING FAIR-ESM")
        print(f"{'─' * 80}\n")
        
        try:
            print(f"Installing fair-esm...")
            subprocess.check_call([
                sys.executable, '-m', 'pip', 'install', 
                'fair-esm', '--quiet'
            ])
            print(f"✓ fair-esm installed successfully")
            return True
        except subprocess.CalledProcessError as e:
            print(f"✗ Failed to install fair-esm: {str(e)}")
            self.download_log['errors'].append(f"Failed to install fair-esm: {str(e)}")
            return False
    
    def download_file(self, url: str, destination: Path, 
                     timeout: int = 300) -> Tuple[bool, Optional[str]]:
        """
        Download file from URL
        
        Args:
            url: URL to download from
            destination: Path to save file
            timeout: Download timeout in seconds
            
        Returns:
            Tuple of (success, error_message)
        """
        try:
            print(f"  Downloading from: {url}")
            
            # Create progress callback
            def download_progress(block_num, block_size, total_size):
                downloaded = block_num * block_size
                if total_size > 0:
                    percent = min(100, (downloaded / total_size) * 100)
                    mb_downloaded = downloaded / (1024 * 1024)
                    mb_total = total_size / (1024 * 1024)
                    print(f"\r    Progress: {percent:.1f}% ({mb_downloaded:.1f}/{mb_total:.1f} MB)", 
                          end='', flush=True)
            
            # Download file
            urllib.request.urlretrieve(url, destination, reporthook=download_progress)
            print()  # New line after progress
            
            return True, None
            
        except urllib.error.URLError as e:
            error_msg = f"URL Error: {str(e)}"
            print(f"\n  ✗ {error_msg}")
            return False, error_msg
        except Exception as e:
            error_msg = f"Download error: {str(e)}"
            print(f"\n  ✗ {error_msg}")
            return False, error_msg
    
    def verify_file_size(self, file_path: Path, expected_size_mb: int, 
                        tolerance_pct: float = 10) -> Tuple[bool, str]:
        """
        Verify downloaded file size
        
        Args:
            file_path: Path to file
            expected_size_mb: Expected size in MB
            tolerance_pct: Tolerance percentage
            
        Returns:
            Tuple of (is_valid, message)
        """
        if not file_path.exists():
            return False, "File does not exist"
        
        file_size_mb = file_path.stat().st_size / (1024 * 1024)
        tolerance_mb = expected_size_mb * (tolerance_pct / 100)
        min_size = expected_size_mb - tolerance_mb
        max_size = expected_size_mb + tolerance_mb
        
        if min_size <= file_size_mb <= max_size:
            return True, f"Size OK: {file_size_mb:.1f} MB (expected ~{expected_size_mb} MB)"
        else:
            return False, f"Size mismatch: {file_size_mb:.1f} MB (expected ~{expected_size_mb} MB)"
    
    def verify_checkpoint(self, file_path: Path) -> Tuple[bool, str]:
        """
        Verify checkpoint by loading it
        
        Args:
            file_path: Path to checkpoint file
            
        Returns:
            Tuple of (is_valid, message)
        """
        try:
            import torch
            
            print(f"  Verifying checkpoint...")
            checkpoint = torch.load(file_path, map_location='cpu')
            
            # Check if it's a valid checkpoint
            if isinstance(checkpoint, dict):
                keys = list(checkpoint.keys())
                msg = f"Checkpoint loaded successfully. Keys: {keys[:5]}{'...' if len(keys) > 5 else ''}"
                return True, msg
            else:
                msg = f"Checkpoint loaded. Type: {type(checkpoint)}"
                return True, msg
                
        except Exception as e:
            return False, f"Failed to load checkpoint: {str(e)}"
    
    def download_method_a_direct(self, model_key: str) -> bool:
        """
        Method A: Direct download from Facebook AI Research
        
        Args:
            model_key: Model key from MODELS dict
            
        Returns:
            True if successful
        """
        print(f"\n{'─' * 80}")
        print(f"METHOD A: DIRECT DOWNLOAD (Facebook AI Research)")
        print(f"{'─' * 80}\n")
        
        model_info = self.MODELS[model_key]
        url = model_info['url_direct']
        destination = self.pretrained_dir / f"{model_key}.pt"
        
        print(f"Model: {model_info['name']}")
        print(f"Expected size: ~{model_info['size_mb']} MB")
        print(f"Destination: {destination}\n")
        
        # Download file
        success, error = self.download_file(url, destination)
        
        if not success:
            print(f"✗ Download failed: {error}")
            self.download_log['errors'].append(f"{model_key} (Method A): {error}")
            return False
        
        print(f"✓ Download completed")
        
        # Verify file size
        size_valid, size_msg = self.verify_file_size(destination, model_info['size_mb'])
        print(f"  {size_msg}")
        
        if not size_valid:
            print(f"  ⚠ Warning: File size may be incorrect")
        
        # Verify checkpoint
        checkpoint_valid, checkpoint_msg = self.verify_checkpoint(destination)
        print(f"  {checkpoint_msg}")
        
        if checkpoint_valid:
            print(f"\n✓ {model_key} downloaded and verified successfully!")
            self.download_log['downloads'][model_key] = {
                'method': 'A (Direct)',
                'status': 'success',
                'file': str(destination),
                'size_mb': destination.stat().st_size / (1024 * 1024)
            }
            return True
        else:
            print(f"\n✗ Checkpoint verification failed")
            self.download_log['errors'].append(f"{model_key} (Method A): Checkpoint verification failed")
            return False
    
    def download_method_b_fair_esm_api(self, model_key: str) -> bool:
        """
        Method B: Use fair-esm Python API
        
        Args:
            model_key: Model key from MODELS dict
            
        Returns:
            True if successful
        """
        print(f"\n{'─' * 80}")
        print(f"METHOD B: FAIR-ESM PYTHON API")
        print(f"{'─' * 80}\n")
        
        try:
            import fair_esm
            
            model_info = self.MODELS[model_key]
            destination = self.pretrained_dir / f"{model_key}.pt"
            
            print(f"Model: {model_info['name']}")
            print(f"Expected size: ~{model_info['size_mb']} MB")
            print(f"Destination: {destination}\n")
            
            # Map model key to fair-esm model name
            fair_esm_models = {
                'rna_fm_t12': 'rna_fm_t12'
            }
            
            if model_key not in fair_esm_models:
                print(f"✗ Model {model_key} not supported by fair-esm API")
                return False
            
            fair_esm_model_name = fair_esm_models[model_key]
            
            print(f"Loading model via fair-esm API...")
            print(f"Model name: {fair_esm_model_name}\n")
            
            # Load model using fair-esm
            model_data = fair_esm.load_model_and_alphabet(fair_esm_model_name)
            
            print(f"✓ Model loaded successfully via fair-esm API")
            
            # Save model
            import torch
            torch.save(model_data[0].state_dict(), destination)
            print(f"✓ Model saved to {destination}")
            
            # Verify file
            size_valid, size_msg = self.verify_file_size(destination, model_info['size_mb'])
            print(f"  {size_msg}")
            
            checkpoint_valid, checkpoint_msg = self.verify_checkpoint(destination)
            print(f"  {checkpoint_msg}")
            
            if checkpoint_valid:
                print(f"\n✓ {model_key} downloaded and verified successfully!")
                self.download_log['downloads'][model_key] = {
                    'method': 'B (fair-esm API)',
                    'status': 'success',
                    'file': str(destination),
                    'size_mb': destination.stat().st_size / (1024 * 1024)
                }
                return True
            else:
                print(f"\n✗ Checkpoint verification failed")
                self.download_log['errors'].append(f"{model_key} (Method B): Checkpoint verification failed")
                return False
                
        except Exception as e:
            print(f"✗ Error using fair-esm API: {str(e)}")
            self.download_log['errors'].append(f"{model_key} (Method B): {str(e)}")
            return False
    
    def download_model(self, model_key: str, use_method_b_first: bool = False) -> bool:
        """
        Download model with fallback
        
        Args:
            model_key: Model key from MODELS dict
            use_method_b_first: Try Method B first before Method A
            
        Returns:
            True if successful
        """
        if model_key not in self.MODELS:
            print(f"✗ Unknown model: {model_key}")
            return False
        
        destination = self.pretrained_dir / f"{model_key}.pt"
        
        # Skip if already exists
        if destination.exists():
            print(f"\n✓ Model already exists: {destination}")
            return True
        
        # Try methods in order
        methods = [
            self.download_method_b_fair_esm_api,
            self.download_method_a_direct
        ] if use_method_b_first else [
            self.download_method_a_direct,
            self.download_method_b_fair_esm_api
        ]
        
        for method in methods:
            try:
                if method(model_key):
                    return True
            except Exception as e:
                print(f"✗ Error in {method.__name__}: {str(e)}")
                continue
        
        return False
    
    def print_model_info(self, model_key: str):
        """Print model information"""
        if model_key not in self.MODELS:
            return
        
        model_info = self.MODELS[model_key]
        print(f"\nModel Information:")
        print(f"  Name: {model_info['name']}")
        print(f"  Size: ~{model_info['size_mb']} MB")
        print(f"  Description: {model_info['description']}")
    
    def print_fallback_instructions(self, model_key: str):
        """Print fallback instructions if download fails"""
        print(f"\n{'─' * 80}")
        print(f"FALLBACK INSTRUCTIONS")
        print(f"{'─' * 80}\n")
        
        if model_key not in self.MODELS:
            return
        
        model_info = self.MODELS[model_key]
        destination = self.pretrained_dir / f"{model_key}.pt"
        
        print(f"If automatic download fails, you can manually download:")
        print(f"\n1. Download from Facebook AI Research:")
        print(f"   URL: {model_info['url_direct']}")
        print(f"\n2. Or download from HuggingFace:")
        if 'url_huggingface' in model_info:
            print(f"   URL: {model_info['url_huggingface']}")
        
        print(f"\n3. Save to:")
        print(f"   {destination}")
        
        print(f"\n4. Verify download:")
        print(f"   python -c \"import torch; torch.load('{destination}')\"")
        
        print(f"\n5. Or use wget/curl:")
        print(f"   wget -O {destination} {model_info['url_direct']}")
        print(f"   # or")
        print(f"   curl -L -o {destination} {model_info['url_direct']}")
    
    def download_all_models(self) -> bool:
        """Download all available models"""
        print("\n" + "=" * 80)
        print("DOWNLOADING PRETRAINED MODELS")
        print("=" * 80)
        
        # Check fair-esm
        if not self.check_fair_esm_installed():
            print(f"\nAttempting to install fair-esm...")
            if not self.install_fair_esm():
                print(f"⚠ Warning: Could not install fair-esm")
                print(f"  Will attempt direct download instead")
        
        # Download models
        all_success = True
        
        for model_key in ['rna_fm_t12']:
            self.print_model_info(model_key)
            
            success = self.download_model(model_key, use_method_b_first=False)
            
            if not success:
                print(f"\n✗ Failed to download {model_key}")
                self.print_fallback_instructions(model_key)
                all_success = False
        
        # Print summary
        self._print_summary()
        
        return all_success
    
    def _print_summary(self):
        """Print download summary"""
        print(f"\n{'─' * 80}")
        print(f"DOWNLOAD SUMMARY")
        print(f"{'─' * 80}\n")
        
        if self.download_log['downloads']:
            print(f"Successfully downloaded:")
            for model_key, info in self.download_log['downloads'].items():
                print(f"  ✓ {model_key}")
                print(f"    Method: {info['method']}")
                print(f"    Size: {info['size_mb']:.1f} MB")
                print(f"    Location: {info['file']}")
        
        if self.download_log['errors']:
            print(f"\nErrors encountered:")
            for error in self.download_log['errors']:
                print(f"  ✗ {error}")
        
        print(f"\nModels directory: {self.pretrained_dir}")
        print(f"Available models:")
        for f in sorted(self.pretrained_dir.glob("*.pt")):
            size_mb = f.stat().st_size / (1024 * 1024)
            print(f"  • {f.name} ({size_mb:.1f} MB)")
        
        print(f"\n{'─' * 80}")
        
        if not self.download_log['errors']:
            print(f"✓ ALL MODELS DOWNLOADED SUCCESSFULLY")
        else:
            print(f"⚠ SOME MODELS FAILED - SEE FALLBACK INSTRUCTIONS ABOVE")
        
        print(f"{'─' * 80}")


def main():
    """Main function"""
    downloader = PretrainedModelDownloader()
    success = downloader.download_all_models()
    
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
