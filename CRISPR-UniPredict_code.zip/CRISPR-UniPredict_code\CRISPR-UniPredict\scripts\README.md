# Scripts Directory

## Overview

This directory contains utility scripts for the CRISPR-UniPredict project.

---

## Available Scripts

### 1. `inspect_data.py`

**Purpose**: Comprehensive data inspection and analysis tool

**Features**:
- Scans `data/raw/crispr_hnn/` and `data/raw/cclmoff/` directories
- Analyzes all CSV/TSV files
- Auto-detects file separators
- Identifies sequence and target columns
- Generates detailed inspection report
- Handles large files efficiently

**Usage**:
```bash
python inspect_data.py
```

**Output**:
- Console: Real-time inspection progress
- File: `data/data_inspection_report.txt`

**Report Contents**:
- Summary statistics (total files, samples, columns)
- Identified column patterns
- Detailed file inspection (shape, columns, first 3 rows)
- Dataset summary table
- Column pattern analysis
- Error reporting

**Example Output**:
```
CRISPR-UniPredict DATA INSPECTION TOOL
================================================================================

SCANNING DATA DIRECTORIES
================================================================================

Scanning: data/raw/crispr_hnn
Found 10 file(s)

  Processing: ESP（n=58616）.csv
    ✓ Shape: 58616 × 2
    ✓ Size: 2.06 MB
    ✓ Separator: ','
    ✓ Sequence columns: ['sgRNA']
    ✓ Target columns: ['indel']

...

INSPECTION SUMMARY
================================================================================

Total Files: 11
Total Samples: 6,685,015
Sequence Columns: 4
Target Columns: 2

✓ Report saved to: data/data_inspection_report.txt
```

**Key Capabilities**:
- ✓ Automatic separator detection (comma, tab, semicolon, pipe)
- ✓ Robust error handling
- ✓ Large file support (tested with 681 MB)
- ✓ Mixed data type handling
- ✓ UTF-8 encoding support
- ✓ Column type identification

**Column Type Detection**:
- **Sequence columns**: Contain 'seq', 'rna', 'guide', 'grna', 'sgrna', 'target', 'dna'
- **Target columns**: Contain 'indel', 'efficiency', 'activity', 'label', 'off_target', 'offtarget', 'score', 'pred'

---

## Data Inspection Results

### Quick Summary

| Metric | Value |
|--------|-------|
| Total Files | 11 |
| Total Samples | 6,685,015 |
| CRISPR_HNN Files | 10 |
| CCLMoff Files | 1 |
| Total Data Size | 691.83 MB |

### CRISPR_HNN Datasets

- **10 files** with on-target activity data
- **331,642 total sequences**
- **10.25 MB total size**
- Format: sgRNA (sequence) + indel (target)
- All files: 2 columns, CSV format

### CCLMoff Dataset

- **1 file** with off-target prediction data
- **6,393,373 total pairs**
- **681.58 MB size**
- Format: sgRNA_seq, off_seq, label + 8 other columns
- 11 columns total, CSV format

---

## Column Patterns Identified

### Sequence Columns
- `sgRNA` (CRISPR_HNN)
- `sgRNA_seq` (CCLMoff)
- `off_seq` (CCLMoff)
- `sgRNA_type` (CCLMoff)

### Target Columns
- `indel` (CRISPR_HNN)
- `label` (CCLMoff)

---

## Report File

**Location**: `data/data_inspection_report.txt`

**Contents**:
1. Header with generation timestamp
2. Summary section
3. Identified columns
4. Detailed file inspection (for each file):
   - File path and size
   - Separator used
   - Shape (rows × columns)
   - Column list with data types
   - Sequence and target columns
   - First 3 rows
   - Data type summary
   - Missing values (if any)
5. Dataset summary table
6. Column pattern analysis
7. Error section (if any)

---

## Usage Examples

### Basic Usage
```bash
# Run from project root
python scripts/inspect_data.py

# Or run from scripts directory
cd scripts
python inspect_data.py
```

### View Report
```bash
# View full report
cat data/data_inspection_report.txt

# View first 50 lines
head -50 data/data_inspection_report.txt

# Search for specific dataset
grep -A 20 "ESP（n=58616）" data/data_inspection_report.txt
```

### Programmatic Usage
```python
from scripts.inspect_data import DataInspector

# Create inspector
inspector = DataInspector()

# Scan directories
inspector.scan_directory()

# Generate report
report = inspector.generate_report("my_report.txt")

# Access results
print(f"Total files: {inspector.summary['total_files']}")
print(f"Total samples: {inspector.summary['total_samples']}")
print(f"Sequence columns: {inspector.summary['sequence_columns']}")
print(f"Target columns: {inspector.summary['target_columns']}")
```

---

## Next Steps

After inspection, proceed with:

### 1. Data Preprocessing
```bash
python -c "from utils.preprocessing import preprocess_crispr_hnn, preprocess_cclmoff; \
  preprocess_crispr_hnn('data/raw/crispr_hnn/', 'data/processed/on_target/'); \
  preprocess_cclmoff('data/raw/cclmoff/', 'data/processed/off_target/')"
```

### 2. Model Training
```bash
python scripts/train_on_target.py
python scripts/train_off_target.py
```

### 3. Model Evaluation
```bash
python scripts/evaluate_models.py
```

---

## Troubleshooting

### Issue: "No data files found"
**Solution**: Ensure datasets are in `data/raw/crispr_hnn/` and `data/raw/cclmoff/`

### Issue: "DtypeWarning: Columns have mixed types"
**Solution**: Normal for large files with mixed data types. Script handles automatically.

### Issue: "File not found"
**Solution**: Run script from project root directory

### Issue: "Permission denied"
**Solution**: Ensure read permissions on data files

---

## Performance

- **Execution time**: ~30-60 seconds (depends on system)
- **Memory usage**: Minimal (processes files sequentially)
- **Large file support**: Tested with 681 MB CCLMoff dataset
- **Scalability**: Can handle datasets up to several GB

---

## Technical Details

### Dependencies
- pandas
- numpy
- pathlib
- collections

### Supported Formats
- CSV (comma-separated)
- TSV (tab-separated)
- Custom delimiters (auto-detected)

### Data Type Detection
- Automatic separator detection
- UTF-8 encoding support
- Mixed type handling
- Large file support

### Error Handling
- Graceful error handling
- Continues on file errors
- Reports all errors in summary
- Detailed error messages

---

## Future Enhancements

Potential additions:
- [ ] Statistical analysis (mean, std, distribution)
- [ ] Data quality scoring
- [ ] Visualization of column patterns
- [ ] Automated data validation
- [ ] Duplicate detection
- [ ] Outlier identification
- [ ] Data profiling report

---

## Related Files

- `../utils/preprocessing/` - Data preprocessing utilities
- `../data/raw/` - Raw data directory
- `../data/data_inspection_report.txt` - Generated report
- `../DATA_INSPECTION_SUMMARY.md` - Inspection summary

---

## Support

For questions or issues:
1. Check the generated report: `data/data_inspection_report.txt`
2. Review this README
3. Check project documentation: `README.md`, `SETUP_GUIDE.md`
4. Review script docstrings: `inspect_data.py`

---

*Last Updated: 2024*
*Status: ✓ Ready for Use*
