# Off-Target Probability Calibration

**Date:** 2026-06-26
**Model:** `models/checkpoints/off_target_dedicated/best_model.pt` (epoch 7)
**Protocol:** calibrators fit on `val.csv`, evaluated on `test.csv` (no leakage).
**Test set:** 311,044 (sgRNA, target) pairs, 3,319 positives (**1.07%** — extreme imbalance).

---

## 1. Why this matters

The off-target classifier is trained with **focal loss** (`alpha=0.85, gamma=2.0`) and
**balanced oversampling** (`pos_oversample_ratio=0.5`) to cope with the ~93:1 class
imbalance. Both are excellent for *ranking* but they train the model under an
artificial ~50% positive prior, while the real prior is ~1%. The result: the raw
sigmoid output is a good *score* but **not a trustworthy probability**. For a
safety-critical screen that is a real defect — you cannot act on "flag if
P(off-target) > 0.3" if 0.3 does not mean a 30% chance.

This report recovers calibrated risk estimates **post hoc**, with **no retraining**
and **no change to ranking performance**.

## 2. Method

Three standard, **monotonic** calibrators are fit on the held-out validation split
and applied to the test split:

| Method | Form | Params |
|---|---|---|
| Temperature scaling | `sigmoid(logit / T)` | T = 0.994 |
| Platt scaling | `sigmoid(a·logit + b)` | a = 1.224, b = −3.241 |
| Isotonic regression | non-parametric monotone map | — |

Because all three are monotonic, **AUROC and the ranking are provably preserved** —
calibration only rescales the probability axis.

Calibration error is reported with **quantile binning** (essential under 1% prevalence;
uniform bins put ~everything in the lowest bin) alongside uniform binning, plus the
proper scoring rules **Brier** and **NLL**.

## 3. Results (test split, n = 311,044)

| Method | ECE (quantile) | ECE (uniform) | MCE (uniform) | Brier | NLL | AUROC | AUPRC |
|---|---|---|---|---|---|---|---|
| Raw (focal sigmoid) | 0.02251 | 0.02251 | 0.722 | 0.013625 | 0.04372 | 0.99309 | 0.83197 |
| Temperature (T=0.994) | 0.02242 | 0.02242 | 0.722 | 0.013639 | 0.04372 | 0.99309 | 0.83197 |
| **Platt (recommended)** | 0.00036 | 0.00256 | 0.220 | 0.003998 | 0.01563 | 0.99309 | 0.83197 |
| Isotonic (ECE-optimal) | 0.00008 | 0.00058 | 0.091 | 0.003761 | 0.01445 | 0.99306 | 0.82300 |

**Headline:** Expected Calibration Error drops **~98%** (0.0225 → 0.0004, Platt),
Brier **−71%**, NLL **−64%**, while AUROC and AUPRC are unchanged.

### Key finding — it's a bias, not over-confidence

Temperature scaling (the usual first try for neural-net calibration) **does essentially
nothing** here (T ≈ 1.0, ECE unchanged). What fixes it is **Platt's intercept,
b = −3.24** — a large negative log-odds shift. This is the signature of training under
a re-balanced prior: the balanced sampler + focal `alpha=0.85` teach the model a
~50% positive prior, so on the true ~1% population it systematically over-states
off-target probability. A single prior/bias correction restores calibration. This is
a clean, defensible explanation rather than a black-box fix.

## 4. Operating points (the practical payoff)

Thresholds chosen on validation for a target false-positive rate, evaluated on test,
in **calibrated-probability space** (so the threshold is an interpretable risk level):

| Target FPR | Threshold P(off) | Test FPR | Recall (TPR) | Precision | # flagged |
|---|---|---|---|---|---|
| 0.001 | 0.545 | 0.0012 | 0.649 | 0.857 | 2,513 |
| 0.005 | 0.191 | 0.0045 | 0.804 | 0.659 | 4,046 |
| 0.010 | 0.087 | 0.0103 | 0.879 | 0.479 | 6,096 |
| 0.050 | 0.006 | 0.0577 | 0.977 | 0.154 | 21,005 |
| 0.100 | 0.002 | 0.0867 | 0.986 | 0.109 | 29,939 |

A practitioner can now pick a regime — e.g. **high-precision** (threshold 0.55 →
86% precision at 65% recall) for confirmatory work, or **high-recall screening**
(threshold 0.006 → 98% recall) to triage candidate guides.

## 5. Recommendation

Ship the **Platt** calibrator alongside the model (`a=1.224, b=−3.241` on the logit):
it reaches near-perfect ECE (0.0004), is a stable 2-parameter map that cannot overfit,
and **preserves AUPRC exactly**. Isotonic gives marginally lower ECE but is a
non-parametric step function and slightly reduces AUPRC (0.832 → 0.823).

## 6. Honest caveats

1. **AUROC discrepancy vs the docs.** This checkpoint scores **AUROC 0.9931 / AUPRC
   0.8320** on the full test set — far above the **0.8753** quoted throughout the
   project docs (and the `off_target_dedicated.py` docstring's 0.7288 for the *multitask*
   model). The dedicated **paired** model is genuinely much stronger than the
   multitask one, but 0.99 is partly because the input includes an explicit
   per-position **mismatch channel** + handcrafted mismatch-count features, which make
   the label comparatively easy to separate. **Before publishing**, reconcile which
   model/number is the official headline, and consider reporting the harder
   **sequence-split** test (`test_seqsplit.csv`) to rule out near-duplicate leakage.
2. **Calibration is prior-specific.** It is fit to this dataset's ~1% base rate. If
   deployed on a population with a different off-target prevalence, re-fit the
   calibrator (or apply an explicit prior correction).
3. Isotonic's tiny AUROC change (0.99309 → 0.99306) is binning/tie noise, not a real
   ranking change.

## 7. Reproduce

```bash
python calibrate_off_target.py            # full run (cached to reports/off_target_calibration/preds_*_full.npz)
python calibrate_off_target.py --max-rows 8000   # quick smoke test
```

Artifacts in `reports/off_target_calibration/`:
- `calibration_results.json` — all metrics, fitted params, operating points
- `reliability_diagram.png` — reliability curves (raw vs calibrated) + probability histogram
- `preds_{val,test}_full.npz` — cached logits + labels (so re-analysis needs no re-inference)
