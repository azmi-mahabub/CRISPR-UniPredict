"""
Comprehensive Data Preprocessing Script for CRISPR-UniPredict
Processes raw datasets into unified format with train/val/test splits
"""

import os
import sys
from pathlib import Path
import pandas as pd
import numpy as np
from datetime import datetime
import logging
from sklearn.model_selection import train_test_split
from collections import defaultdict

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class DataPreprocessor:
    """Preprocess and unify CRISPR datasets"""
    
    def __init__(self):
        """Initialize preprocessor"""
        self.project_root = Path(__file__).parent.parent
        self.raw_dir = self.project_root / "data" / "raw"
        self.processed_dir = self.project_root / "data" / "processed"
        self.combined_dir = self.processed_dir / "combined"
        self.on_target_dir = self.processed_dir / "on_target"
        self.off_target_dir = self.processed_dir / "off_target"
        
        # Create directories
        self.combined_dir.mkdir(parents=True, exist_ok=True)
        self.on_target_dir.mkdir(parents=True, exist_ok=True)
        self.off_target_dir.mkdir(parents=True, exist_ok=True)
        
        self.all_data = []
        self.stats = {
            'total_samples': 0,
            'on_target_samples': 0,
            'off_target_samples': 0,
            'datasets_processed': 0,
            'errors': []
        }
    
    def process_crispr_hnn_datasets(self):
        """Process CRISPR-HNN on-target datasets"""
        logger.info("\n" + "="*80)
        logger.info("PROCESSING CRISPR-HNN ON-TARGET DATASETS")
        logger.info("="*80)
        
        hnn_dir = self.raw_dir / "crispr_hnn"
        if not hnn_dir.exists():
            logger.error(f"CRISPR-HNN directory not found: {hnn_dir}")
            return
        
        csv_files = list(hnn_dir.glob("*.csv"))
        logger.info(f"Found {len(csv_files)} CRISPR-HNN files")
        
        for csv_file in sorted(csv_files):
            try:
                logger.info(f"\nProcessing: {csv_file.name}")
                
                # Read CSV
                df = pd.read_csv(csv_file)
                logger.info(f"  Shape: {df.shape}")
                
                # Standardize columns
                if 'sgRNA' in df.columns and 'indel' in df.columns:
                    df_processed = pd.DataFrame({
                        'sgrna': df['sgRNA'].str.upper(),
                        'on_target_score': df['indel'].astype(float),
                        'dataset': csv_file.stem,
                        'task': 'on_target'
                    })
                    
                    # Add off_target_score as NaN for on-target only data
                    df_processed['off_target_score'] = np.nan
                    
                    self.all_data.append(df_processed)
                    self.stats['on_target_samples'] += len(df_processed)
                    self.stats['datasets_processed'] += 1
                    logger.info(f"  ✓ Processed {len(df_processed)} samples")
                else:
                    logger.warning(f"  ✗ Missing expected columns: {df.columns.tolist()}")
                    self.stats['errors'].append(f"{csv_file.name}: Missing columns")
            
            except Exception as e:
                logger.error(f"  ✗ Error processing {csv_file.name}: {e}")
                self.stats['errors'].append(f"{csv_file.name}: {str(e)}")
    
    def process_cclmoff_dataset(self):
        """Process CCLMoff off-target dataset"""
        logger.info("\n" + "="*80)
        logger.info("PROCESSING CCLMOFF OFF-TARGET DATASET")
        logger.info("="*80)
        
        cclmoff_dir = self.raw_dir / "cclmoff"
        if not cclmoff_dir.exists():
            logger.error(f"CCLMoff directory not found: {cclmoff_dir}")
            return
        
        csv_files = list(cclmoff_dir.glob("*.csv"))
        logger.info(f"Found {len(csv_files)} CCLMoff files")
        
        for csv_file in sorted(csv_files):
            try:
                logger.info(f"\nProcessing: {csv_file.name}")
                
                # Read CSV with low_memory=False to avoid dtype warnings
                df = pd.read_csv(csv_file, low_memory=False)
                logger.info(f"  Shape: {df.shape}")
                
                # Check for expected columns
                if 'sgRNA_seq' in df.columns and 'label' in df.columns:
                    # Sample if too large (to keep processing reasonable)
                    if len(df) > 100000:
                        logger.info(f"  Sampling 100,000 from {len(df)} samples")
                        df = df.sample(n=100000, random_state=42)
                    
                    df_processed = pd.DataFrame({
                        'sgrna': df['sgRNA_seq'].str.upper(),
                        'off_target_score': df['label'].astype(float),
                        'dataset': csv_file.stem,
                        'task': 'off_target'
                    })
                    
                    # Add on_target_score as NaN for off-target only data
                    df_processed['on_target_score'] = np.nan
                    
                    self.all_data.append(df_processed)
                    self.stats['off_target_samples'] += len(df_processed)
                    self.stats['datasets_processed'] += 1
                    logger.info(f"  ✓ Processed {len(df_processed)} samples")
                else:
                    logger.warning(f"  ✗ Missing expected columns: {df.columns.tolist()}")
                    self.stats['errors'].append(f"{csv_file.name}: Missing columns")
            
            except Exception as e:
                logger.error(f"  ✗ Error processing {csv_file.name}: {e}")
                self.stats['errors'].append(f"{csv_file.name}: {str(e)}")
    
    def create_unified_dataset(self):
        """Create unified dataset from all processed data"""
        logger.info("\n" + "="*80)
        logger.info("CREATING UNIFIED DATASET")
        logger.info("="*80)
        
        if not self.all_data:
            logger.error("No data to process!")
            return None
        
        # Combine all data
        unified_df = pd.concat(self.all_data, ignore_index=True)
        logger.info(f"Combined shape: {unified_df.shape}")
        
        # Validate sequences
        logger.info("Validating sequences...")
        valid_nucleotides = set('ACGT')
        
        def is_valid_sequence(seq):
            if pd.isna(seq):
                return False
            return all(n in valid_nucleotides for n in str(seq).upper())
        
        valid_mask = unified_df['sgrna'].apply(is_valid_sequence)
        logger.info(f"Valid sequences: {valid_mask.sum()} / {len(unified_df)}")
        
        # Remove invalid sequences
        if valid_mask.sum() < len(unified_df):
            logger.warning(f"Removing {(~valid_mask).sum()} invalid sequences")
            unified_df = unified_df[valid_mask].reset_index(drop=True)
        
        # Remove duplicates
        logger.info(f"Removing duplicates...")
        before_dedup = len(unified_df)
        unified_df = unified_df.drop_duplicates(subset=['sgrna', 'dataset']).reset_index(drop=True)
        logger.info(f"Removed {before_dedup - len(unified_df)} duplicates")
        
        self.stats['total_samples'] = len(unified_df)
        
        # Save unified dataset
        unified_path = self.combined_dir / "unified_dataset.csv"
        unified_df.to_csv(unified_path, index=False)
        logger.info(f"✓ Saved unified dataset: {unified_path}")
        
        return unified_df
    
    def create_train_val_test_splits(self, unified_df, train_ratio=0.7, val_ratio=0.15, test_ratio=0.15):
        """Create train/val/test splits"""
        logger.info("\n" + "="*80)
        logger.info("CREATING TRAIN/VAL/TEST SPLITS")
        logger.info("="*80)
        
        # First split: train + temp (val + test)
        train_df, temp_df = train_test_split(
            unified_df,
            test_size=(val_ratio + test_ratio),
            random_state=42
        )
        
        # Second split: val and test
        val_df, test_df = train_test_split(
            temp_df,
            test_size=test_ratio / (val_ratio + test_ratio),
            random_state=42
        )
        
        logger.info(f"Train set: {len(train_df)} samples ({len(train_df)/len(unified_df)*100:.1f}%)")
        logger.info(f"Val set: {len(val_df)} samples ({len(val_df)/len(unified_df)*100:.1f}%)")
        logger.info(f"Test set: {len(test_df)} samples ({len(test_df)/len(unified_df)*100:.1f}%)")
        
        # Save splits
        train_path = self.combined_dir / "train.csv"
        val_path = self.combined_dir / "val.csv"
        test_path = self.combined_dir / "test.csv"
        
        train_df.to_csv(train_path, index=False)
        val_df.to_csv(val_path, index=False)
        test_df.to_csv(test_path, index=False)
        
        logger.info(f"✓ Saved train set: {train_path}")
        logger.info(f"✓ Saved val set: {val_path}")
        logger.info(f"✓ Saved test set: {test_path}")
        
        return train_df, val_df, test_df
    
    def print_statistics(self, unified_df, train_df, val_df, test_df):
        """Print comprehensive statistics"""
        logger.info("\n" + "="*80)
        logger.info("PREPROCESSING STATISTICS")
        logger.info("="*80)
        
        logger.info("\nDataset Overview:")
        logger.info(f"  Total samples: {len(unified_df):,}")
        logger.info(f"  On-target samples: {self.stats['on_target_samples']:,}")
        logger.info(f"  Off-target samples: {self.stats['off_target_samples']:,}")
        logger.info(f"  Datasets processed: {self.stats['datasets_processed']}")
        
        logger.info("\nTrain/Val/Test Split:")
        logger.info(f"  Train: {len(train_df):,} ({len(train_df)/len(unified_df)*100:.1f}%)")
        logger.info(f"  Val: {len(val_df):,} ({len(val_df)/len(unified_df)*100:.1f}%)")
        logger.info(f"  Test: {len(test_df):,} ({len(test_df)/len(unified_df)*100:.1f}%)")
        
        # Task distribution
        logger.info("\nTask Distribution (Overall):")
        task_counts = unified_df['task'].value_counts()
        for task, count in task_counts.items():
            logger.info(f"  {task}: {count:,} ({count/len(unified_df)*100:.1f}%)")
        
        logger.info("\nTask Distribution (Train):")
        task_counts_train = train_df['task'].value_counts()
        for task, count in task_counts_train.items():
            logger.info(f"  {task}: {count:,} ({count/len(train_df)*100:.1f}%)")
        
        # Dataset distribution
        logger.info("\nDataset Distribution (Top 10):")
        dataset_counts = unified_df['dataset'].value_counts().head(10)
        for dataset, count in dataset_counts.items():
            logger.info(f"  {dataset}: {count:,} ({count/len(unified_df)*100:.1f}%)")
        
        # Score statistics
        logger.info("\nOn-Target Score Statistics:")
        on_target_scores = unified_df['on_target_score'].dropna()
        if len(on_target_scores) > 0:
            logger.info(f"  Count: {len(on_target_scores):,}")
            logger.info(f"  Mean: {on_target_scores.mean():.4f}")
            logger.info(f"  Std: {on_target_scores.std():.4f}")
            logger.info(f"  Min: {on_target_scores.min():.4f}")
            logger.info(f"  Max: {on_target_scores.max():.4f}")
        
        logger.info("\nOff-Target Score Statistics:")
        off_target_scores = unified_df['off_target_score'].dropna()
        if len(off_target_scores) > 0:
            logger.info(f"  Count: {len(off_target_scores):,}")
            logger.info(f"  Mean: {off_target_scores.mean():.4f}")
            logger.info(f"  Std: {off_target_scores.std():.4f}")
            logger.info(f"  Min: {off_target_scores.min():.4f}")
            logger.info(f"  Max: {off_target_scores.max():.4f}")
        
        # Sequence length statistics
        logger.info("\nSequence Length Statistics:")
        seq_lengths = unified_df['sgrna'].str.len()
        logger.info(f"  Mean length: {seq_lengths.mean():.1f}")
        logger.info(f"  Min length: {seq_lengths.min()}")
        logger.info(f"  Max length: {seq_lengths.max()}")
        logger.info(f"  Unique lengths: {seq_lengths.nunique()}")
        
        if self.stats['errors']:
            logger.warning(f"\nWarnings/Errors ({len(self.stats['errors'])}):")
            for error in self.stats['errors'][:5]:
                logger.warning(f"  • {error}")
            if len(self.stats['errors']) > 5:
                logger.warning(f"  ... and {len(self.stats['errors']) - 5} more")
        
        logger.info("\n" + "="*80)
        logger.info("✓ PREPROCESSING COMPLETE")
        logger.info("="*80)
    
    def verify_output_files(self):
        """Verify that all output files were created"""
        logger.info("\n" + "="*80)
        logger.info("VERIFYING OUTPUT FILES")
        logger.info("="*80)
        
        required_files = [
            self.combined_dir / "unified_dataset.csv",
            self.combined_dir / "train.csv",
            self.combined_dir / "val.csv",
            self.combined_dir / "test.csv"
        ]
        
        all_exist = True
        for file_path in required_files:
            if file_path.exists():
                size_mb = file_path.stat().st_size / (1024 * 1024)
                logger.info(f"✓ {file_path.name} ({size_mb:.2f} MB)")
            else:
                logger.error(f"✗ {file_path.name} NOT FOUND")
                all_exist = False
        
        if all_exist:
            logger.info("\n✓ All output files verified!")
        else:
            logger.error("\n✗ Some output files are missing!")
        
        return all_exist
    
    def run(self):
        """Run complete preprocessing pipeline"""
        logger.info("\n" + "="*80)
        logger.info("CRISPR-UniPredict DATA PREPROCESSING PIPELINE")
        logger.info("="*80)
        logger.info(f"Start time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        
        try:
            # Process datasets
            self.process_crispr_hnn_datasets()
            self.process_cclmoff_dataset()
            
            # Create unified dataset
            unified_df = self.create_unified_dataset()
            if unified_df is None:
                logger.error("Failed to create unified dataset")
                return False
            
            # Create splits
            train_df, val_df, test_df = self.create_train_val_test_splits(unified_df)
            
            # Print statistics
            self.print_statistics(unified_df, train_df, val_df, test_df)
            
            # Verify output files
            success = self.verify_output_files()
            
            logger.info(f"\nEnd time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
            
            return success
        
        except Exception as e:
            logger.error(f"Pipeline failed: {e}", exc_info=True)
            return False


if __name__ == "__main__":
    preprocessor = DataPreprocessor()
    success = preprocessor.run()
    sys.exit(0 if success else 1)
