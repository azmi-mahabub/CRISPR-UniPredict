"""
Cross-Dataset Validation Script for CRISPR-UniPredict
Evaluates model generalization across different datasets
"""

import argparse
import sys
import logging
import json
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Tuple
import numpy as np
import pandas as pd
import torch
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from models.crispr_unipredict import CRISPRUniPredict
from models.encoding import SequenceEncoder
from utils.preprocessing.dataset import CRISPRDataset
from utils.evaluation.metrics import MetricsCalculator
from training.trainer import Trainer
from training.optimization import create_optimizer_and_scheduler
from utils.preprocessing.dataloader_factory import DataLoaderFactory
from configs.config_loader import ConfigLoader
from torch.utils.data import DataLoader


logger = logging.getLogger(__name__)


class CrossDatasetValidator:
    """
    Cross-dataset validation for CRISPR-UniPredict
    
    Evaluates model generalization across different datasets
    """
    
    def __init__(self, config, output_dir: Path):
        """
        Initialize validator
        
        Args:
            config: Configuration object
            output_dir: Output directory
        """
        self.config = config
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        self.device = 'cuda' if config.device.use_cuda else 'cpu'
        self.metrics_calculator = MetricsCalculator()
        
        # Results storage
        self.results = {}
        self.metrics_matrix = {}
    
    def define_dataset_combinations(self) -> Dict[str, Dict]:
        """
        Define dataset combinations for cross-validation
        
        Returns:
            Dictionary with dataset combinations
        """
        combinations = {
            'circle_seq_to_others': {
                'train': 'data/datasets/CIRCLE-seq/train.csv',
                'test': {
                    'GUIDE-seq': 'data/datasets/GUIDE-seq/test.csv',
                    'DISCOVER-seq': 'data/datasets/DISCOVER-seq/test.csv',
                    'DIG-seq': 'data/datasets/DIG-seq/test.csv'
                }
            },
            'combined_to_small': {
                'train': 'data/processed/combined/train.csv',
                'test': {
                    'CIRCLE-seq': 'data/datasets/CIRCLE-seq/test.csv',
                    'GUIDE-seq': 'data/datasets/GUIDE-seq/test.csv',
                    'DIG-seq': 'data/datasets/DIG-seq/test.csv'
                }
            },
            'on_target_to_on_target': {
                'train': 'data/processed/on_target/train.csv',
                'test': {
                    'on_target_val': 'data/processed/on_target/val.csv',
                    'on_target_test': 'data/processed/on_target/test.csv'
                }
            },
            'off_target_to_off_target': {
                'train': 'data/processed/off_target/train.csv',
                'test': {
                    'off_target_val': 'data/processed/off_target/val.csv',
                    'off_target_test': 'data/processed/off_target/test.csv'
                }
            }
        }
        
        return combinations
    
    def load_dataset(self, csv_path: str, split: str = 'test') -> CRISPRDataset:
        """
        Load dataset from CSV
        
        Args:
            csv_path: Path to CSV file
            split: Dataset split name
        
        Returns:
            CRISPRDataset instance
        """
        csv_path = Path(csv_path)
        
        if not csv_path.exists():
            logger.warning(f"Dataset not found: {csv_path}")
            return None
        
        encoder = SequenceEncoder(device=self.device)
        
        dataset = CRISPRDataset(
            csv_path=str(csv_path),
            encoder=encoder,
            cache_dir=Path('.cache') / split,
            use_cache=True,
            augmentation=False,
            verbose=False
        )
        
        return dataset
    
    def evaluate_on_dataset(self,
                           model: CRISPRUniPredict,
                           dataset: CRISPRDataset,
                           batch_size: int = 64) -> Dict:
        """
        Evaluate model on dataset
        
        Args:
            model: Trained model
            dataset: Test dataset
            batch_size: Batch size
        
        Returns:
            Dictionary with metrics
        """
        if dataset is None:
            return None
        
        # Create dataloader
        dataloader = DataLoader(
            dataset,
            batch_size=batch_size,
            shuffle=False,
            num_workers=4,
            pin_memory=True
        )
        
        # Collect predictions
        all_on_target_pred = []
        all_on_target_target = []
        all_off_target_pred = []
        all_off_target_target = []
        all_on_target_mask = []
        all_off_target_mask = []
        
        model.eval()
        with torch.no_grad():
            for batch in dataloader:
                sgrna_onehot = batch['sgrna_onehot'].to(self.device)
                sgrna_label = batch['sgrna_label'].to(self.device)
                on_target_score = batch['on_target_score'].to(self.device)
                off_target_label = batch['off_target_label'].to(self.device)
                on_target_mask = batch['on_target_mask'].to(self.device)
                off_target_mask = batch['off_target_mask'].to(self.device)
                
                # Forward pass
                on_target_pred, off_target_pred = model(
                    sgrna_onehot, sgrna_label, task_type='both'
                )
                
                # Collect
                all_on_target_pred.append(on_target_pred.cpu())
                all_on_target_target.append(on_target_score.cpu())
                all_off_target_pred.append(off_target_pred.cpu())
                all_off_target_target.append(off_target_label.cpu())
                all_on_target_mask.append(on_target_mask.cpu())
                all_off_target_mask.append(off_target_mask.cpu())
        
        # Concatenate
        on_target_pred = torch.cat(all_on_target_pred).numpy().squeeze()
        on_target_target = torch.cat(all_on_target_target).numpy().squeeze()
        off_target_pred = torch.cat(all_off_target_pred).numpy().squeeze()
        off_target_target = torch.cat(all_off_target_target).numpy().squeeze()
        on_target_mask = torch.cat(all_on_target_mask).numpy()
        off_target_mask = torch.cat(all_off_target_mask).numpy()
        
        # Compute metrics
        metrics = self.metrics_calculator.compute_all_metrics(
            on_target_pred=on_target_pred,
            off_target_pred=off_target_pred,
            on_target_target=on_target_target,
            off_target_target=off_target_target,
            on_target_mask=on_target_mask,
            off_target_mask=off_target_mask
        )
        
        return metrics
    
    def run_cross_validation(self, num_epochs: int = 10) -> None:
        """
        Run cross-dataset validation
        
        Args:
            num_epochs: Number of epochs to train
        """
        combinations = self.define_dataset_combinations()
        
        for combo_name, combo_config in combinations.items():
            logger.info(f"\n{'='*80}")
            logger.info(f"Running: {combo_name}")
            logger.info(f"{'='*80}")
            
            # Load training dataset
            train_path = combo_config['train']
            logger.info(f"Loading training data from {train_path}")
            train_dataset = self.load_dataset(train_path, 'train')
            
            if train_dataset is None:
                logger.warning(f"Skipping {combo_name}: training data not found")
                continue
            
            # Initialize model
            model = CRISPRUniPredict(device=self.device)
            optimizer, scheduler = create_optimizer_and_scheduler(model, self.config)
            
            # Quick training (simplified for cross-validation)
            logger.info(f"Training model for {num_epochs} epochs...")
            self._train_model(model, train_dataset, optimizer, scheduler, num_epochs)
            
            # Evaluate on all test datasets
            combo_results = {}
            for test_name, test_path in combo_config['test'].items():
                logger.info(f"Evaluating on {test_name}...")
                test_dataset = self.load_dataset(test_path, test_name)
                
                if test_dataset is None:
                    logger.warning(f"Test dataset not found: {test_name}")
                    continue
                
                metrics = self.evaluate_on_dataset(model, test_dataset)
                combo_results[test_name] = metrics
            
            self.results[combo_name] = combo_results
    
    def _train_model(self,
                    model: CRISPRUniPredict,
                    dataset: CRISPRDataset,
                    optimizer,
                    scheduler,
                    num_epochs: int) -> None:
        """
        Train model (simplified)
        
        Args:
            model: Model to train
            dataset: Training dataset
            optimizer: Optimizer
            scheduler: Scheduler
            num_epochs: Number of epochs
        """
        from utils.losses import MultiTaskLoss
        
        criterion = MultiTaskLoss(
            on_target_weight=self.config.training.loss.loss_weights['on_target'],
            off_target_weight=self.config.training.loss.loss_weights['off_target']
        ).to(self.device)
        
        dataloader = DataLoader(
            dataset,
            batch_size=self.config.training.batch_size,
            shuffle=True,
            num_workers=4
        )
        
        model.train()
        for epoch in range(num_epochs):
            total_loss = 0.0
            
            for batch in dataloader:
                sgrna_onehot = batch['sgrna_onehot'].to(self.device)
                sgrna_label = batch['sgrna_label'].to(self.device)
                on_target_score = batch['on_target_score'].to(self.device)
                off_target_label = batch['off_target_label'].to(self.device)
                on_target_mask = batch['on_target_mask'].to(self.device)
                off_target_mask = batch['off_target_mask'].to(self.device)
                
                # Forward pass
                on_target_pred, off_target_pred = model(
                    sgrna_onehot, sgrna_label, task_type='both'
                )
                
                # Compute loss
                loss, _ = criterion(
                    on_target_pred=on_target_pred,
                    off_target_pred=off_target_pred,
                    on_target_target=on_target_score,
                    off_target_target=off_target_label,
                    on_target_mask=on_target_mask,
                    off_target_mask=off_target_mask
                )
                
                # Backward pass
                optimizer.zero_grad()
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                optimizer.step()
                
                total_loss += loss.item()
            
            avg_loss = total_loss / len(dataloader)
            logger.info(f"Epoch {epoch+1}/{num_epochs} - Loss: {avg_loss:.6f}")
    
    def create_metrics_matrix(self) -> pd.DataFrame:
        """
        Create metrics comparison matrix
        
        Returns:
            DataFrame with metrics
        """
        # Extract key metrics
        matrix_data = {}
        
        for combo_name, combo_results in self.results.items():
            for test_name, metrics in combo_results.items():
                if metrics is None:
                    continue
                
                key = f"{combo_name} → {test_name}"
                
                # Extract key metrics
                on_target_scc = metrics['on_target'].get('spearman_r', 0.0)
                off_target_auroc = metrics['off_target'].get('auroc', 0.0)
                
                matrix_data[key] = {
                    'On-Target SCC': on_target_scc,
                    'Off-Target AUROC': off_target_auroc
                }
        
        df = pd.DataFrame(matrix_data).T
        return df
    
    def plot_metrics_heatmap(self) -> None:
        """Plot metrics comparison heatmap"""
        try:
            df = self.create_metrics_matrix()
            
            fig, axes = plt.subplots(1, 2, figsize=(14, 6))
            
            # On-target SCC heatmap
            sns.heatmap(
                df[['On-Target SCC']],
                annot=True,
                fmt='.3f',
                cmap='RdYlGn',
                vmin=0,
                vmax=1,
                ax=axes[0],
                cbar_kws={'label': 'Spearman Correlation'}
            )
            axes[0].set_title('On-Target Performance (SCC)')
            axes[0].set_ylabel('Train → Test Dataset')
            
            # Off-target AUROC heatmap
            sns.heatmap(
                df[['Off-Target AUROC']],
                annot=True,
                fmt='.3f',
                cmap='RdYlGn',
                vmin=0,
                vmax=1,
                ax=axes[1],
                cbar_kws={'label': 'AUROC'}
            )
            axes[1].set_title('Off-Target Performance (AUROC)')
            axes[1].set_ylabel('Train → Test Dataset')
            
            plt.tight_layout()
            plt.savefig(self.output_dir / 'metrics_heatmap.png', dpi=150)
            plt.close()
            
            logger.info(f"Metrics heatmap saved to {self.output_dir / 'metrics_heatmap.png'}")
        
        except Exception as e:
            logger.warning(f"Failed to plot metrics heatmap: {e}")
    
    def save_results(self) -> None:
        """Save results to JSON and CSV"""
        # Convert to JSON-serializable format
        results_json = {}
        for combo_name, combo_results in self.results.items():
            results_json[combo_name] = {}
            for test_name, metrics in combo_results.items():
                if metrics is None:
                    continue
                
                results_json[combo_name][test_name] = {}
                for task, task_metrics in metrics.items():
                    results_json[combo_name][test_name][task] = {}
                    for key, value in task_metrics.items():
                        if isinstance(value, dict):
                            continue
                        elif isinstance(value, (np.integer, np.floating)):
                            results_json[combo_name][test_name][task][key] = float(value)
                        else:
                            results_json[combo_name][test_name][task][key] = value
        
        # Save JSON
        json_path = self.output_dir / 'cross_validation_results.json'
        with open(json_path, 'w') as f:
            json.dump(results_json, f, indent=2)
        
        logger.info(f"Results saved to {json_path}")
        
        # Save CSV
        df = self.create_metrics_matrix()
        csv_path = self.output_dir / 'metrics_matrix.csv'
        df.to_csv(csv_path)
        
        logger.info(f"Metrics matrix saved to {csv_path}")
    
    def print_summary(self) -> None:
        """Print summary statistics"""
        logger.info("\n" + "=" * 80)
        logger.info("CROSS-DATASET VALIDATION SUMMARY")
        logger.info("=" * 80)
        
        df = self.create_metrics_matrix()
        logger.info("\nMetrics Matrix:")
        logger.info(df.to_string())
        
        logger.info("\n" + "=" * 80)


def setup_logging(output_dir: Path) -> logging.Logger:
    """Setup logging"""
    output_dir.mkdir(parents=True, exist_ok=True)
    
    logger = logging.getLogger('CRISPR-CrossValidation')
    logger.setLevel(logging.DEBUG)
    
    # File handler
    log_file = output_dir / 'cross_validation.log'
    file_handler = logging.FileHandler(log_file)
    file_handler.setLevel(logging.DEBUG)
    
    # Console handler
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    
    # Formatter
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    file_handler.setFormatter(formatter)
    console_handler.setFormatter(formatter)
    
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)
    
    return logger


def parse_arguments():
    """Parse command-line arguments"""
    parser = argparse.ArgumentParser(
        description='Cross-dataset validation for CRISPR-UniPredict',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python scripts/cross_dataset_validation.py \\
    --config configs/model_config.yaml \\
    --output_dir results/cross_validation \\
    --epochs 10
        """
    )
    
    parser.add_argument(
        '--config',
        type=str,
        default='configs/model_config.yaml',
        help='Path to configuration file'
    )
    
    parser.add_argument(
        '--output_dir',
        type=str,
        default='results/cross_validation',
        help='Output directory for results'
    )
    
    parser.add_argument(
        '--epochs',
        type=int,
        default=10,
        help='Number of epochs to train'
    )
    
    parser.add_argument(
        '--batch_size',
        type=int,
        default=64,
        help='Batch size for training'
    )
    
    return parser.parse_args()


def main():
    """Main function"""
    
    # Parse arguments
    args = parse_arguments()
    
    # Setup output directory
    output_dir = Path(args.output_dir)
    
    # Setup logging
    global logger
    logger = setup_logging(output_dir)
    
    logger.info("=" * 80)
    logger.info("CRISPR-UniPredict Cross-Dataset Validation")
    logger.info("=" * 80)
    logger.info(f"Config: {args.config}")
    logger.info(f"Output directory: {output_dir}")
    logger.info(f"Epochs: {args.epochs}")
    
    try:
        # Load configuration
        config = ConfigLoader(args.config).config
        
        # Create validator
        validator = CrossDatasetValidator(config, output_dir)
        
        # Run cross-validation
        validator.run_cross_validation(num_epochs=args.epochs)
        
        # Generate visualizations
        validator.plot_metrics_heatmap()
        
        # Save results
        validator.save_results()
        
        # Print summary
        validator.print_summary()
        
        logger.info("Cross-validation completed successfully!")
        
        return 0
    
    except Exception as e:
        logger.error(f"Cross-validation failed: {e}", exc_info=True)
        return 1


if __name__ == '__main__':
    sys.exit(main())
