# CRISPR-UniPredict — Quick Troubleshooting Guide

**Last Updated:** 2026-04-19  
**Purpose:** Common issues and how to fix them

---

## Issue 1: "RNA-FM not available: ... Using placeholder"

### Symptoms
- Model loads but has only ~2M parameters instead of ~101M
- Training is very fast (< 0.1 s/batch)
- Warning in logs: `RNA-FM not available in Python path`

### Causes
1. `RNA-FM-main` folder not found or not in parent directory
2. `PYTHONPATH` not set correctly
3. Corrupted RNA-FM checkpoint

### Solutions

**Solution 1: Set PYTHONPATH manually (temporary)**
```powershell
$env:PYTHONPATH = "c:\shawon2\both paper models\RNA-FM-main"
python scripts/train.py --config configs/smoke_rna_fm.yaml
```

**Solution 2: Verify RNA-FM-main exists (permanent)**
```powershell
# Should show RNA-FM-main folder
ls "c:\shawon2\both paper models\"
```

**Solution 3: Fix corrupted hub cache (if PyTorch hub issue)**
```powershell
# Remove incomplete checkpoint
Remove-Item "$env:USERPROFILE\.cache\torch\hub\checkpoints\RNA-FM_pretrained.pth"

# Re-download on next run
python scripts/train.py --config configs/smoke_rna_fm.yaml
```

**Verification:** After fix, should see:
```
Model initialized
  Total parameters: 101,661,951
  Trainable parameters: 18,960,511
```

---

## Issue 2: "No valid on-target samples in batch" (continuous)

### Symptoms
- Every batch shows "No valid on-target samples in batch"
- On-target loss is always 0
- In **debug mode**, this is expected for some batches (~50%)

### Root Cause
In normal (non-debug) mode, **initial rows of CSV may all be off-target**. After target filling, they're preserved but not mixed in order.

### Solutions

**For --debug mode:**
- This is **normal and expected**. The stratified sampling ensures ~50% of debug batches have on-target labels.
- Check logs: should see both "No valid on-target..." and "on_target=X.XXX" messages.

**For normal mode:**
- **This indicates a data issue**, not a code issue. Off-target rows dominate the dataset naturally.
- To verify: check your CSV file's label distribution
  ```python
  import pandas as pd
  df = pd.read_csv('data/processed/combined/train.csv')
  print("On-target rows:", df['on_target_score'].notna().sum())
  print("Off-target rows:", df['off_target_label'].notna().sum())
  ```

---

## Issue 3: "TypeError: torch.load() got an unexpected keyword argument 'weights_only'"

### Symptoms
- Error on PyTorch 2.4 or older
- Message: `weights_only` is not recognized

### Cause
The fix added `weights_only=False` for PyTorch 2.6+, but older PyTorch doesn't have this parameter.

### Solution
**Remove `weights_only=False` for older PyTorch:**

Edit `RNA-FM-main/fm/pretrained.py` line 41 and 71:
```python
# BEFORE (PyTorch 2.6+)
data = torch.load(..., weights_only=False)

# AFTER (PyTorch 2.4 and older)
data = torch.load(...)
```

**Check your PyTorch version:**
```python
import torch
print(torch.__version__)
```

---

## Issue 4: "ReduceLROnPlateau.__init__() got an unexpected keyword argument 'verbose'"

### Symptoms
- Error at scheduler initialization
- PyTorch 1.13+ removed the `verbose` parameter

### Solution
✅ **Already fixed in this release.** The `verbose=True` parameter has been removed from:
- `training/optimization.py` (line 186)
- `training/trainer.py` (line 160)

If you still see this error, re-run:
```powershell
git status  # Check for uncommitted changes
cd "c:\shawon2\both paper models\CRISPR-UniPredict"
python scripts/train.py --config configs/smoke_rna_fm.yaml --debug
```

---

## Issue 5: "std(): degrees of freedom is <= 0" warnings

### Symptoms
```
UserWarning: std(): degrees of freedom is <= 0. Correction should be strictly less 
than the reduction factor (input numel divided by output numel).
```

### Cause
**Expected behavior in on-target loss.** When batch has only 1-2 on-target samples, standard deviation fails (needs n ≥ 2).

### Impact
- ⚠️ Non-fatal warning
- Loss still computes correctly
- Does **not** indicate a problem

### Solutions
1. **Ignore** — Training proceeds normally (recommend this)
2. **Increase batch size** — Use batch_size ≥ 16 in config (reduces warning frequency)
3. **Modify loss function** — Add epsilon to std() in `utils/losses.py` line 233 (optional)

---

## Issue 6: "ModuleNotFoundError: No module named 'fm'"

### Symptoms
```
ModuleNotFoundError: No module named 'fm'
ImportError: RNA-FM not available. Please install from RNA-FM-main directory
```

### Cause
RNA-FM package not in Python path

### Solution

**Option 1: Set PYTHONPATH (recommended)**
```powershell
$env:PYTHONPATH = "c:\shawon2\both paper models\RNA-FM-main"
python scripts/train.py --config configs/smoke_rna_fm.yaml
```

**Option 2: Install as package**
```powershell
cd "c:\shawon2\both paper models\RNA-FM-main"
pip install -e .
python scripts/train.py --config configs/smoke_rna_fm.yaml
```

**Verify it works:**
```python
import sys
sys.path.insert(0, r"c:\shawon2\both paper models\RNA-FM-main")
import fm
print("RNA-FM available:", fm.__version__)
```

---

## Issue 7: Extremely slow training (>5 s/batch on GPU)

### Symptoms
- Training much slower than expected
- Still works, but very slow

### Causes
1. GPU not being used (using CPU instead)
2. Batch size too small
3. `num_workers > 0` on Windows (dataloader spawn issues)

### Solutions

**Check GPU usage:**
```powershell
python -c "import torch; print('GPU available:', torch.cuda.is_available())"
```

**Fix GPU (config file):**
```yaml
device:
  use_cuda: true
```

**Fix batch size:**
```yaml
training:
  batch_size: 32  # Increase from 8
```

**Fix dataloader (already fixed, but verify):**
```yaml
data:
  num_workers: 0  # Keep as 0 on Windows
```

---

## Issue 8: "RuntimeError: Expected all tensors to be on the same device"

### Symptoms
```
RuntimeError: Expected all tensors to be on the same device, but found at least 
two devices, cuda:0 and cpu!
```

### Cause
Model on GPU but data on CPU, or vice versa

### Solutions

**Verify device match in config:**
```yaml
device:
  use_cuda: true  # Match your setup
  mixed_precision: false
```

**Manual fix in Python:**
```python
model = model.to('cuda')  # Move model to GPU
```

---

## Issue 9: Memory error / CUDA out of memory

### Symptoms
```
RuntimeError: CUDA out of memory. Tried to allocate X.XXGB
```

### Solution: Reduce batch size

Edit `configs/smoke_rna_fm.yaml` or your config:
```yaml
training:
  batch_size: 4  # Down from 8
  
inference:
  batch_size: 4  # Down from 8
```

---

## Issue 10: Training gets stuck / appears frozen

### Symptoms
- No progress bar update for >30 seconds
- No error message
- `Top CPU/GPU usage drops to 0`

### Cause
Usually **Windows dataloader issue** with `num_workers > 0`

### Solution
Verify config has:
```yaml
data:
  num_workers: 0  # Never > 0 on Windows
```

If still stuck, restart Python process:
```powershell
# Kill any Python processes
Stop-Process -Name python -Force -ErrorAction SilentlyContinue

# Try again
python scripts/train.py --config configs/smoke_rna_fm.yaml --debug
```

---

## Issue 11: "FileNotFoundError: data/processed/combined/train.csv"

### Symptoms
```
FileNotFoundError: [Errno 2] No such file or directory: 'data/processed/combined/train.csv'
```

### Cause
Working directory is wrong or data path in config is incorrect

### Solution

**Check working directory:**
```powershell
cd "c:\shawon2\both paper models\CRISPR-UniPredict"
ls data/processed/combined/
```

**If missing, create symlink or verify data exists:**
```powershell
# List what data exists
ls data/
```

**Adjust config path if needed:**
```yaml
data:
  train_path: "data/processed/combined/train.csv"
  val_path: "data/processed/combined/val.csv"
  test_path: "data/processed/combined/test.csv"
```

---

## Quick Diagnostic Checklist

Run this to debug most issues:

```powershell
# 1. Check RNA-FM available
python -c "import sys; sys.path.insert(0, 'c:\shawon2\both paper models\RNA-FM-main'); import fm; print('✓ RNA-FM OK')"

# 2. Check GPU
python -c "import torch; print('GPU:', 'YES' if torch.cuda.is_available() else 'NO')"

# 3. Check data
python -c "import pandas as pd; print('Train rows:', len(pd.read_csv('data/processed/combined/train.csv', nrows=100)))"

# 4. Try smoke test
python scripts/train.py --config configs/smoke_rna_fm.yaml --experiment_name diag --debug --seed 42
```

---

## Getting Help

1. **Check logs:** `logs/<experiment_name>_<timestamp>/`
2. **Consult this guide** first (you are here)
3. **Read session docs:** 
   - `docs/FULL_SESSION_DOCUMENTATION.md`
   - `docs/FIXES_2026-04-12_PIPELINE_AND_TRAINING.md`
   - `docs/VERIFICATION_REPORT_2026-04-19.md`
4. **Create minimal reproduction:**
   ```python
   from utils.preprocessing.dataloader_fast import FastCRISPRDataset
   from models.encoding import SequenceEncoder
   ds = FastCRISPRDataset("data/processed/combined/train.csv", 
                          SequenceEncoder(device="cpu"), verbose=True)
   print(len(ds), "samples loaded")
   ```

---

*End of troubleshooting guide.*
