"""
Data Validation Script for CRISPR-UniPredict
Validates preprocessed train/val/test splits
"""

import os
import sys
from pathlib import Path
import pandas as pd
import numpy as np
from typing import Dict, List, Tuple, Optional
from datetime import datetime
import warnings

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))


class DataValidator:
    """Comprehensive data validation for preprocessed splits"""
    
    def __init__(self, data_dir=None):
        """
        Initialize validator
        
        Args:
            data_dir: Directory containing split files
        """
        if data_dir is None:
            data_dir = Path(__file__).parent.parent / "data" / "processed" / "combined"
        
        self.data_dir = Path(data_dir)
        self.train_df = None
        self.val_df = None
        self.test_df = None
        
        self.validation_results = {
            'passed': [],
            'failed': [],
            'warnings': [],
            'statistics': {}
        }
    
    def load_splits(self) -> bool:
        """
        Load train/val/test splits
        
        Returns:
            True if all files loaded successfully
        """
        print(f"\n{'─' * 80}")
        print(f"LOADING DATA SPLITS")
        print(f"{'─' * 80}\n")
        
        try:
            train_path = self.data_dir / "train.csv"
            val_path = self.data_dir / "val.csv"
            test_path = self.data_dir / "test.csv"
            
            # Check files exist
            for path in [train_path, val_path, test_path]:
                if not path.exists():
                    raise FileNotFoundError(f"File not found: {path}")
            
            # Load files
            print(f"Loading train.csv...")
            self.train_df = pd.read_csv(train_path)
            print(f"  ✓ Loaded: {len(self.train_df):,} samples × {len(self.train_df.columns)} columns")
            
            print(f"Loading val.csv...")
            self.val_df = pd.read_csv(val_path)
            print(f"  ✓ Loaded: {len(self.val_df):,} samples × {len(self.val_df.columns)} columns")
            
            print(f"Loading test.csv...")
            self.test_df = pd.read_csv(test_path)
            print(f"  ✓ Loaded: {len(self.test_df):,} samples × {len(self.test_df.columns)} columns")
            
            return True
            
        except Exception as e:
            print(f"  ✗ Error loading files: {str(e)}")
            return False
    
    def validate_sequence(self, seq: str) -> Tuple[bool, Optional[str]]:
        """
        Validate a sequence
        
        Args:
            seq: Sequence string
            
        Returns:
            Tuple of (is_valid, error_message)
        """
        if not isinstance(seq, str):
            return False, "Not a string"
        
        if len(seq) == 0:
            return False, "Empty sequence"
        
        seq_upper = seq.upper()
        
        # Check for valid nucleotides
        if not all(c in 'ACGT' for c in seq_upper):
            return False, f"Invalid nucleotides: {seq}"
        
        return True, None
    
    def check_column_existence(self) -> bool:
        """Check if all required columns exist"""
        print(f"\n{'─' * 80}")
        print(f"CHECKING COLUMN EXISTENCE")
        print(f"{'─' * 80}\n")
        
        required_columns = [
            'sgrna_sequence', 'target_sequence', 'pam_sequence',
            'on_target_score', 'off_target_label', 'dataset_source',
            'cell_line', 'detection_method', 'task_type'
        ]
        
        all_valid = True
        
        for df_name, df in [('train', self.train_df), ('val', self.val_df), ('test', self.test_df)]:
            missing = [col for col in required_columns if col not in df.columns]
            
            if missing:
                msg = f"✗ {df_name}: Missing columns: {missing}"
                print(msg)
                self.validation_results['failed'].append(msg)
                all_valid = False
            else:
                msg = f"✓ {df_name}: All required columns present"
                print(msg)
                self.validation_results['passed'].append(msg)
        
        return all_valid
    
    def check_sequence_validity(self) -> bool:
        """Check if all sequences are valid"""
        print(f"\n{'─' * 80}")
        print(f"CHECKING SEQUENCE VALIDITY")
        print(f"{'─' * 80}\n")
        
        all_valid = True
        
        for df_name, df in [('train', self.train_df), ('val', self.val_df), ('test', self.test_df)]:
            invalid_count = 0
            invalid_examples = []
            
            for idx, row in df.iterrows():
                seq = row['sgrna_sequence']
                is_valid, error = self.validate_sequence(seq)
                
                if not is_valid:
                    invalid_count += 1
                    if len(invalid_examples) < 3:
                        invalid_examples.append(f"Row {idx}: {seq} ({error})")
            
            if invalid_count > 0:
                msg = f"✗ {df_name}: {invalid_count} invalid sgRNA sequences"
                print(msg)
                for example in invalid_examples:
                    print(f"    {example}")
                self.validation_results['failed'].append(msg)
                all_valid = False
            else:
                msg = f"✓ {df_name}: All sgRNA sequences valid (ACGT only)"
                print(msg)
                self.validation_results['passed'].append(msg)
        
        return all_valid
    
    def check_sequence_lengths(self) -> bool:
        """Check if sequence lengths are within valid range"""
        print(f"\n{'─' * 80}")
        print(f"CHECKING SEQUENCE LENGTHS")
        print(f"{'─' * 80}\n")
        
        MIN_LENGTH = 19
        MAX_LENGTH = 23
        all_valid = True
        
        for df_name, df in [('train', self.train_df), ('val', self.val_df), ('test', self.test_df)]:
            lengths = df['sgrna_sequence'].str.len()
            invalid_mask = (lengths < MIN_LENGTH) | (lengths > MAX_LENGTH)
            invalid_count = invalid_mask.sum()
            
            if invalid_count > 0:
                min_len = lengths.min()
                max_len = lengths.max()
                msg = f"✗ {df_name}: {invalid_count} sequences outside {MIN_LENGTH}-{MAX_LENGTH} bp range (min: {min_len}, max: {max_len})"
                print(msg)
                self.validation_results['failed'].append(msg)
                all_valid = False
            else:
                min_len = lengths.min()
                max_len = lengths.max()
                msg = f"✓ {df_name}: All sequences in valid range ({min_len}-{max_len} bp)"
                print(msg)
                self.validation_results['passed'].append(msg)
        
        return all_valid
    
    def check_on_target_scores(self) -> bool:
        """Check if on_target_score is valid for on_target tasks"""
        print(f"\n{'─' * 80}")
        print(f"CHECKING ON-TARGET SCORES")
        print(f"{'─' * 80}\n")
        
        all_valid = True
        
        for df_name, df in [('train', self.train_df), ('val', self.val_df), ('test', self.test_df)]:
            on_target_df = df[df['task_type'] == 'on_target']
            
            if len(on_target_df) == 0:
                msg = f"✓ {df_name}: No on_target samples"
                print(msg)
                self.validation_results['passed'].append(msg)
                continue
            
            # Check for NaN values
            nan_count = on_target_df['on_target_score'].isna().sum()
            
            # Check for values outside 0-1 range
            valid_scores = on_target_df['on_target_score'].dropna()
            invalid_range = ((valid_scores < 0) | (valid_scores > 1)).sum()
            
            if nan_count > 0 or invalid_range > 0:
                msg = f"✗ {df_name}: Invalid on_target_scores (NaN: {nan_count}, Out of range: {invalid_range})"
                print(msg)
                self.validation_results['failed'].append(msg)
                all_valid = False
            else:
                min_score = valid_scores.min()
                max_score = valid_scores.max()
                msg = f"✓ {df_name}: All on_target_scores valid (range: {min_score:.4f}-{max_score:.4f})"
                print(msg)
                self.validation_results['passed'].append(msg)
        
        return all_valid
    
    def check_off_target_labels(self) -> bool:
        """Check if off_target_label is valid for off_target tasks"""
        print(f"\n{'─' * 80}")
        print(f"CHECKING OFF-TARGET LABELS")
        print(f"{'─' * 80}\n")
        
        all_valid = True
        
        for df_name, df in [('train', self.train_df), ('val', self.val_df), ('test', self.test_df)]:
            off_target_df = df[df['task_type'] == 'off_target']
            
            if len(off_target_df) == 0:
                msg = f"✓ {df_name}: No off_target samples"
                print(msg)
                self.validation_results['passed'].append(msg)
                continue
            
            # Check for NaN values
            nan_count = off_target_df['off_target_label'].isna().sum()
            
            # Check for values outside 0-1 range
            valid_labels = off_target_df['off_target_label'].dropna()
            invalid_values = ~valid_labels.isin([0, 1])
            invalid_count = invalid_values.sum()
            
            if nan_count > 0 or invalid_count > 0:
                msg = f"✗ {df_name}: Invalid off_target_labels (NaN: {nan_count}, Invalid values: {invalid_count})"
                print(msg)
                self.validation_results['failed'].append(msg)
                all_valid = False
            else:
                label_dist = valid_labels.value_counts().to_dict()
                msg = f"✓ {df_name}: All off_target_labels valid (0: {label_dist.get(0, 0)}, 1: {label_dist.get(1, 0)})"
                print(msg)
                self.validation_results['passed'].append(msg)
        
        return all_valid
    
    def check_missing_values(self) -> bool:
        """Check for missing required values"""
        print(f"\n{'─' * 80}")
        print(f"CHECKING FOR MISSING VALUES")
        print(f"{'─' * 80}\n")
        
        required_cols = ['sgrna_sequence', 'task_type', 'dataset_source', 'detection_method']
        all_valid = True
        
        for df_name, df in [('train', self.train_df), ('val', self.val_df), ('test', self.test_df)]:
            missing_dict = {}
            
            for col in required_cols:
                missing_count = df[col].isna().sum()
                if missing_count > 0:
                    missing_dict[col] = missing_count
            
            if missing_dict:
                msg = f"✗ {df_name}: Missing values in required columns: {missing_dict}"
                print(msg)
                self.validation_results['failed'].append(msg)
                all_valid = False
            else:
                msg = f"✓ {df_name}: No missing values in required columns"
                print(msg)
                self.validation_results['passed'].append(msg)
        
        return all_valid
    
    def check_task_distribution(self) -> bool:
        """Check if task distribution is balanced"""
        print(f"\n{'─' * 80}")
        print(f"CHECKING TASK DISTRIBUTION")
        print(f"{'─' * 80}\n")
        
        all_valid = True
        
        for df_name, df in [('train', self.train_df), ('val', self.val_df), ('test', self.test_df)]:
            task_counts = df['task_type'].value_counts()
            
            if 'on_target' not in task_counts or 'off_target' not in task_counts:
                msg = f"⚠ {df_name}: Missing task type (on_target or off_target)"
                print(msg)
                self.validation_results['warnings'].append(msg)
                continue
            
            on_target_count = task_counts.get('on_target', 0)
            off_target_count = task_counts.get('off_target', 0)
            total = len(df)
            
            on_target_pct = (on_target_count / total) * 100
            off_target_pct = (off_target_count / total) * 100
            
            # Check if distribution is reasonable (should be ~8.57% on-target, ~91.43% off-target)
            expected_on_pct = 8.57
            expected_off_pct = 91.43
            tolerance = 0.5  # 0.5% tolerance
            
            on_pct_diff = abs(on_target_pct - expected_on_pct)
            off_pct_diff = abs(off_target_pct - expected_off_pct)
            
            if on_pct_diff > tolerance or off_pct_diff > tolerance:
                msg = f"⚠ {df_name}: Task distribution differs from expected (on: {on_target_pct:.2f}%, off: {off_target_pct:.2f}%)"
                print(msg)
                self.validation_results['warnings'].append(msg)
            else:
                msg = f"✓ {df_name}: Task distribution balanced (on: {on_target_pct:.2f}%, off: {off_target_pct:.2f}%)"
                print(msg)
                self.validation_results['passed'].append(msg)
        
        return True
    
    def check_no_duplicates(self) -> bool:
        """Check for duplicate sgRNA-target pairs between splits"""
        print(f"\n{'─' * 80}")
        print(f"CHECKING FOR DUPLICATE PAIRS BETWEEN SPLITS")
        print(f"{'─' * 80}\n")
        
        all_valid = True
        
        # Create pair identifiers (sgRNA + target + dataset source for uniqueness)
        def create_pair_id(df):
            return (df['sgrna_sequence'].astype(str) + '|' + 
                   df['target_sequence'].astype(str) + '|' + 
                   df['dataset_source'].astype(str))
        
        train_pairs = set(create_pair_id(self.train_df))
        val_pairs = set(create_pair_id(self.val_df))
        test_pairs = set(create_pair_id(self.test_df))
        
        # Check overlaps
        train_val_overlap = train_pairs & val_pairs
        train_test_overlap = train_pairs & test_pairs
        val_test_overlap = val_pairs & test_pairs
        
        if train_val_overlap:
            msg = f"⚠ Train-Val overlap: {len(train_val_overlap)} duplicate pairs (same sgRNA+target+dataset)"
            print(msg)
            self.validation_results['warnings'].append(msg)
        else:
            msg = f"✓ Train-Val: No duplicate pairs"
            print(msg)
            self.validation_results['passed'].append(msg)
        
        if train_test_overlap:
            msg = f"⚠ Train-Test overlap: {len(train_test_overlap)} duplicate pairs (same sgRNA+target+dataset)"
            print(msg)
            self.validation_results['warnings'].append(msg)
        else:
            msg = f"✓ Train-Test: No duplicate pairs"
            print(msg)
            self.validation_results['passed'].append(msg)
        
        if val_test_overlap:
            msg = f"⚠ Val-Test overlap: {len(val_test_overlap)} duplicate pairs (same sgRNA+target+dataset)"
            print(msg)
            self.validation_results['warnings'].append(msg)
        else:
            msg = f"✓ Val-Test: No duplicate pairs"
            print(msg)
            self.validation_results['passed'].append(msg)
        
        # Check for row-level duplicates within each split
        print(f"\nChecking for duplicate rows within splits:")
        
        for df_name, df in [('train', self.train_df), ('val', self.val_df), ('test', self.test_df)]:
            # Check for exact row duplicates
            duplicates = df.duplicated().sum()
            if duplicates > 0:
                msg = f"⚠ {df_name}: {duplicates} duplicate rows within split"
                print(f"  {msg}")
                self.validation_results['warnings'].append(msg)
            else:
                msg = f"✓ {df_name}: No duplicate rows within split"
                print(f"  {msg}")
                self.validation_results['passed'].append(msg)
        
        return all_valid
    
    def check_task_type_values(self) -> bool:
        """Check if task_type only contains valid values"""
        print(f"\n{'─' * 80}")
        print(f"CHECKING TASK TYPE VALUES")
        print(f"{'─' * 80}\n")
        
        valid_tasks = {'on_target', 'off_target'}
        all_valid = True
        
        for df_name, df in [('train', self.train_df), ('val', self.val_df), ('test', self.test_df)]:
            invalid_tasks = set(df['task_type'].unique()) - valid_tasks
            
            if invalid_tasks:
                msg = f"✗ {df_name}: Invalid task_type values: {invalid_tasks}"
                print(msg)
                self.validation_results['failed'].append(msg)
                all_valid = False
            else:
                msg = f"✓ {df_name}: All task_type values valid"
                print(msg)
                self.validation_results['passed'].append(msg)
        
        return all_valid
    
    def collect_statistics(self):
        """Collect statistics about the data"""
        print(f"\n{'─' * 80}")
        print(f"COLLECTING STATISTICS")
        print(f"{'─' * 80}\n")
        
        stats = {
            'train': {
                'total_samples': len(self.train_df),
                'on_target': len(self.train_df[self.train_df['task_type'] == 'on_target']),
                'off_target': len(self.train_df[self.train_df['task_type'] == 'off_target']),
                'avg_seq_length': self.train_df['sgrna_sequence'].str.len().mean(),
                'unique_datasets': self.train_df['dataset_source'].nunique()
            },
            'val': {
                'total_samples': len(self.val_df),
                'on_target': len(self.val_df[self.val_df['task_type'] == 'on_target']),
                'off_target': len(self.val_df[self.val_df['task_type'] == 'off_target']),
                'avg_seq_length': self.val_df['sgrna_sequence'].str.len().mean(),
                'unique_datasets': self.val_df['dataset_source'].nunique()
            },
            'test': {
                'total_samples': len(self.test_df),
                'on_target': len(self.test_df[self.test_df['task_type'] == 'on_target']),
                'off_target': len(self.test_df[self.test_df['task_type'] == 'off_target']),
                'avg_seq_length': self.test_df['sgrna_sequence'].str.len().mean(),
                'unique_datasets': self.test_df['dataset_source'].nunique()
            }
        }
        
        self.validation_results['statistics'] = stats
        
        print("Train split:")
        print(f"  Total: {stats['train']['total_samples']:,}")
        print(f"  On-target: {stats['train']['on_target']:,}")
        print(f"  Off-target: {stats['train']['off_target']:,}")
        print(f"  Avg sequence length: {stats['train']['avg_seq_length']:.2f} bp")
        print(f"  Unique datasets: {stats['train']['unique_datasets']}")
        
        print("\nValidation split:")
        print(f"  Total: {stats['val']['total_samples']:,}")
        print(f"  On-target: {stats['val']['on_target']:,}")
        print(f"  Off-target: {stats['val']['off_target']:,}")
        print(f"  Avg sequence length: {stats['val']['avg_seq_length']:.2f} bp")
        print(f"  Unique datasets: {stats['val']['unique_datasets']}")
        
        print("\nTest split:")
        print(f"  Total: {stats['test']['total_samples']:,}")
        print(f"  On-target: {stats['test']['on_target']:,}")
        print(f"  Off-target: {stats['test']['off_target']:,}")
        print(f"  Avg sequence length: {stats['test']['avg_seq_length']:.2f} bp")
        print(f"  Unique datasets: {stats['test']['unique_datasets']}")
    
    def validate_all(self) -> bool:
        """Run all validation checks"""
        print("\n" + "=" * 80)
        print("CRISPR-UniPredict DATA VALIDATION")
        print("=" * 80)
        
        # Load data
        if not self.load_splits():
            return False
        
        # Run all checks
        checks = [
            self.check_column_existence,
            self.check_sequence_validity,
            self.check_sequence_lengths,
            self.check_task_type_values,
            self.check_on_target_scores,
            self.check_off_target_labels,
            self.check_missing_values,
            self.check_task_distribution,
            self.check_no_duplicates
        ]
        
        results = []
        for check in checks:
            try:
                result = check()
                results.append(result)
            except Exception as e:
                print(f"\n✗ Error in {check.__name__}: {str(e)}")
                self.validation_results['failed'].append(f"Error in {check.__name__}: {str(e)}")
                results.append(False)
        
        # Collect statistics
        self.collect_statistics()
        
        # Print summary
        self._print_summary()
        
        return all(results)
    
    def _print_summary(self):
        """Print validation summary"""
        print("\n" + "=" * 80)
        print("VALIDATION SUMMARY")
        print("=" * 80)
        
        passed = len(self.validation_results['passed'])
        failed = len(self.validation_results['failed'])
        warnings = len(self.validation_results['warnings'])
        
        print(f"\nResults:")
        print(f"  ✓ Passed: {passed}")
        print(f"  ✗ Failed: {failed}")
        print(f"  ⚠ Warnings: {warnings}")
        
        if self.validation_results['failed']:
            print(f"\nFailed checks:")
            for check in self.validation_results['failed']:
                print(f"  ✗ {check}")
        
        if self.validation_results['warnings']:
            print(f"\nWarnings:")
            for warning in self.validation_results['warnings']:
                print(f"  ⚠ {warning}")
        
        overall_status = "✓ PASSED" if failed == 0 else "✗ FAILED"
        print(f"\n{'─' * 80}")
        print(f"Overall Status: {overall_status}")
        print(f"{'─' * 80}")
        
        if failed > 0:
            print("\n⚠ WARNING: Data validation found issues!")
            print("Please review the failed checks above.")
        else:
            print("\n✓ All validation checks passed!")
            print("Data is ready for model training.")


def main():
    """Main function"""
    validator = DataValidator()
    success = validator.validate_all()
    
    # Exit with appropriate code
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
