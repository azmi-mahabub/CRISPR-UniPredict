"""
Comprehensive system validation for CRISPR-UniPredict
Validates environment, data, model, performance, and API
"""

import sys
import os
import subprocess
import importlib
import argparse
import logging
from pathlib import Path
from typing import Dict, Tuple, List

# Add project root to Python path
sys.path.insert(0, str(Path(__file__).parent.parent))

import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)


class SystemValidator:
    """Comprehensive system validation"""
    
    def __init__(self, verbose: bool = False):
        self.verbose = verbose
        self.results = {}
        self.project_root = Path(__file__).parent.parent
    
    def log(self, message: str, level: str = 'info'):
        """Log message"""
        if level == 'info':
            logger.info(message)
        elif level == 'warning':
            logger.warning(message)
        elif level == 'error':
            logger.error(message)
        elif level == 'success':
            logger.info(f"✓ {message}")
    
    def validate_all(self) -> bool:
        """Run all validations"""
        self.log("=" * 80)
        self.log("CRISPR-UniPredict System Validation")
        self.log("=" * 80)
        
        all_passed = True
        
        # Run validations
        all_passed &= self.validate_environment()
        all_passed &= self.validate_data()
        all_passed &= self.validate_model()
        all_passed &= self.validate_performance()
        all_passed &= self.validate_api()
        
        # Summary
        self.log("=" * 80)
        self.print_summary(all_passed)
        self.log("=" * 80)
        
        return all_passed
    
    # ==================== ENVIRONMENT VALIDATION ====================
    
    def validate_environment(self) -> bool:
        """Validate environment"""
        self.log("\n1. ENVIRONMENT VALIDATION")
        self.log("-" * 80)
        
        passed = True
        
        # Python version
        py_version = sys.version_info
        if py_version >= (3, 9):
            self.log(f"✓ Python version: {py_version.major}.{py_version.minor}.{py_version.micro}")
        else:
            self.log(f"✗ Python 3.9+ required, got {py_version.major}.{py_version.minor}", 'error')
            passed = False
        
        # Check required packages
        required_packages = {
            'torch': '2.0.0',
            'numpy': '1.24.0',
            'pandas': '2.0.0',
            'matplotlib': '3.7.0',
            'seaborn': '0.12.0',
            'scikit-learn': '1.3.0',
            'scipy': '1.10.0',
        }
        
        for package, min_version in required_packages.items():
            try:
                # Handle sklearn special case
                if package == 'scikit-learn':
                    mod = importlib.import_module('sklearn')
                else:
                    mod = importlib.import_module(package)
                version = getattr(mod, '__version__', 'unknown')
                self.log(f"✓ {package}: {version}")
            except ImportError:
                self.log(f"✗ {package} not installed", 'error')
                passed = False
        
        # GPU availability
        try:
            import torch
            if torch.cuda.is_available():
                device_name = torch.cuda.get_device_name(0)
                device_memory = torch.cuda.get_device_properties(0).total_memory / 1e9
                self.log(f"✓ GPU available: {device_name} ({device_memory:.2f} GB)")
            else:
                self.log("⚠ GPU not available (will use CPU)", 'warning')
        except Exception as e:
            self.log(f"⚠ GPU check failed: {e}", 'warning')
        
        # Disk space
        try:
            import shutil
            total, used, free = shutil.disk_usage(self.project_root)
            free_gb = free / (1024**3)
            if free_gb > 5:
                self.log(f"✓ Disk space: {free_gb:.2f} GB available")
            else:
                self.log(f"⚠ Low disk space: {free_gb:.2f} GB available", 'warning')
        except Exception as e:
            self.log(f"⚠ Disk space check failed: {e}", 'warning')
        
        self.results['environment'] = passed
        return passed
    
    # ==================== DATA VALIDATION ====================
    
    def validate_data(self) -> bool:
        """Validate data integrity"""
        self.log("\n2. DATA VALIDATION")
        self.log("-" * 80)
        
        passed = True
        
        # Check data directories
        data_dirs = [
            'data/raw',
            'data/processed',
        ]
        
        for data_dir in data_dirs:
            path = self.project_root / data_dir
            if path.exists():
                self.log(f"✓ Data directory exists: {data_dir}")
            else:
                self.log(f"⚠ Data directory missing: {data_dir}", 'warning')
        
        # Check for CSV files
        csv_files = list((self.project_root / 'data').rglob('*.csv'))
        if csv_files:
            self.log(f"✓ Found {len(csv_files)} CSV files")
            
            # Validate CSV files
            for csv_file in csv_files[:3]:  # Check first 3
                try:
                    df = pd.read_csv(csv_file)
                    
                    # Check for required columns
                    if 'sgrna' in df.columns or 'sgRNA' in df.columns:
                        self.log(f"✓ {csv_file.name}: {len(df)} rows")
                        
                        # Check for duplicates
                        if df.duplicated().sum() == 0:
                            self.log(f"  ✓ No duplicate rows")
                        else:
                            self.log(f"  ⚠ Found {df.duplicated().sum()} duplicate rows", 'warning')
                        
                        # Check for missing values
                        missing = df.isnull().sum().sum()
                        if missing == 0:
                            self.log(f"  ✓ No missing values")
                        else:
                            self.log(f"  ⚠ Found {missing} missing values", 'warning')
                    else:
                        self.log(f"⚠ {csv_file.name}: Missing sgRNA column", 'warning')
                
                except Exception as e:
                    self.log(f"✗ Error reading {csv_file.name}: {e}", 'error')
                    passed = False
        else:
            self.log("⚠ No CSV files found in data directory", 'warning')
        
        self.results['data'] = passed
        return passed
    
    # ==================== MODEL VALIDATION ====================
    
    def validate_model(self) -> bool:
        """Validate model integrity"""
        self.log("\n3. MODEL VALIDATION")
        self.log("-" * 80)
        
        passed = True
        
        try:
            import torch
            from models.crispr_unipredict import CRISPRUniPredict
            from models.encoding import SequenceEncoder
            
            # Check checkpoint
            checkpoint_path = self.project_root / 'models' / 'checkpoints' / 'best.pt'
            if checkpoint_path.exists():
                self.log(f"✓ Checkpoint exists: {checkpoint_path.name}")
                
                # Try to load checkpoint
                try:
                    checkpoint = torch.load(checkpoint_path, map_location='cpu')
                    self.log(f"✓ Checkpoint loads successfully")
                except Exception as e:
                    self.log(f"✗ Failed to load checkpoint: {e}", 'error')
                    passed = False
            else:
                self.log(f"⚠ Checkpoint not found: {checkpoint_path}", 'warning')
            
            # Initialize model
            try:
                device = 'cuda' if torch.cuda.is_available() else 'cpu'
                model = CRISPRUniPredict(device=device)
                self.log(f"✓ Model initialized on {device}")
                
                # Check parameters
                total_params = model.get_total_params()
                trainable_params = model.get_trainable_params()
                
                self.log(f"✓ Total parameters: {total_params:,}")
                self.log(f"✓ Trainable parameters: {trainable_params:,}")
                
                # Check for NaN parameters
                has_nan = False
                for name, param in model.named_parameters():
                    if torch.isnan(param).any():
                        self.log(f"✗ NaN found in {name}", 'error')
                        has_nan = True
                        passed = False
                
                if not has_nan:
                    self.log(f"✓ No NaN parameters")
                
                # Test forward pass
                try:
                    encoder = SequenceEncoder(device=device)
                    sgrna = "GCTAGCTAGCTAGCTAGCTAGCT"
                    
                    onehot = encoder.one_hot_encode(sgrna).unsqueeze(0)
                    label = encoder.label_encode(sgrna, add_start_token=False).unsqueeze(0)
                    
                    with torch.no_grad():
                        on_target, off_target = model(onehot, label, task_type='both')
                    
                    self.log(f"✓ Forward pass successful")
                    self.log(f"  On-target: {on_target.item():.4f}")
                    self.log(f"  Off-target: {off_target.item():.4f}")
                    
                    # Check output ranges
                    if 0 <= on_target.item() <= 1 and 0 <= off_target.item() <= 1:
                        self.log(f"✓ Output in valid range [0, 1]")
                    else:
                        self.log(f"✗ Output out of range", 'error')
                        passed = False
                
                except Exception as e:
                    self.log(f"✗ Forward pass failed: {e}", 'error')
                    passed = False
            
            except Exception as e:
                self.log(f"✗ Model initialization failed: {e}", 'error')
                passed = False
        
        except ImportError as e:
            self.log(f"✗ Failed to import model: {e}", 'error')
            passed = False
        
        self.results['model'] = passed
        return passed
    
    # ==================== PERFORMANCE VALIDATION ====================
    
    def validate_performance(self) -> bool:
        """Validate performance"""
        self.log("\n4. PERFORMANCE VALIDATION")
        self.log("-" * 80)
        
        passed = True
        
        try:
            import torch
            import time
            from models.crispr_unipredict import CRISPRUniPredict
            from models.encoding import SequenceEncoder
            
            device = 'cuda' if torch.cuda.is_available() else 'cpu'
            model = CRISPRUniPredict(device=device)
            encoder = SequenceEncoder(device=device)
            
            # Test batch prediction
            sgrnas = ["GCTAGCTAGCTAGCTAGCTAGCT"] * 10
            
            oneshots = []
            labels = []
            for sgrna in sgrnas:
                onehot = encoder.one_hot_encode(sgrna)
                label = encoder.label_encode(sgrna, add_start_token=False)
                oneshots.append(onehot)
                labels.append(label)
            
            onehot_batch = torch.stack(oneshots)
            label_batch = torch.stack(labels)
            
            # Time prediction
            start = time.time()
            with torch.no_grad():
                on_target, off_target = model(onehot_batch, label_batch, task_type='both')
            elapsed = time.time() - start
            
            self.log(f"✓ Batch prediction (10 sequences): {elapsed*1000:.2f}ms")
            
            # Check inference speed
            if elapsed < 1.0:
                self.log(f"✓ Inference speed acceptable")
            else:
                self.log(f"⚠ Inference speed slow: {elapsed:.2f}s", 'warning')
            
            # Check consistency
            predictions1 = on_target.cpu().numpy()
            
            with torch.no_grad():
                on_target2, _ = model(onehot_batch, label_batch, task_type='both')
            predictions2 = on_target2.cpu().numpy()
            
            if np.allclose(predictions1, predictions2):
                self.log(f"✓ Predictions consistent across runs")
            else:
                self.log(f"⚠ Predictions differ across runs", 'warning')
            
            # Check vs random baseline
            random_baseline = np.random.uniform(0, 1, predictions1.shape)
            
            model_mean_error = np.mean(np.abs(predictions1 - 0.5))
            random_mean_error = np.mean(np.abs(random_baseline - 0.5))
            
            if model_mean_error < random_mean_error:
                self.log(f"✓ Model better than random baseline")
            else:
                self.log(f"⚠ Model not better than random baseline", 'warning')
        
        except Exception as e:
            self.log(f"✗ Performance validation failed: {e}", 'error')
            passed = False
        
        self.results['performance'] = passed
        return passed
    
    # ==================== API VALIDATION ====================
    
    def validate_api(self) -> bool:
        """Validate API functionality"""
        self.log("\n5. API VALIDATION")
        self.log("-" * 80)
        
        passed = True
        
        try:
            from api.inference_api import app
            from fastapi.testclient import TestClient
            
            client = TestClient(app)
            
            # Test health endpoint
            try:
                response = client.get("/health")
                if response.status_code == 200:
                    self.log(f"✓ Health endpoint: OK")
                else:
                    self.log(f"✗ Health endpoint returned {response.status_code}", 'error')
                    passed = False
            except Exception as e:
                self.log(f"✗ Health endpoint failed: {e}", 'error')
                passed = False
            
            # Test model info endpoint
            try:
                response = client.get("/model/info")
                if response.status_code == 200:
                    self.log(f"✓ Model info endpoint: OK")
                else:
                    self.log(f"✗ Model info endpoint returned {response.status_code}", 'error')
                    passed = False
            except Exception as e:
                self.log(f"✗ Model info endpoint failed: {e}", 'error')
                passed = False
            
            # Test on-target prediction
            try:
                response = client.post(
                    "/predict/on_target",
                    json={"sgrna": "GCTAGCTAGCTAGCTAGCTAGCT"}
                )
                if response.status_code == 200:
                    data = response.json()
                    if "efficiency_score" in data:
                        self.log(f"✓ On-target prediction: OK")
                    else:
                        self.log(f"✗ On-target prediction missing fields", 'error')
                        passed = False
                else:
                    self.log(f"✗ On-target prediction returned {response.status_code}", 'error')
                    passed = False
            except Exception as e:
                self.log(f"✗ On-target prediction failed: {e}", 'error')
                passed = False
            
            # Test comprehensive prediction
            try:
                response = client.post(
                    "/predict/comprehensive",
                    json={
                        "sgrna": "GCTAGCTAGCTAGCTAGCTAGCT",
                        "target": "ATGCATGCATGCATGCATGCATG"
                    }
                )
                if response.status_code == 200:
                    data = response.json()
                    required_fields = ["on_target_score", "off_target_risk", "comprehensive_score"]
                    if all(field in data for field in required_fields):
                        self.log(f"✓ Comprehensive prediction: OK")
                    else:
                        self.log(f"✗ Comprehensive prediction missing fields", 'error')
                        passed = False
                else:
                    self.log(f"✗ Comprehensive prediction returned {response.status_code}", 'error')
                    passed = False
            except Exception as e:
                self.log(f"✗ Comprehensive prediction failed: {e}", 'error')
                passed = False
            
            # Test batch prediction
            try:
                response = client.post(
                    "/batch_predict",
                    json={
                        "sgrnas": ["GCTAGCTAGCTAGCTAGCTAGCT", "ATGCATGCATGCATGCATGCATG"],
                        "targets": ["ATGCATGCATGCATGCATGCATG", "GCTAGCTAGCTAGCTAGCTAGCT"]
                    }
                )
                if response.status_code == 200:
                    data = response.json()
                    if "predictions" in data and len(data["predictions"]) == 2:
                        self.log(f"✓ Batch prediction: OK")
                    else:
                        self.log(f"✗ Batch prediction format incorrect", 'error')
                        passed = False
                else:
                    self.log(f"✗ Batch prediction returned {response.status_code}", 'error')
                    passed = False
            except Exception as e:
                self.log(f"✗ Batch prediction failed: {e}", 'error')
                passed = False
            
            # Test error handling
            try:
                response = client.post(
                    "/predict/on_target",
                    json={"sgrna": "INVALID"}
                )
                if response.status_code != 200:
                    self.log(f"✓ Error handling: OK (rejected invalid input)")
                else:
                    self.log(f"⚠ Error handling: accepted invalid input", 'warning')
            except Exception as e:
                self.log(f"⚠ Error handling test failed: {e}", 'warning')
        
        except ImportError:
            self.log(f"⚠ API not available (FastAPI not installed)", 'warning')
        except Exception as e:
            self.log(f"✗ API validation failed: {e}", 'error')
            passed = False
        
        self.results['api'] = passed
        return passed
    
    # ==================== SUMMARY ====================
    
    def print_summary(self, all_passed: bool):
        """Print validation summary"""
        self.log("\nVALIDATION SUMMARY")
        self.log("-" * 80)
        
        for component, passed in self.results.items():
            status = "✓ OK" if passed else "✗ FAILED"
            self.log(f"{component.upper()}: {status}")
        
        self.log("")
        if all_passed:
            self.log("✓ System ready for use!", 'success')
            return 0
        else:
            self.log("✗ System validation failed. Please fix issues above.", 'error')
            return 1


def main():
    """Main function"""
    parser = argparse.ArgumentParser(
        description='Validate CRISPR-UniPredict system'
    )
    parser.add_argument(
        '--comprehensive',
        action='store_true',
        help='Run comprehensive validation'
    )
    parser.add_argument(
        '--verbose',
        action='store_true',
        help='Verbose output'
    )
    
    args = parser.parse_args()
    
    validator = SystemValidator(verbose=args.verbose)
    passed = validator.validate_all()
    
    return 0 if passed else 1


if __name__ == "__main__":
    sys.exit(main())
