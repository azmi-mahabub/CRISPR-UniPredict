"""
Main Training Script for CRISPR-UniPredict
Entry point for training the model with configuration management
"""

import argparse
import sys
import logging
import json
from pathlib import Path
from datetime import datetime
import numpy as np
import torch
import matplotlib.pyplot as plt
import seaborn as sns

# Add parent directory to path
_PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_PROJECT_ROOT))

from utils.rna_fm_path import ensure_rna_fm_import_path

ensure_rna_fm_import_path(_PROJECT_ROOT)

from configs.config_loader import ConfigLoader
from models.crispr_unipredict import CRISPRUniPredict
from utils.preprocessing.dataloader_fast import (
    create_fast_dataloaders,
    build_stratified_debug_indices,
)
from training.trainer import Trainer
from training.optimization import create_optimizer_and_scheduler


def setup_logging(experiment_dir: Path) -> logging.Logger:
    """
    Setup logging to file and console
    
    Args:
        experiment_dir: Directory for experiment logs
    
    Returns:
        Configured logger
    """
    experiment_dir.mkdir(parents=True, exist_ok=True)
    
    # Create logger
    logger = logging.getLogger('CRISPR-UniPredict')
    logger.setLevel(logging.DEBUG)
    
    # File handler
    log_file = experiment_dir / 'training.log'
    file_handler = logging.FileHandler(log_file)
    file_handler.setLevel(logging.DEBUG)
    
    # Console handler
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    
    # Formatter
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    file_handler.setFormatter(formatter)
    console_handler.setFormatter(formatter)
    
    # Add handlers
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)
    
    return logger


def set_random_seeds(seed: int = 42) -> None:
    """
    Set random seeds for reproducibility
    
    Args:
        seed: Random seed value
    """
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    
    # Ensure deterministic behavior
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def setup_device(config) -> str:
    """
    Setup device (CPU/GPU/multi-GPU)
    
    Args:
        config: Configuration object
    
    Returns:
        Device string ('cpu' or 'cuda')
    """
    if config.device.use_cuda and torch.cuda.is_available():
        device = 'cuda'
        logger.info(f"Using GPU: {torch.cuda.get_device_name(0)}")
        logger.info(f"GPU Memory: {torch.cuda.get_device_properties(0).total_memory / 1e9:.2f} GB")
    else:
        device = 'cpu'
        logger.info("Using CPU")
    
    return device


def create_experiment_directory(experiment_name: str) -> Path:
    """
    Create experiment directory
    
    Args:
        experiment_name: Name of experiment
    
    Returns:
        Path to experiment directory
    """
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    experiment_dir = Path('logs') / f"{experiment_name}_{timestamp}"
    experiment_dir.mkdir(parents=True, exist_ok=True)
    
    return experiment_dir


def load_config(config_path: str) -> object:
    """
    Load configuration from YAML file
    
    Args:
        config_path: Path to config file
    
    Returns:
        Configuration object
    """
    if not Path(config_path).exists():
        raise FileNotFoundError(f"Config file not found: {config_path}")
    
    config_loader = ConfigLoader(config_path)
    return config_loader.config


def create_dataloaders(config, debug: bool = False, device: str = 'cuda'):
    """
    Create dataloaders using fast loader
    
    Args:
        config: Configuration object
        debug: Use small subset for debugging
        device: Device for encoding
    
    Returns:
        Dictionary with dataloaders
    """
    dataloaders = create_fast_dataloaders(config, device=device)
    
    if debug:
        max_dbg = 256
        logger.info(
            f"Debug mode: stratified subset (up to {max_dbg} rows per split: "
            "on-target + off-target labels when present)"
        )
        for split in ['train', 'val', 'test']:
            if split in dataloaders:
                original_loader = dataloaders[split]
                idx = build_stratified_debug_indices(
                    original_loader.dataset,
                    max_samples=min(max_dbg, len(original_loader.dataset)),
                    seed=42,
                )
                dataloaders[split] = torch.utils.data.DataLoader(
                    original_loader.dataset,
                    batch_size=original_loader.batch_size,
                    sampler=torch.utils.data.SequentialSampler(idx),
                    collate_fn=original_loader.collate_fn,
                )
    
    return dataloaders


def initialize_model(config, device: str) -> CRISPRUniPredict:
    """
    Initialize model
    
    Args:
        config: Configuration object
        device: Device string
    
    Returns:
        Initialized model
    """
    model = CRISPRUniPredict(device=device)
    
    # Log model information
    total_params = sum(p.numel() for p in model.parameters())
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    
    logger.info(f"Model initialized")
    logger.info(f"  Total parameters: {total_params:,}")
    logger.info(f"  Trainable parameters: {trainable_params:,}")
    
    return model


def save_config_and_args(experiment_dir: Path, config, args) -> None:
    """
    Save configuration and arguments to JSON
    
    Args:
        experiment_dir: Experiment directory
        config: Configuration object
        args: Command-line arguments
    """
    # Save config
    config_dict = {}
    for key in dir(config):
        if not key.startswith('_'):
            try:
                value = getattr(config, key)
                if isinstance(value, (str, int, float, bool, list, dict)):
                    config_dict[key] = value
            except:
                pass
    
    with open(experiment_dir / 'config.json', 'w') as f:
        json.dump(config_dict, f, indent=2)
    
    # Save arguments
    args_dict = vars(args)
    with open(experiment_dir / 'args.json', 'w') as f:
        json.dump(args_dict, f, indent=2)
    
    logger.info(f"Configuration saved to {experiment_dir / 'config.json'}")


def plot_training_history(history: dict, experiment_dir: Path) -> None:
    """
    Plot training history
    
    Args:
        history: Training history dictionary
        experiment_dir: Experiment directory
    """
    try:
        fig, axes = plt.subplots(2, 2, figsize=(12, 10))
        
        # Plot 1: Total loss
        train_losses = [m['total_loss'] for m in history['train']]
        val_losses = [m['total_loss'] for m in history['val']]
        
        axes[0, 0].plot(train_losses, label='Train', marker='o')
        axes[0, 0].plot(val_losses, label='Val', marker='s')
        axes[0, 0].set_xlabel('Epoch')
        axes[0, 0].set_ylabel('Loss')
        axes[0, 0].set_title('Total Loss')
        axes[0, 0].legend()
        axes[0, 0].grid(True)
        
        # Plot 2: On-target loss
        on_target_train = [m['on_target_loss'] for m in history['train']]
        on_target_val = [m['on_target_loss'] for m in history['val']]
        
        axes[0, 1].plot(on_target_train, label='Train', marker='o')
        axes[0, 1].plot(on_target_val, label='Val', marker='s')
        axes[0, 1].set_xlabel('Epoch')
        axes[0, 1].set_ylabel('Loss')
        axes[0, 1].set_title('On-Target Loss')
        axes[0, 1].legend()
        axes[0, 1].grid(True)
        
        # Plot 3: Off-target loss
        off_target_train = [m['off_target_loss'] for m in history['train']]
        off_target_val = [m['off_target_loss'] for m in history['val']]
        
        axes[1, 0].plot(off_target_train, label='Train', marker='o')
        axes[1, 0].plot(off_target_val, label='Val', marker='s')
        axes[1, 0].set_xlabel('Epoch')
        axes[1, 0].set_ylabel('Loss')
        axes[1, 0].set_title('Off-Target Loss')
        axes[1, 0].legend()
        axes[1, 0].grid(True)
        
        # Plot 4: Loss ratio
        loss_ratio = [on_target_train[i] / (off_target_train[i] + 1e-7) 
                     for i in range(len(on_target_train))]
        
        axes[1, 1].plot(loss_ratio, marker='o', color='green')
        axes[1, 1].set_xlabel('Epoch')
        axes[1, 1].set_ylabel('Ratio')
        axes[1, 1].set_title('On-Target / Off-Target Loss Ratio')
        axes[1, 1].grid(True)
        
        plt.tight_layout()
        plt.savefig(experiment_dir / 'training_history.png', dpi=150)
        logger.info(f"Training history plot saved to {experiment_dir / 'training_history.png'}")
        plt.close()
    
    except Exception as e:
        logger.warning(f"Failed to plot training history: {e}")


def save_training_summary(experiment_dir: Path, history: dict, trainer: Trainer) -> None:
    """
    Save training summary statistics
    
    Args:
        experiment_dir: Experiment directory
        history: Training history
        trainer: Trainer instance
    """
    summary = {
        'total_epochs': len(history['train']),
        'best_val_loss': float(trainer.best_val_loss),
        'best_model_path': str(trainer.best_model_path) if trainer.best_model_path else None,
        'final_train_loss': float(history['train'][-1]['total_loss']),
        'final_val_loss': float(history['val'][-1]['total_loss']),
        'train_losses': [float(m['total_loss']) for m in history['train']],
        'val_losses': [float(m['total_loss']) for m in history['val']],
        'on_target_train_losses': [float(m['on_target_loss']) for m in history['train']],
        'on_target_val_losses': [float(m['on_target_loss']) for m in history['val']],
        'off_target_train_losses': [float(m['off_target_loss']) for m in history['train']],
        'off_target_val_losses': [float(m['off_target_loss']) for m in history['val']]
    }
    
    with open(experiment_dir / 'summary.json', 'w') as f:
        json.dump(summary, f, indent=2)
    
    logger.info(f"Training summary saved to {experiment_dir / 'summary.json'}")
    
    # Print summary
    logger.info("\n" + "=" * 80)
    logger.info("TRAINING SUMMARY")
    logger.info("=" * 80)
    logger.info(f"Total epochs: {summary['total_epochs']}")
    logger.info(f"Best validation loss: {summary['best_val_loss']:.6f}")
    logger.info(f"Final train loss: {summary['final_train_loss']:.6f}")
    logger.info(f"Final val loss: {summary['final_val_loss']:.6f}")
    logger.info(f"Best model: {summary['best_model_path']}")
    logger.info("=" * 80 + "\n")


def parse_arguments():
    """Parse command-line arguments"""
    parser = argparse.ArgumentParser(
        description='Train CRISPR-UniPredict model',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Full training
  python scripts/train.py --config configs/model_config.yaml --experiment_name exp_001
  
  # Resume training
  python scripts/train.py --config configs/model_config.yaml --resume models/checkpoints/best.pt
  
  # Debug mode (small data)
  python scripts/train.py --config configs/model_config.yaml --debug
        """
    )
    
    parser.add_argument(
        '--config',
        type=str,
        default='configs/model_config.yaml',
        help='Path to configuration file'
    )
    
    parser.add_argument(
        '--resume',
        type=str,
        default=None,
        help='Path to checkpoint to resume from'
    )
    
    parser.add_argument(
        '--experiment_name',
        type=str,
        default='default_experiment',
        help='Name for this experiment'
    )
    
    parser.add_argument(
        '--debug',
        action='store_true',
        help='Use small subset for quick testing'
    )
    
    parser.add_argument(
        '--seed',
        type=int,
        default=42,
        help='Random seed for reproducibility'
    )
    
    return parser.parse_args()


def main():
    """Main training function"""
    
    # Parse arguments
    args = parse_arguments()
    
    # Create experiment directory
    experiment_dir = create_experiment_directory(args.experiment_name)
    
    # Setup logging
    global logger
    logger = setup_logging(experiment_dir)
    
    logger.info("=" * 80)
    logger.info("CRISPR-UniPredict Training")
    logger.info("=" * 80)
    logger.info(f"Experiment: {args.experiment_name}")
    logger.info(f"Experiment directory: {experiment_dir}")
    logger.info(f"Debug mode: {args.debug}")
    logger.info(f"Resume from: {args.resume}")
    
    try:
        # Set random seeds
        set_random_seeds(args.seed)
        logger.info(f"Random seed set to {args.seed}")
        
        # Load configuration
        logger.info(f"Loading configuration from {args.config}")
        config = load_config(args.config)
        
        # Save configuration
        save_config_and_args(experiment_dir, config, args)
        
        # Setup device
        device = setup_device(config)
        
        # Create dataloaders
        logger.info("Creating dataloaders...")
        dataloaders = create_dataloaders(config, debug=args.debug, device=device)
        logger.info(f"  Train batches: {len(dataloaders['train'])}")
        logger.info(f"  Val batches: {len(dataloaders['val'])}")
        logger.info(f"  Test batches: {len(dataloaders['test'])}")
        
        # Initialize model
        logger.info("Initializing model...")
        model = initialize_model(config, device)
        
        # Setup optimizer and scheduler
        logger.info("Setting up optimizer and scheduler...")
        optimizer, scheduler = create_optimizer_and_scheduler(model, config)
        
        # Initialize trainer
        logger.info("Initializing trainer...")
        trainer = Trainer(
            model=model,
            dataloaders=dataloaders,
            config=config,
            resume_from=args.resume
        )
        
        # Train model
        logger.info("Starting training...")
        history = trainer.train()
        
        # Save training history
        trainer.save_training_history(experiment_dir / 'training_history.json')
        
        # Plot training history
        plot_training_history(history, experiment_dir)
        
        # Save summary
        save_training_summary(experiment_dir, history, trainer)
        
        logger.info("Training completed successfully!")
        logger.info(f"Results saved to {experiment_dir}")
        
        return 0
    
    except Exception as e:
        logger.error(f"Training failed with error: {e}", exc_info=True)
        return 1


if __name__ == '__main__':
    sys.exit(main())
